import { createContext, useContext, useEffect, useState } from 'react'
import type { EmailList, Subset } from '../lib/api'
import { api } from '../lib/api'
import { OverviewPage } from '../pages/Overview'
import { BrowsePage } from '../pages/Browse'
import { PipelinePage } from '../pages/Pipeline'

type Page = 'overview' | 'pipeline' | 'browse'

const PAGES: { id: Page; label: string }[] = [
  { id: 'overview', label: 'Overview' },
  { id: 'pipeline', label: 'Pipeline' },
  { id: 'browse', label: 'Browse' },
]

interface AppState {
  subset: Subset
  setSubset: (subset: Subset) => void
  emails: EmailList | null
  openStory: (emailId: string) => void
}

const AppContext = createContext<AppState>({
  subset: 'all',
  setSubset: () => { },
  emails: null,
  openStory: () => { },
})

// eslint-disable-next-line react-refresh/only-export-components
export function useApp() {
  return useContext(AppContext)
}

export function Shell() {
  const [page, setPage] = useState<Page>('overview')
  const [subset, setSubset] = useState<Subset>('all')
  const [emails, setEmails] = useState<EmailList | null>(null)
  const [storyId, setStoryId] = useState<string | null>(null)

  useEffect(() => {
    api<EmailList>(`/emails?subset=${subset}`)
      .then(setEmails)
      .catch(() => setEmails(null))
  }, [subset])

  function openStory(emailId: string) {
    setStoryId(emailId)
    setPage('browse')
  }

  return (
    <AppContext.Provider value={{ subset, setSubset, emails, openStory }}>
      <div className="min-h-screen bg-slate-50/50">
        <header className="flex items-center justify-between px-6 py-3 bg-white/80 backdrop-blur-md border-b border-slate-100 sticky top-0 z-50">

          {/* Left: Extra Large Logo & Typography */}
          <div className="flex items-center gap-3">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 440 80" className="h-16 w-auto">
              <defs>
                <linearGradient id="shieldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#0284c7" />
                  <stop offset="100%" stopColor="#0f172a" />
                </linearGradient>
                <linearGradient id="checkGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#38bdf8" />
                  <stop offset="100%" stopColor="#22c55e" />
                </linearGradient>
              </defs>

              {/* Logo Mark / Icon */}
              <g transform="translate(10, 6) scale(1.1)">
                <path d="M12 4h32l16 16v40a6 6 0 0 1-6 6H12a6 6 0 0 1-6-6V10a6 6 0 0 1 6-6z" fill="#f8fafc" stroke="#cbd5e1" strokeWidth="2" />
                <path d="M44 4v16h16" fill="none" stroke="#cbd5e1" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />

                <rect x="14" y="16" width="18" height="3" rx="1.5" fill="#94a3b8" />
                <rect x="14" y="24" width="26" height="3" rx="1.5" fill="#94a3b8" />

                <path d="M36 30l18-6v14c0 10-7 18-18 22-11-4-18-12-18-22V24l18 6z" fill="url(#shieldGrad)" opacity="0.95" />

                <path d="M28 41l6 6 12-13" fill="none" stroke="url(#checkGrad)" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />
              </g>

              {/* Typography / Extra Large Brand Name & Subtitle */}
              <text x="92" y="40" fontFamily="system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif" fontWeight="800" fontSize="36" fill="#0f172a" letterSpacing="0.5">SDOC</text>
              <text x="195" y="40" fontFamily="system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif" fontWeight="300" fontSize="36" fill="#0284c7" letterSpacing="0.5">Verify</text>
              <text x="93" y="64" fontFamily="system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif" fontWeight="600" fontSize="17.5" fill="#64748b" letterSpacing="2.2">SHIPPING AUDIT ENGINE</text>
            </svg>
          </div>

          {/* Right: Scaled Up Navigation Bar */}
          <nav className="flex items-center gap-1.5 bg-slate-100/80 p-1.5 rounded-full border border-slate-200/60 shadow-sm">
            {PAGES.map(({ id, label }) => (
              <button
                key={id}
                type="button"
                onClick={() => setPage(id)}
                className={`px-6 py-2.5 text-sm font-semibold transition-all rounded-full ${page === id
                    ? 'bg-sky-600 text-white shadow-md'
                    : 'text-slate-600 hover:text-slate-900'
                  }`}
              >
                {label}
              </button>
            ))}
          </nav>

        </header>

        <main className="mx-auto max-w-6xl px-6 py-8">
          {page === 'overview' && <OverviewPage />}
          {page === 'pipeline' && <PipelinePage />}
          {page === 'browse' && (
            <BrowsePage storyId={storyId} onClose={() => setStoryId(null)} />
          )}
        </main>
      </div>
    </AppContext.Provider>
  )
}
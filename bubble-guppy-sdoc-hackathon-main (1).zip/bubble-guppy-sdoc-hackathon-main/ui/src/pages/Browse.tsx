import { useEffect, useMemo, useState } from 'react'
import type { Category, Status, Story, StoryAttachment } from '../lib/api'
import { FIELD_LABELS, api } from '../lib/api'
import { useApp } from '../app/shell'
import { CategoryChip, StatusBadge, SubsetSelector } from '../components/ui'
import { ResolvePanel } from '../components/ResolvePanel'

export function BrowsePage({
  storyId,
  onClose,
}: {
  storyId: string | null
  onClose: () => void
}) {
  const { emails, subset, setSubset } = useApp()
  const [query, setQuery] = useState('')
  const [categoryFilter, setCategoryFilter] = useState<Category | 'all'>('all')
  const [statusFilter, setStatusFilter] = useState<Status | 'all'>('all')
  const [selected, setSelected] = useState<string | null>(storyId)
  // Reset the selection when the shell opens a different story — derived in
  // render (no setState-in-effect).
  const [lastStoryId, setLastStoryId] = useState(storyId)
  if (lastStoryId !== storyId) {
    setLastStoryId(storyId)
    setSelected(storyId)
  }

  const filtered = useMemo(() => {
    if (!emails) return []
    const q = query.trim().toLowerCase()

    return emails.emails.filter((email) => {
      // 1. Filter by category
      if (categoryFilter !== 'all' && email.category !== categoryFilter) {
        return false
      }

      // 2. Filter by status
      if (statusFilter !== 'all' && email.status !== statusFilter) {
        return false
      }

      // 3. Search by email ID, subject, or field name / label
      if (q) {
        const matchId = email.email_id.toLowerCase().includes(q)
        const matchSubject = email.subject.toLowerCase().includes(q)
        const matchDefects = email.defect_fields.some((field) => {
          const rawMatch = field.toLowerCase().includes(q)
          const labelMatch = (FIELD_LABELS[field] ?? '').toLowerCase().includes(q)
          return rawMatch || labelMatch
        })
        const matchReason = (email.review_reason ?? '').toLowerCase().includes(q)
        if (!matchId && !matchSubject && !matchDefects && !matchReason) {
          return false
        }
      }

      return true
    })
  }, [emails, query, categoryFilter, statusFilter])

  if (selected) {
    return (
      <StoryView
        emailId={selected}
        onBack={() => {
          onClose?.()
          setSelected(null)
        }}
      />
    )
  }

  const hasActiveFilters = categoryFilter !== 'all' || statusFilter !== 'all' || query.trim().length > 0

  return (
    <div className="space-y-6">
      {/* Subset Selector */}
      <SubsetSelector subset={subset} onChange={setSubset} />

      {/* Multi-facet Filter Search Toolbar */}
      <div className="rounded-xl border border-line bg-card p-4 shadow-sm space-y-3">
        <div className="grid gap-3 md:grid-cols-12 items-center">
          {/* Search Email ID or Field Name */}
          <div className="relative md:col-span-6">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search email ID or field name (e.g. email_001, consignee)…"
              className="w-full rounded-lg border border-line bg-slate-50 px-4 py-2.5 text-base focus:border-primary focus:bg-white focus:outline-none transition-all"
            />
            {query && (
              <button
                type="button"
                onClick={() => setQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-ink-soft hover:text-ink cursor-pointer"
                title="Clear search"
              >
                ✕
              </button>
            )}
          </div>

          {/* Filter by Category */}
          <div className="md:col-span-3">
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value as Category | 'all')}
              className="w-full rounded-lg border border-line bg-slate-50 px-3 py-2.5 text-base font-semibold focus:border-primary focus:bg-white focus:outline-none transition-all cursor-pointer"
              aria-label="Filter by category"
            >
              <option value="all">All Categories</option>
              <option value="BL_COMPARISON">BL Comparison</option>
              <option value="SI_REQUEST">SI Request</option>
              <option value="INVOICE_QUERY">Invoice Query</option>
              <option value="GENERAL">General</option>
              <option value="SPAM">Spam</option>
            </select>
          </div>

          {/* Filter by Status */}
          <div className="md:col-span-3">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as Status | 'all')}
              className="w-full rounded-lg border border-line bg-slate-50 px-3 py-2.5 text-base font-semibold focus:border-primary focus:bg-white focus:outline-none transition-all cursor-pointer"
              aria-label="Filter by status"
            >
              <option value="all">All Statuses</option>
              <option value="OK">OK</option>
              <option value="MISMATCH">Mismatch</option>
              <option value="NEEDS_REVIEW">Needs Review</option>
            </select>
          </div>
        </div>

        {/* Active Filters Bar & Count */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-line/60 text-sm">
          <div className="flex items-center flex-wrap gap-2">
            <span className="font-semibold text-ink-soft">Active filters:</span>
            {!hasActiveFilters ? (
              <span className="text-slate-400 italic">None</span>
            ) : (
              <>
                {categoryFilter !== 'all' && (
                  <span className="inline-flex items-center gap-1 rounded-md bg-primary-soft px-2.5 py-0.5 text-xs font-bold text-primary">
                    Category: {categoryFilter.replace(/_/g, ' ')}
                    <button
                      type="button"
                      onClick={() => setCategoryFilter('all')}
                      className="hover:opacity-75 cursor-pointer"
                    >
                      ✕
                    </button>
                  </span>
                )}
                {statusFilter !== 'all' && (
                  <span className="inline-flex items-center gap-1 rounded-md bg-slate-100 px-2.5 py-0.5 text-xs font-bold text-slate-700">
                    Status: {statusFilter.replace(/_/g, ' ')}
                    <button
                      type="button"
                      onClick={() => setStatusFilter('all')}
                      className="hover:opacity-75 cursor-pointer"
                    >
                      ✕
                    </button>
                  </span>
                )}
                {query && (
                  <span className="inline-flex items-center gap-1 rounded-md bg-slate-100 px-2.5 py-0.5 text-xs font-bold text-slate-700">
                    Search: "{query}"
                    <button
                      type="button"
                      onClick={() => setQuery('')}
                      className="hover:opacity-75 cursor-pointer"
                    >
                      ✕
                    </button>
                  </span>
                )}
                <button
                  type="button"
                  onClick={() => {
                    setQuery('')
                    setCategoryFilter('all')
                    setStatusFilter('all')
                  }}
                  className="text-xs font-semibold text-rose-600 hover:underline cursor-pointer ml-1"
                >
                  Reset all
                </button>
              </>
            )}
          </div>

          <span className="font-semibold text-ink-soft">
            {emails ? `Showing ${filtered.length} of ${emails.count} emails` : '…'}
          </span>
        </div>
      </div>

      <div className="overflow-hidden rounded-xl border border-line bg-card shadow-sm">
        <table className="w-full text-left">
          <thead>
            <tr className="border-b border-line bg-slate-50 text-sm font-bold tracking-wide text-ink-soft uppercase">
              <th className="px-5 py-3">Email</th>
              <th className="px-5 py-3">Category</th>
              <th className="px-5 py-3">Status</th>
              <th className="px-5 py-3">Defect fields</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((email) => (
              <tr
                key={email.email_id}
                onClick={() => setSelected(email.email_id)}
                className="cursor-pointer border-b border-line/60 transition last:border-0 hover:bg-primary-soft"
              >
                <td className="px-5 py-3">
                  <div className="font-mono text-sm font-bold text-primary">{email.email_id}</div>
                  <div className="max-w-md truncate text-base">{email.subject}</div>
                </td>
                <td className="px-5 py-3"><CategoryChip category={email.category} /></td>
                <td className="px-5 py-3">
                  <span className="inline-flex items-center gap-2">
                    <StatusBadge status={email.status} />
                    {email.resolved && (
                      <span className="rounded-md border border-green-200 bg-ok-soft px-2.5 py-0.5 text-sm font-bold text-ok">
                        RESOLVED ✓
                      </span>
                    )}
                  </span>
                </td>
                <td className="px-5 py-3 text-sm">
                  {email.defect_fields.length
                    ? email.defect_fields.map((field) => field.replace(/_/g, ' ')).join(', ')
                    : email.review_reason ?? '—'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

function AnchorLines({ attachment, field }: { attachment: StoryAttachment; field: string | null }) {
  const anchorSet = useMemo(() => {
    if (!field) return new Set<number>()
    return new Set(attachment.anchors[field] ?? [])
  }, [attachment, field])
  return (
    <div className="max-h-64 overflow-auto rounded-lg border border-line bg-slate-50 p-3 font-mono text-sm leading-6">
      {attachment.lines.map((line, index) => (
        <div
          key={index}
          className={
            anchorSet.has(index)
              ? 'rounded bg-primary-soft px-2 font-bold text-primary'
              : 'px-2 text-ink-soft'
          }
        >
          {line || ' '}
        </div>
      ))}
    </div>
  )
}

function StoryView({ emailId, onBack }: { emailId: string; onBack: () => void }) {
  const [story, setStory] = useState<Story | null>(null)
  const [highlightField, setHighlightField] = useState<string | null>(null)
  const [reloadKey, setReloadKey] = useState(0)

  useEffect(() => {
    api<Story>(`/emails/${emailId}/story`).then(setStory).catch(() => setStory(null))
  }, [emailId, reloadKey])

  if (!story) return <p className="text-xl text-ink-soft">Loading story…</p>

  const { verdict } = story

  return (
    <div className="space-y-8">
      <button type="button" onClick={onBack} className="text-lg font-semibold text-primary hover:underline">
        ← Back to list
      </button>

      <div className="rounded-xl border border-line bg-card p-6 shadow-sm">
        <div className="flex items-start justify-between gap-4">
          <div>
            <div className="font-mono text-sm font-bold text-primary">{story.email_id}</div>
            <h2 className="mt-1 text-2xl font-bold">{story.subject}</h2>
            <p className="mt-1 text-ink-soft">{story.classification.reason}</p>
          </div>
          <div className="flex shrink-0 items-center gap-2">
            <CategoryChip category={story.classification.category} />
            <StatusBadge status={verdict.status} />
            {story.resolved && (
              <span className="rounded-md border border-green-200 bg-ok-soft px-2.5 py-0.5 text-sm font-bold text-ok">
                RESOLVED ✓
              </span>
            )}
          </div>
        </div>
        <pre className="mt-4 max-h-40 overflow-auto rounded-lg bg-slate-50 p-4 font-mono text-sm whitespace-pre-wrap text-ink-soft">
          {story.body}
        </pre>
        <ol className="mt-4 flex flex-wrap gap-2 text-sm font-semibold">
          {story.steps.map((step, index) => (
            <li key={index} className="rounded-md bg-primary-soft px-3 py-1 text-primary">
              {step.stage}: {step.decision}
            </li>
          ))}
        </ol>
      </div>

      {story.attachments.length > 0 && (
        <div className="grid gap-6 md:grid-cols-2">
          {story.attachments.map((attachment) => (
            <div key={attachment.path} className="rounded-xl border border-line bg-card p-5 shadow-sm">
              <div className="mb-3 flex items-center justify-between">
                <h3 className="font-bold">
                  {attachment.kind} · <span className="font-mono text-sm text-ink-soft">{attachment.path.split('/').pop()}</span>
                </h3>
                {attachment.scanned && (
                  <span className="rounded bg-review-soft px-2 py-0.5 text-xs font-bold text-review">SCAN</span>
                )}
              </div>
              <AnchorLines attachment={attachment} field={highlightField} />
            </div>
          ))}
        </div>
      )}

      {story.comparison && (
        <div className="rounded-xl border border-line bg-card p-6 shadow-sm">
          <h3 className="mb-4 text-lg font-bold">SI vs draft BL — the seven fields</h3>
          <div className="space-y-2">
            {Object.entries(story.comparison).map(([field, pair]) => {
              return (
                <div
                  key={field}
                  onMouseEnter={() => setHighlightField(field)}
                  onMouseLeave={() => setHighlightField(null)}
                  className={`grid grid-cols-[1fr_2fr_2fr] items-center gap-4 rounded-lg px-4 py-2 ${
                    pair.match === false ? 'bg-mismatch-soft' : pair.match === null ? 'bg-review-soft' : 'bg-ok-soft'
                  }`}
                >
                  <span className="text-sm font-bold">{FIELD_LABELS[field] ?? field}</span>
                  <span className="truncate font-mono text-sm">{pair.si || '—'}</span>
                  <span className={`truncate font-mono text-sm ${pair.match === false ? 'font-bold text-mismatch' : ''}`}>
                    {pair.bl || '—'}
                  </span>
                </div>
              )
            })}
          </div>
        </div>
      )}

      <div className={`rounded-xl border p-6 shadow-sm ${verdict.status === 'OK' ? 'border-green-200 bg-ok-soft' : verdict.status === 'MISMATCH' ? 'border-rose-200 bg-mismatch-soft' : 'border-amber-200 bg-review-soft'}`}>
        <div className="text-2xl font-extrabold">Verdict: {verdict.status}</div>
        <p className="mt-1 font-semibold">{verdict.detail}</p>
        <p className="mt-1 text-sm">decided by {verdict.decided_by}{verdict.review_reason ? ` · escalation: ${verdict.review_reason}` : ''}</p>
      </div>

      {verdict.status === 'MISMATCH' && (
        <ResolvePanel key={story.email_id} story={story} onResolved={() => setReloadKey((key) => key + 1)} />
      )}
    </div>
  )
}

import { useEffect, useState } from 'react'
import type {
  EmailList,
  EmailSummary,
  Overview,
  ResolveLogEntry,
} from '../lib/api'
import { api, apiPost } from '../lib/api'
import { useApp } from '../app/shell'
import { CategoryChip, StatCard, StatusBadge } from '../components/ui'

const CATEGORY_COLORS = ['#2563eb', '#6366f1', '#8b5cf6', '#94a3b8', '#f43f5e']

/** Locale-neutral short label for a resolved_at timestamp. */
function formatSentAt(resolvedAt: string | null): string {
  if (!resolvedAt) return '—'
  const date = new Date(resolvedAt)
  return Number.isNaN(date.getTime()) ? resolvedAt : date.toLocaleString()
}

export function OverviewPage() {
  const { openStory } = useApp()
  const [overview, setOverview] = useState<Overview | null>(null)
  // True from the start: the mount effect kicks off the first fetch.
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [mismatches, setMismatches] = useState<EmailSummary[] | null>(null)
  const [resolvedList, setResolvedList] = useState<EmailSummary[] | null>(null)
  const [resolveLog, setResolveLog] = useState<Map<string, ResolveLogEntry>>(new Map())
  const [resetting, setResetting] = useState(false)

  function fetchOverview() {
    api<Overview>('/overview')
      .then(setOverview)
      .catch((err: Error) => setError(err.message))
      .finally(() => setLoading(false))
  }

  // User-triggered retry (button / after a trail reset): reset the UI state
  // synchronously here in the event, then fetch.
  function rerun() {
    setLoading(true)
    setError(null)
    fetchOverview()
  }

  function loadLists() {
    api<EmailList>('/emails?subset=all')
      .then((list) => {
        setMismatches(
          list.emails.filter((email) => email.status === 'MISMATCH' && !email.resolved),
        )
        setResolvedList(
          list.emails
            .filter((email) => email.resolved)
            .sort((a, b) => (b.resolved_at ?? '').localeCompare(a.resolved_at ?? '')),
        )
      })
      .catch(() => {
        setMismatches([])
        setResolvedList([])
      })
    api<{ count: number; entries: ResolveLogEntry[] }>('/resolve/log')
      .then((log) => setResolveLog(new Map(log.entries.map((entry) => [entry.email_id, entry]))))
      .catch(() => setResolveLog(new Map()))
  }

  // Initial fetch: kick off the (async) loaders on mount. The setState calls
  // all happen in promise callbacks, never synchronously in the effect.
  useEffect(() => {
    fetchOverview()
    loadLists()
  }, [])

  async function resetTrail() {
    setResetting(true)
    try {
      await apiPost('/resolve/reset', {})
      loadLists()
      rerun()
    } finally {
      setResetting(false)
    }
  }

  if (!overview) {
    return (
      <div className="flex flex-col items-center gap-6 py-24">
        <p className="text-2xl font-semibold text-ink-soft">
          {loading
            ? 'Running the pipeline over the inbox…'
            : error ?? 'The dashboard is empty until the pipeline runs.'}
        </p>
        <button
          type="button"
          onClick={rerun}
          disabled={loading}
          className="rounded-xl bg-primary px-10 py-4 text-2xl font-bold text-white shadow-md transition hover:bg-blue-700 disabled:opacity-60"
        >
          {loading ? 'Running…' : '▶ Run pipeline'}
        </button>
        {error && <p className="text-ink-soft">Is the api/ server up? (uv run uvicorn api.app:app)</p>}
      </div>
    )
  }

  const { measured_scores: scores } = overview
  const maxCategory = Math.max(...Object.values(overview.category_distribution))

  return (
    <div className="space-y-10">
      <section>
        <h2 className="mb-4 text-xl font-bold tracking-wide text-ink-soft uppercase">
          Measured scores (this run)
        </h2>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          <StatCard value={scores.stage1_macro_f1.toFixed(3)} label="Stage-1 macro-F1" />
          <StatCard value={scores.stage3_defect_f1.toFixed(3)} label="Stage-3 defect-F1" />
          <StatCard value={scores.end_to_end.toFixed(3)} label="End-to-end" />
          <StatCard value={scores.final_score.toFixed(4)} label="Final score" accent="#2563eb" />
        </div>
        <p className="mt-2 text-sm text-ink-soft">Measured {scores.measured_on}.</p>
      </section>

      <section>
        <h2 className="mb-4 text-xl font-bold tracking-wide text-ink-soft uppercase">
          The run at a glance
        </h2>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-5">
          <StatCard value={overview.total_emails} label="Emails processed" />
          <StatCard value={overview.category_distribution.BL_COMPARISON} label="Document checks" accent="#2563eb" />
          <StatCard
            value={overview.status_distribution.MISMATCH}
            label="Mismatches open"
            accent="#be123c"
          />
          <StatCard
            value={overview.status_distribution.NEEDS_REVIEW}
            label="Escalated to human"
            accent="#b45309"
          />
          <StatCard
            value={overview.status_distribution.RESOLVED}
            label="Resolved ✓"
            accent="#15803d"
          />
        </div>
      </section>

      <section className="grid gap-8 md:grid-cols-2">
        <div className="rounded-xl border border-line bg-card p-6 shadow-sm">
          <h3 className="mb-4 text-lg font-bold">Category distribution</h3>
          <div className="space-y-3">
            {Object.entries(overview.category_distribution).map(([category, count], index) => (
              <div key={category}>
                <div className="mb-1 flex justify-between text-sm font-semibold">
                  <span>{category.replace(/_/g, ' ')}</span>
                  <span>{count}</span>
                </div>
                <div className="h-3 rounded-full bg-slate-100">
                  <div
                    className="h-3 rounded-full"
                    style={{
                      width: `${(count / maxCategory) * 100}%`,
                      backgroundColor: CATEGORY_COLORS[index % CATEGORY_COLORS.length],
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-xl border border-line bg-card p-6 shadow-sm">
          <h3 className="mb-4 text-lg font-bold">Escalation reasons</h3>
          <div className="space-y-3">
            {Object.entries(overview.escalation_reasons).map(([reason, count]) => (
              <div key={reason} className="flex items-center justify-between rounded-lg bg-review-soft px-4 py-2">
                <span className="font-mono text-sm font-semibold text-review">{reason}</span>
                <span className="text-xl font-extrabold text-review">{count}</span>
              </div>
            ))}
          </div>
          <h3 className="mt-6 mb-3 text-lg font-bold">Most mismatched fields</h3>
          <div className="flex flex-wrap gap-2">
            {Object.entries(overview.defects.field_counts).map(([field, count]) => (
              <span key={field} className="rounded-md bg-mismatch-soft px-3 py-1 text-sm font-bold text-mismatch">
                {field.replace(/_/g, ' ')} · {count}
              </span>
            ))}
          </div>
        </div>
      </section>

      {resolvedList !== null && resolvedList.length > 0 && (
        <section>
          <div className="mb-4 flex items-center gap-3">
            <h2 className="text-xl font-bold tracking-wide text-ink-soft uppercase">
              Resolved
            </h2>
            <span className="rounded-md bg-ok-soft px-2.5 py-1 text-sm font-bold text-ok">
              {resolvedList.length}
            </span>
            <button
              type="button"
              onClick={resetTrail}
              disabled={resetting}
              className="ml-auto rounded-lg border border-line bg-card px-4 py-2 text-sm font-semibold text-ink-soft transition hover:bg-mismatch-soft hover:text-mismatch disabled:opacity-50"
            >
              {resetting ? 'Resetting…' : 'Reset trail'}
            </button>
          </div>
          <div className="overflow-hidden rounded-xl border border-green-200 bg-card shadow-sm">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b border-line bg-slate-50 text-sm font-bold tracking-wide text-ink-soft uppercase">
                  <th className="px-5 py-3">Email</th>
                  <th className="px-5 py-3">Sent at</th>
                  <th className="px-5 py-3">Resolved values</th>
                  <th className="px-5 py-3">Delivery</th>
                </tr>
              </thead>
              <tbody>
                {resolvedList.map((email) => {
                  const entry = resolveLog.get(email.email_id)
                  return (
                    <tr
                      key={email.email_id}
                      onClick={() => openStory(email.email_id)}
                      className="cursor-pointer border-b border-line/60 transition last:border-0 hover:bg-primary-soft"
                    >
                      <td className="px-5 py-3">
                        <div className="font-mono text-sm font-bold text-primary">{email.email_id}</div>
                        <div className="max-w-md truncate text-base">{email.subject}</div>
                      </td>
                      <td className="px-5 py-3 text-sm font-semibold">
                        {formatSentAt(email.resolved_at)}
                        {entry?.sandboxed && (
                          <span className="ml-2 rounded bg-review-soft px-2 py-0.5 text-xs font-bold text-review">
                            SANDBOX
                          </span>
                        )}
                      </td>
                      <td className="px-5 py-3 text-sm">
                        {entry && Object.keys(entry.resolutions).length > 0
                          ? Object.entries(entry.resolutions)
                              .map(
                                ([field, resolution]) =>
                                  `${field.replace(/_/g, ' ')}: ${resolution.value ?? `(${resolution.choice})`}`,
                              )
                              .join(', ')
                          : '—'}
                      </td>
                      <td className="px-5 py-3 font-mono text-sm text-ink-soft">
                        {entry?.recipient ?? '—'}
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </section>
      )}

      <section>
        <div className="mb-4 flex items-center gap-3">
          <h2 className="text-xl font-bold tracking-wide text-ink-soft uppercase">
            Mismatch overview
          </h2>
          <span className="rounded-md bg-mismatch-soft px-2.5 py-1 text-sm font-bold text-mismatch">
            {mismatches?.length ?? '…'}
          </span>
        </div>
        {mismatches === null ? (
          <p className="text-lg text-ink-soft">Loading mismatches…</p>
        ) : mismatches.length === 0 ? (
          <p className="rounded-xl border border-line bg-card px-5 py-6 text-lg text-ink-soft">
            No unresolved mismatches — the inbox is clean.
          </p>
        ) : (
          <div className="overflow-hidden rounded-xl border border-line bg-card shadow-sm">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b border-line bg-slate-50 text-sm font-bold tracking-wide text-ink-soft uppercase">
                  <th className="px-5 py-3">Email</th>
                  <th className="px-5 py-3">Category</th>
                  <th className="px-5 py-3">Status</th>
                  <th className="px-5 py-3">Defect fields</th>
                </tr>
              </thead>
              <tbody>
                {mismatches.map((email) => (
                  <tr
                    key={email.email_id}
                    onClick={() => openStory(email.email_id)}
                    className="cursor-pointer border-b border-line/60 transition last:border-0 hover:bg-primary-soft"
                  >
                    <td className="px-5 py-3">
                      <div className="font-mono text-sm font-bold text-primary">{email.email_id}</div>
                      <div className="max-w-md truncate text-base">{email.subject}</div>
                    </td>
                    <td className="px-5 py-3"><CategoryChip category={email.category} /></td>
                    <td className="px-5 py-3"><StatusBadge status={email.status} /></td>
                    <td className="px-5 py-3 text-sm">
                      {email.defect_fields.length
                        ? email.defect_fields.map((field) => field.replace(/_/g, ' ')).join(', ')
                        : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  )
}

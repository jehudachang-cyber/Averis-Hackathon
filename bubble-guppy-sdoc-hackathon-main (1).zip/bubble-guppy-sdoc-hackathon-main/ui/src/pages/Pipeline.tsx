import { useEffect, useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import type { EmailSummary, Story } from '../lib/api'
import { fetchStoryCached } from '../lib/api'
import { useApp } from '../app/shell'
import { SubsetSelector } from '../components/ui'
import {
  ActAttachmentOpen,
  ActCompareBoard,
  ActEmailFocus,
  ActInboxCascade,
  ActVerdict,
} from '../components/cinema/Cinema'

const PAGE_SIZE = 24

const STAGES = [
  'Classify Emails',
  'Read Email',
  'Open Attachments',
  'Comparison',
  'Verdict + scoreboard',
] as const

/**
 * Load one page's stories (≤24) through the session story cache. Returns the
 * stories in the same order as `summaries`; [] while the page is in flight.
 */
function usePageStories(summaries: EmailSummary[]): Story[] {
  const [stories, setStories] = useState<Story[]>([])

  useEffect(() => {
    // No synchronous setState: keep the previous page's stories rendered while
    // the new page's (usually cached) fetches settle — the effect only clears
    // stale async results via `cancelled`.
    if (summaries.length === 0) return
    let cancelled = false
    Promise.all(summaries.map((summary) => fetchStoryCached(summary.email_id)))
      .then((loaded) => {
        if (!cancelled) setStories(loaded)
      })
      .catch(() => {
        if (!cancelled) setStories([])
      })
    return () => {
      cancelled = true
    }
    // summaries is a slice of a memoized array — identity is stable per page.
  }, [summaries])

  return stories
}

export function PipelinePage() {
  const { subset, setSubset, emails } = useApp()
  const [current, setCurrent] = useState(0)
  const [act, setAct] = useState(0)
  const [page, setPage] = useState(0)
  // Reset view state when the subset changes — derived from render, not an
  // effect, so the first render after a subset switch is already correct.
  const [resetKey, setResetKey] = useState(subset)
  if (resetKey !== subset) {
    setResetKey(subset)
    setPage(0)
    setCurrent(0)
    setAct(0)
  }

  // The email list is already subset-filtered and shared with Browse by the
  // shell — reuse it instead of refetching, and slice out only the current
  // page. Pagination + the cascade grid need just summaries; full stories are
  // fetched for exactly this page's ≤24 emails, once per session (cache).
  const pageSummaries = useMemo(
    () => (emails?.emails ?? []).slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE),
    [emails, page],
  )
  const pageCount = Math.ceil((emails?.emails.length ?? 0) / PAGE_SIZE)
  const pageStories = usePageStories(pageSummaries)

  const story = useMemo(() => pageStories[current], [pageStories, current])

  // Stage list adapts to the story: "Open Attachments" only when the email
  // has attachments, "Comparison" only when there is an SI/BL verdict table
  // (invoice queries and no-document send requests like email_003 skip both;
  // NEEDS_REVIEW cases keep attachments but skip the comparison).
  const activeActs = useMemo(() => {
    if (!story) return [0, 1, 2, 3, 4]
    const acts = [0, 1]
    if (story.attachments.length) acts.push(2)
    if (story.comparison) acts.push(3)
    acts.push(4)
    return acts
  }, [story])

  // Loading while the shell's email list is in flight, or while this page's
  // stories have not resolved yet (a fresh page or an all-failed fetch).
  const loading =
    emails === null || (story === undefined && pageSummaries.length > 0)

  // Act 1 (cascade) is interactive; acts 2-5 show detail views.

  if (loading) {
    return <p className="py-24 text-center text-2xl text-ink-soft">Loading the cast…</p>
  }
  if (!story) {
    return (
      <p className="py-24 text-center text-2xl text-ink-soft">
        No stories available — is the api/ bridge running?
      </p>
    )
  }

  return (
    <div className="space-y-6">
      {/* subset selector (decision #9) — shared with Browse */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <SubsetSelector subset={subset} onChange={setSubset} />
      </div>

      {/* act rail */}
      <div className="flex flex-wrap items-center gap-2">
        {activeActs.map((actIndex, position) => (
          <button
            key={STAGES[actIndex]}
            type="button"
            onClick={() => setAct(actIndex)}
            className={`rounded-full px-3 py-1 text-sm font-bold transition ${
              act === actIndex
                ? 'bg-ink text-white'
                : actIndex < act
                  ? 'bg-primary-soft text-primary'
                  : 'bg-card text-ink-soft'
            }`}
          >
            {position + 1}. {STAGES[actIndex]}
          </button>
        ))}
        {act !== 0 && (
          <span className="ml-auto flex items-center gap-2">
            <div className="w-px h-6 bg-line" />
            <button
              type="button"
              onClick={() => {
                const position = activeActs.indexOf(act)
                if (position > 0) setAct(activeActs[position - 1])
              }}
              className="rounded-lg border border-line bg-card px-4 py-2 font-semibold text-ink-soft transition hover:bg-primary-soft"
            >
              ⏮ Stage
            </button>
            <button
              type="button"
              onClick={() => {
                const position = activeActs.indexOf(act)
                setAct(activeActs[(position + 1) % activeActs.length])
              }}
              className="rounded-lg bg-card px-4 py-2 font-semibold text-ink-soft transition hover:bg-primary-soft"
            >
              Stage ⏭
            </button>
          </span>
        )}
      </div>

      {/* the stage */}
      <div className="min-h-[420px]">
        <AnimatePresence mode="wait">
          <motion.div
            key={`${story.email_id}-${act}`}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -16 }}
            transition={{ duration: 0.35 }}
          >
            {act === 0 && (
              <ActInboxCascade
                stories={pageStories}
                onPick={(emailId) => {
                  const index = pageStories.findIndex((item) => item.email_id === emailId)
                  setCurrent(index)
                  setAct(1)
                }}
              />
            )}
            {act === 1 && <ActEmailFocus story={story} />}
            {act === 2 && <ActAttachmentOpen story={story} />}
            {act === 3 && <ActCompareBoard story={story} />}
            {act === 4 && (
              <ActVerdict story={story} finalScore={1.0} />
            )}
          </motion.div>
        </AnimatePresence>
      </div>

      {act === 0 && pageCount > 1 && (
        <div className="flex items-center justify-center gap-1.5 flex-wrap">
          {Array.from({ length: pageCount }, (_, i) => (
            <button
              key={i}
              type="button"
              onClick={() => {
                setPage(i)
                setCurrent(0)
              }}
              className={`rounded-lg px-3 py-1 text-sm font-semibold transition ${
                page === i
                  ? 'bg-primary text-white'
                  : 'border border-line bg-card text-ink-soft hover:bg-primary-soft'
              }`}
            >
              {i + 1}
            </button>
          ))}
        </div>
      )}
      {act === 0 && (
        <p className="text-center text-sm text-ink-soft">
          Click any email card to open it!
        </p>
      )}
      <p className="text-center text-sm text-ink-soft/60">
        This pipeline visualisation demonstrates the backend processing stages.
        <br />
        It is included for transparency and audit trail purposes; end-users will primarily use the Overview and Browse views.
      </p>
    </div>
  )
}

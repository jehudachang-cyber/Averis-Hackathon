import { AnimatePresence, motion } from 'framer-motion'
import { useEffect, useState } from 'react'
import type { Story } from '../../lib/api'
import { FIELD_LABELS } from '../../lib/api'
import { CategoryChip } from '../ui'
import { ScanAwait } from './ScanAwait'

/* ---------------------------------- act 1 --------------------------------- */
export function ActInboxCascade({
  stories,
  onPick,
}: {
  stories: Story[]
  onPick: (emailId: string) => void
}) {
  return (
    <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
      {stories.map((story, index) => (
        <motion.button
          key={story.email_id}
          type="button"
          initial={{ opacity: 0, y: 40, rotate: -2 }}
          animate={{ opacity: 1, y: 0, rotate: 0 }}
          transition={{ delay: index * 0.12, type: 'spring', stiffness: 120, damping: 14 }}
          whileHover={{ scale: 1.04 }}
          onClick={() => onPick(story.email_id)}
          className="rounded-xl border border-line bg-card p-4 text-left shadow-sm"
        >
          <div className="flex items-center justify-between">
            <span className="font-mono text-xs font-bold text-primary">{story.email_id}</span>
            {story.classification.category === 'SPAM' && (
              <motion.span
                initial={{ scale: 2.2, opacity: 0, rotate: -18 }}
                animate={{ scale: 1, opacity: 1, rotate: -12 }}
                transition={{ delay: 0.3 + index * 0.12 }}
                className="rounded border-2 border-rose-500 px-1.5 py-0.5 text-[10px] font-black tracking-widest text-rose-600 uppercase"
              >
                Spam
              </motion.span>
            )}
          </div>
          <div className="mt-1 line-clamp-2 text-sm font-semibold">{story.subject}</div>
          <div className="mt-2">
            <CategoryChip category={story.classification.category} />
          </div>
        </motion.button>
      ))}
    </div>
  )
}

/* ---------------------------------- act 2 --------------------------------- */
export function ActEmailFocus({ story }: { story: Story }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="rounded-xl border border-line bg-card p-6 shadow-md"
    >
      <div className="font-mono text-sm font-bold text-primary">{story.email_id}</div>
      <h3 className="mt-1 text-2xl font-bold">{story.subject}</h3>
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="mt-3 max-h-64 overflow-auto rounded-lg bg-slate-50 p-3 font-mono text-sm whitespace-pre-wrap"
      >
        {story.body}
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
        className="mt-3 flex items-center gap-3"
      >
        <CategoryChip category={story.classification.category} />
        <span className="text-sm font-semibold text-ink-soft">
          {story.classification.reason} · confidence{' '}
          {story.classification.confidence?.toFixed(2) ?? '—'}
        </span>
      </motion.div>
    </motion.div>
  )
}

/* ---------------------------------- act 3 --------------------------------- */
export function ActAttachmentOpen({ story }: { story: Story }) {
  const [ocrDone, setOcrDone] = useState(false)
  const hasScan = story.attachments.some((attachment) => attachment.scanned)
  useEffect(() => {
    if (!hasScan) return
    // The ≥1s pixelation beat (decision #13). The parent mounts this act with
    // key={`${story.email_id}-${act}`}, so ocrDone starts false per email —
    // no synchronous reset needed here.
    const timer = setTimeout(() => setOcrDone(true), 1400)
    return () => clearTimeout(timer)
  }, [story.email_id, hasScan])

  return (
    <div className="grid gap-4 md:grid-cols-2">
      {story.attachments.map((attachment, index) => (
        <motion.div
          key={attachment.path}
          initial={{ opacity: 0, x: index === 0 ? -60 : 60 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: index * 0.2, type: 'spring', stiffness: 90 }}
          className="relative overflow-hidden rounded-xl border border-line bg-card p-4 shadow-sm"
        >
          <div className="mb-2 flex items-center justify-between">
            <span className="text-lg font-bold">{attachment.kind}</span>
            {attachment.scanned && !ocrDone && (
              <motion.span
                animate={{ opacity: [1, 0.4, 1] }}
                transition={{ repeat: Infinity, duration: 0.9 }}
                className="rounded bg-review-soft px-2 py-0.5 text-xs font-bold text-review"
              >
                OCR transcribing…
              </motion.span>
            )}
          </div>
          <div className="relative max-h-112 overflow-auto rounded-lg bg-slate-50 p-3 font-mono text-sm leading-6">
            {attachment.lines.map((line, lineIndex) => (
              <div key={lineIndex}>{line || ' '}</div>
            ))}
            {attachment.scanned && <ScanAwait done={ocrDone} />}
          </div>
        </motion.div>
      ))}
    </div>
  )
}

/* ---------------------------------- act 4 --------------------------------- */
export function ActCompareBoard({ story }: { story: Story }) {
  if (!story.comparison) return null
  return (
    <div className="space-y-2">
      <div className="grid grid-cols-[1fr_2fr_2fr] items-center gap-4 px-4 text-xs font-bold tracking-wide text-ink-soft uppercase">
        <span>Field</span>
        <span>SI (Shipping Instruction)</span>
        <span>BL (draft Bill of Lading)</span>
      </div>
      {Object.entries(story.comparison).map(([field, pair], index) => (
        <motion.div
          key={field}
          initial={{ opacity: 0, x: -30 }}
          animate={
            pair.match === false
              ? { opacity: 1, x: [0, -8, 8, -5, 5, 0] } // mismatch shake
              : { opacity: 1, x: 0 }
          }
          transition={{ delay: index * 0.15, duration: pair.match === false ? 0.5 : 0.3 }}
          className={`grid grid-cols-[1fr_2fr_2fr] items-center gap-4 rounded-lg px-4 py-2 ${
            pair.match === false
              ? 'bg-mismatch-soft ring-2 ring-rose-300'
              : 'bg-ok-soft'
          }`}
        >
          <span className="text-sm font-bold">{FIELD_LABELS[field] ?? field}</span>
          <span className="truncate font-mono text-sm">{pair.si || '—'}</span>
          <span className={`truncate font-mono text-sm ${pair.match === false ? 'font-black text-mismatch' : ''}`}>
            {pair.match === false ? '⚠ ' : ''}
            {pair.bl || '—'}
          </span>
        </motion.div>
      ))}
    </div>
  )
}

/* ---------------------------------- act 5 --------------------------------- */
function CountUp({ value, decimals = 0 }: { value: number; decimals?: number }) {
  const [shown, setShown] = useState(0)
  useEffect(() => {
    const start = performance.now()
    let frame: number
    const tick = (now: number) => {
      const progress = Math.min((now - start) / 1200, 1)
      setShown(value * (1 - Math.pow(1 - progress, 3)))
      if (progress < 1) frame = requestAnimationFrame(tick)
    }
    frame = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(frame)
  }, [value])
  return <>{shown.toFixed(decimals)}</>
}

export function ActVerdict({ story, finalScore }: { story: Story; finalScore: number }) {
  // Invoice queries have no SI/BL verdict to report — a friendlier line reads
  // better than a bare "Verdict: OK" on stage.
  const isInvoice = story.classification.category === 'INVOICE_QUERY'
  const tone =
    isInvoice
      ? 'border-blue-200 bg-primary-soft text-primary'
      : story.verdict.status === 'OK'
        ? 'border-green-200 bg-ok-soft text-ok'
        : story.verdict.status === 'MISMATCH'
          ? 'border-rose-200 bg-mismatch-soft text-mismatch'
          : 'border-amber-200 bg-review-soft text-review'
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ type: 'spring', stiffness: 140, damping: 14 }}
      className={`rounded-xl border p-6 ${tone}`}
    >
      <div className="text-3xl font-black">
        {isInvoice ? 'Nothing to verify here' : `Verdict: ${story.verdict.status}`}
      </div>
      <p className="mt-1 font-semibold">
        {isInvoice
          ? 'This is a routine invoice query — the pipeline read it, no documents needed checking, nothing to do.'
          : story.verdict.detail}
      </p>
      {!isInvoice && (
        <p className="mt-1 text-sm">
          decided by {story.verdict.decided_by}
          {story.verdict.review_reason ? ` · escalation: ${story.verdict.review_reason}` : ''}
        </p>
      )}
      <AnimatePresence>
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="mt-4 flex items-baseline gap-3 border-t border-current/20 pt-3"
        >
          <span className="text-lg font-bold tracking-wide uppercase">Final score</span>
          <span className="text-5xl font-black tabular-nums">
            <CountUp value={finalScore} decimals={4} />
          </span>
        </motion.div>
      </AnimatePresence>
    </motion.div>
  )
}

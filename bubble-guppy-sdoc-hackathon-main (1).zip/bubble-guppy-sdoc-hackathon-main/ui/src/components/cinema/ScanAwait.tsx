import { motion } from 'framer-motion'

/**
 * Pixelated "OCR working" treatment for scanned documents (decision #2/#13).
 * The document sits pixelated/blurred while the engine transcribes, then
 * sharpens. A minimum duration keeps the effect readable on stage.
 */
export function ScanAwait({ done }: { done: boolean }) {
  return (
    <motion.div
      aria-hidden
      className="pointer-events-none absolute inset-0 rounded-lg"
      initial={{ opacity: 1 }}
      animate={{
        opacity: done ? 0 : 1,
        backdropFilter: done ? 'blur(0px)' : 'blur(2px)',
      }}
      transition={{ duration: done ? 0.6 : 0.2 }}
      style={{
        backgroundImage:
          'conic-gradient(from 90deg at 1px 1px, #0f1720 25%, #1e293b 0)',
        backgroundSize: done ? '2px 2px' : '8px 8px',
        mixBlendMode: 'multiply',
        opacity: 0.35,
      }}
    />
  )
}

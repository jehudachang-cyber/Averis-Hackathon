import { Fragment } from 'react'
import type { ReactNode } from 'react'

/** Inline markdown (**bold**, `code`) → React nodes; everything else escapes. */
function inline(text: string): ReactNode[] {
  const tokens = text.split(/(\*\*.+?\*\*|`[^`]+?`)/g)
  return tokens.map((token, index) => {
    if (token.startsWith('**') && token.endsWith('**') && token.length >= 4) {
      return <strong key={index}>{token.slice(2, -2)}</strong>
    }
    if (token.startsWith('`') && token.endsWith('`') && token.length >= 2) {
      return <code key={index}>{token.slice(1, -1)}</code>
    }
    return <Fragment key={index}>{token}</Fragment>
  })
}

/** Trim one `| a | b |` table line into cells. */
function splitRow(line: string): string[] {
  return line
    .trim()
    .replace(/^\|/, '')
    .replace(/\|$/, '')
    .split('|')
    .map((cell) => cell.trim())
}

const SEPARATOR = /^:?-+:?$/

/** Render the correction-email markdown subset (issue 68): tables, bold,
 * code, paragraphs. Text other than the recognised spans is plain — the
 * source body is trusted but the values it embeds are user-typed, so nothing
 * is ever rendered as raw HTML.
 */
export function Markdown({ text }: { text: string }) {
  const blocks = text.trim().split(/\n\s*\n/)
  return (
    <div className="space-y-2">
      {blocks.map((block, blockIndex) => {
        const lines = block.split('\n').filter((line) => line.trim())
        if (lines.length === 0) return null
        const isTable = lines.every(
          (line) => line.trim().startsWith('|') && line.trim().endsWith('|'),
        )
        if (isTable) {
          const rows = lines.map(splitRow)
          let header: string[] | null = null
          let body = rows
          if (rows.length >= 2 && rows[1].every((cell) => SEPARATOR.test(cell))) {
            header = rows[0]
            body = rows.slice(2)
          }
          return (
            <table
              key={blockIndex}
              className="w-full border-collapse overflow-hidden rounded-lg text-sm"
            >
              {header !== null && (
                <thead>
                  <tr>
                    {header.map((cell, cellIndex) => (
                      <th
                        key={cellIndex}
                        className="border border-line bg-slate-50 px-3 py-1.5 text-left font-bold"
                      >
                        {inline(cell)}
                      </th>
                    ))}
                  </tr>
                </thead>
              )}
              <tbody>
                {body.map((row, rowIndex) => (
                  <tr key={rowIndex}>
                    {row.map((cell, cellIndex) => (
                      <td key={cellIndex} className="border border-line px-3 py-1.5 align-top">
                        {inline(cell)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          )
        }
        return (
          <p key={blockIndex} className="text-sm leading-relaxed text-ink-soft">
            {inline(lines.join(' '))}
          </p>
        )
      })}
    </div>
  )
}
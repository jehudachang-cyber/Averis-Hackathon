import type { Category, Status, Subset } from '../lib/api'

const SUBSETS: { id: Subset; label: string }[] = [
  { id: 'showcase', label: 'Showcase' },
  { id: 'bl_comparison', label: 'BL Comparison' },
  { id: 'all', label: 'All emails' },
]

/** Subset picker shared by Pipeline and Browse; selection lives in the app
 * shell, so both pages always see (and change) the same subset. */
export function SubsetSelector({
  subset,
  onChange,
}: {
  subset: Subset
  onChange: (subset: Subset) => void
}) {
  return (
    <div className="flex flex-wrap gap-2">
      {SUBSETS.map(({ id, label }) => (
        <button
          key={id}
          type="button"
          onClick={() => onChange(id)}
          className={`rounded-lg px-4 py-2 text-base font-semibold transition ${
            subset === id
              ? 'bg-primary text-white shadow'
              : 'bg-card text-ink-soft hover:bg-primary-soft hover:text-primary'
          }`}
        >
          {label}
        </button>
      ))}
    </div>
  )
}

const CATEGORY_LABELS: Record<Category, string> = {
  BL_COMPARISON: 'BL Comparison',
  SI_REQUEST: 'SI Request',
  INVOICE_QUERY: 'Invoice Query',
  GENERAL: 'General',
  SPAM: 'Spam',
}

export function CategoryChip({ category }: { category: Category }) {
  const styles: Record<Category, string> = {
    BL_COMPARISON: 'bg-primary-soft text-primary border-blue-200',
    SI_REQUEST: 'bg-indigo-50 text-indigo-700 border-indigo-200',
    INVOICE_QUERY: 'bg-violet-50 text-violet-700 border-violet-200',
    GENERAL: 'bg-slate-100 text-slate-600 border-slate-200',
    SPAM: 'bg-rose-50 text-rose-600 border-rose-200',
  }
  return (
    <span
      className={`inline-block rounded-full border px-3 py-0.5 text-sm font-semibold ${styles[category]}`}
    >
      {CATEGORY_LABELS[category]}
    </span>
  )
}

export function StatusBadge({ status }: { status: Status }) {
  const styles: Record<Status, string> = {
    OK: 'bg-ok-soft text-ok border-green-200',
    MISMATCH: 'bg-mismatch-soft text-mismatch border-rose-200',
    NEEDS_REVIEW: 'bg-review-soft text-review border-amber-200',
  }
  const labels: Record<Status, string> = {
    OK: 'OK',
    MISMATCH: 'Mismatch',
    NEEDS_REVIEW: 'Needs review',
  }
  return (
    <span
      className={`inline-block rounded-md border px-2.5 py-0.5 text-sm font-bold ${styles[status]}`}
    >
      {labels[status]}
    </span>
  )
}

export function StatCard({
  value,
  label,
  accent,
}: {
  value: string | number
  label: string
  accent?: string
}) {
  return (
    <div className="rounded-xl border border-line bg-card p-6 text-center shadow-sm transition hover:-translate-y-0.5 hover:border-blue-300 hover:shadow-md">
      <div className="text-4xl font-extrabold" style={accent ? { color: accent } : undefined}>
        {value}
      </div>
      <div className="mt-1 text-sm font-bold tracking-wide text-ink-soft uppercase">
        {label}
      </div>
    </div>
  )
}

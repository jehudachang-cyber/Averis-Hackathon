import { useEffect, useMemo, useRef, useState } from 'react'
import type {
  ResolveChoice,
  ResolvePreview,
  ResolveSendRequest,
  ResolveSendResult,
  Story,
} from '../lib/api'
import { FIELD_LABELS, apiPost } from '../lib/api'
import { Markdown } from './Markdown'

/** Fields that always need an explicit confirm (title-document consequences). */
const RISKY_FIELDS = new Set([
  'consignee',
  'notify_party',
  'port_of_loading',
  'port_of_discharge',
])

type Phase = 'form' | 'preview' | 'sent'

interface FieldChoice {
  choice: ResolveChoice
  manual: string
}

function defaultChoices(story: Story): Record<string, FieldChoice> {
  const choices: Record<string, FieldChoice> = {}
  for (const field of story.verdict.defect_fields) {
    choices[field] = { choice: 'si', manual: '' }
  }
  return choices
}

/** Per-field resolution UI for MISMATCH stories (issue 51).
 *
 * Each defect field shows three selectable rows — SI value (pre-selected),
 * BL value, and an inline corrected-value input. The selected row is
 * highlighted green; focusing the corrected input switches to 'manual'.
 * Risky fields (consignee/notify party/ports) require an explicit confirm
 * checkbox before the send is enabled; the preview shows exactly where the
 * email will land (sandbox vs counterparty).
 */
/** Locale-neutral short label for a resolved_at timestamp. */
function formatSentAt(resolvedAt: string | null): string {
  if (!resolvedAt) return 'just now'
  const date = new Date(resolvedAt)
  return Number.isNaN(date.getTime()) ? resolvedAt : date.toLocaleString()
}

export function ResolvePanel({
  story,
  onResolved,
}: {
  story: Story
  /** Issue 78: refresh the story after a send — the overlay turns terminal. */
  onResolved: () => void
}) {
  const [choices, setChoices] = useState<Record<string, FieldChoice>>(() =>
    defaultChoices(story),
  )
  const manualRefs = useRef<Record<string, HTMLInputElement | null>>({})
  const [phase, setPhase] = useState<Phase>('form')
  const [explicitConfirm, setExplicitConfirm] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const [preview, setPreview] = useState<ResolvePreview | null>(null)
  const [sent, setSent] = useState<ResolveSendResult | null>(null)

  const defectFields = story.verdict.defect_fields
  // Reset the form when the story changes — derived in render (no
  // setState-in-effect). Browse mounts this panel with key={story.email_id},
  // so `story` is stable for a mount in practice; the guard also covers
  // direct reuse without a fresh key.
  const [lastStory, setLastStory] = useState(story)
  if (lastStory !== story) {
    setLastStory(story)
    setChoices(defaultChoices(story))
    setPhase('form')
    setPreview(null)
    setSent(null)
    setExplicitConfirm(false)
    setError(null)
  }

  useEffect(() => {
    for (const field of defectFields) {
      if (choices[field]?.choice === 'manual') {
        manualRefs.current[field]?.focus()
      }
    }
  }, [choices, defectFields])

  const needsExplicit = useMemo(
    () => defectFields.some((field) => RISKY_FIELDS.has(field)),
    [defectFields],
  )

  const sendBlocked =
    busy || !explicitConfirm || defectFields.some((field) => choices[field]?.choice === 'manual' && !choices[field]?.manual.trim())

  function update(field: string, patch: Partial<FieldChoice>) {
    setChoices((prev) => ({ ...prev, [field]: { ...prev[field], ...patch } }))
  }

  function payload() {
    const picked: Record<string, ResolveChoice> = {}
    const overrides: Record<string, string> = {}
    for (const field of defectFields) {
      picked[field] = choices[field]?.choice ?? 'si'
      if (picked[field] === 'manual') overrides[field] = choices[field]?.manual ?? ''
    }
    return { email_id: story.email_id, choices: picked, overrides }
  }

  async function doPreview() {
    setBusy(true)
    setError(null)
    try {
      setPreview(await apiPost<ResolvePreview>('/resolve/preview', payload()))
      setPhase('preview')
    } catch (exc) {
      setError(exc instanceof Error ? exc.message : String(exc))
    } finally {
      setBusy(false)
    }
  }

  async function doSend() {
    setBusy(true)
    setError(null)
    try {
      const request: ResolveSendRequest = { ...payload(), confirmed: true }
      const result = await apiPost<ResolveSendResult>('/resolve/send', request)
      setSent(result)
      setPhase('sent')
    } catch (exc) {
      setError(exc instanceof Error ? exc.message : String(exc))
    } finally {
      setBusy(false)
    }
  }

  // Issue 78: a resolved story is terminal — no form, no re-send path.
  if (story.resolved) {
    return (
      <div className="rounded-xl border border-green-200 bg-ok-soft p-6 shadow-sm">
        <h3 className="text-lg font-bold text-ok">Resolved ✓ (sent {formatSentAt(story.resolved_at)})</h3>
        <p className="mt-2 text-sm text-ink-soft">
          The correction email is on the trail — this mismatch stays closed until the trail is reset.
        </p>
      </div>
    )
  }

  if (phase === 'sent' && sent) {
    return (
      <div className="rounded-xl border border-green-200 bg-ok-soft p-6 shadow-sm">
        <h3 className="text-lg font-bold text-ok">✅ Resolution sent</h3>
        <p className="mt-2 text-base">
          Correction email for <span className="font-mono font-bold">{sent.email_id}</span> sent to{' '}
          <span className="font-mono font-bold">{sent.recipient}</span>
          {sent.sandboxed && (
            <span className="ml-2 rounded bg-review-soft px-2 py-0.5 text-xs font-bold text-review">
              SANDBOX
            </span>
          )}
        </p>
        <p className="mt-1 text-sm text-ink-soft">
          Logged to the resolve trail — the pipeline verdict stays untouched.
        </p>
        <button
          type="button"
          onClick={onResolved}
          className="mt-4 rounded-lg bg-primary px-4 py-2 text-base font-semibold text-white shadow transition hover:opacity-90"
        >
          Done
        </button>
      </div>
    )
  }

  if (phase === 'preview' && preview) {
    return (
      <div className="space-y-4 rounded-xl border border-line bg-card p-6 shadow-sm">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold">Preview — correction email</h3>
          {preview.sandboxed ? (
            <span className="rounded bg-review-soft px-2 py-0.5 text-xs font-bold text-review">
              SANDBOX → {preview.recipient}
            </span>
          ) : (
            <span className="rounded bg-mismatch-soft px-2 py-0.5 text-xs font-bold text-mismatch">
              REAL SEND → {preview.recipient}
            </span>
          )}
        </div>
        <div className="rounded-lg border border-line bg-slate-50 p-3">
          <div className="text-sm font-bold">Subject</div>
          <div className="font-mono text-sm">{preview.subject}</div>
        </div>
        <div className="max-h-72 overflow-auto rounded-lg border border-line bg-slate-50 p-4">
          <Markdown text={preview.body} />
        </div>
        {error && <p className="text-sm font-bold text-mismatch">{error}</p>}
        <div className="flex gap-3">
          <button
            type="button"
            onClick={doSend}
            disabled={sendBlocked}
            className="rounded-lg bg-mismatch px-4 py-2 text-base font-semibold text-white shadow transition enabled:hover:opacity-90 disabled:opacity-50"
          >
            {busy ? 'Sending…' : 'Send correction email'}
          </button>
          <button
            type="button"
            onClick={() => setPhase('form')}
            className="rounded-lg bg-card px-4 py-2 text-base font-semibold text-ink-soft transition hover:bg-primary-soft hover:text-primary"
          >
            Back
          </button>
        </div>
        {sendBlocked && !busy && (
          <p className="text-sm text-ink-soft">
            {needsExplicit
              ? 'Tick the explicit confirm above to enable sending (risky fields present).'
              : 'Tick the confirm checkbox to enable sending.'}
          </p>
        )}
      </div>
    )
  }

  return (
    <div className="space-y-4 rounded-xl border border-line bg-card p-6 shadow-sm">
      <h3 className="text-lg font-bold">Resolve mismatches</h3>
      <p className="text-sm text-ink-soft">
        Pick the correct value per field — the SI value is pre-selected (green). The correction
        email is sandboxed by default (lands in the team inbox, never a counterparty).
      </p>
      <div className="space-y-3">
        {defectFields.map((field) => {
          const pair = story.comparison?.[field]
          const choice = choices[field] ?? { choice: 'si' as ResolveChoice, manual: '' }
          const risky = RISKY_FIELDS.has(field)
          return (
            <div
              key={field}
              className={`rounded-lg border p-4 ${
                risky ? 'border-amber-300 bg-review-soft' : 'border-line bg-slate-50'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-lg font-bold">{FIELD_LABELS[field] ?? field}</span>
                {risky && (
                  <span className="rounded bg-review-soft px-2 py-0.5 text-xs font-bold text-review">
                    EXPLICIT CONFIRM
                  </span>
                )}
              </div>
              <div className="mt-3 space-y-2">
                {(
                  [
                    ['si', 'SI', pair?.si || '—', false],
                    ['bl', 'BL', pair?.bl || '—', false],
                    ['manual', 'Corrected value', choices[field]?.manual ?? '', true],
                  ] as [ResolveChoice, string, string, boolean][]
                ).map(([value, label, content, isManual]) => {
                  const selected = choice.choice === value
                  const rowClass = selected
                    ? 'border-green-200 bg-ok-soft text-green-800'
                    : 'border-line bg-card text-ink-soft hover:bg-primary-soft'
                  if (isManual) {
                    return (
                      <label
                        key={value}
                        className={`flex cursor-text items-center gap-3 rounded-lg border px-3 py-2 text-base font-bold transition ${rowClass}`}
                      >
                        <input
                          type="radio"
                          name={`choice-${field}`}
                          value={value}
                          checked={selected}
                          onChange={() => update(field, { choice: value })}
                          className="sr-only"
                        />
                        <span className="shrink-0">{label}:</span>
                        <input
                          type="text"
                          ref={(el) => {
                            manualRefs.current[field] = el
                          }}
                          value={content}
                          placeholder="Enter corrected value…"
                          onFocus={() => {
                            if (choice.choice !== 'manual') update(field, { choice: 'manual' })
                          }}
                          onChange={(event) => update(field, { manual: event.target.value })}
                          className="min-w-0 flex-1 rounded-md border border-line bg-card px-2 py-1 font-mono text-base font-bold focus:border-primary focus:outline-none"
                        />
                      </label>
                    )
                  }
                  return (
                    <label
                      key={value}
                      className={`flex cursor-pointer items-center gap-3 rounded-lg border px-3 py-2 text-base font-bold transition ${rowClass}`}
                    >
                      <input
                        type="radio"
                        name={`choice-${field}`}
                        value={value}
                        checked={selected}
                        onChange={() => update(field, { choice: value })}
                        className="sr-only"
                      />
                      <span className="shrink-0">{label}:</span>
                      <span className="min-w-0 flex-1 truncate font-mono text-base font-bold">
                        {content}
                      </span>
                    </label>
                  )
                })}
              </div>
            </div>
          )
        })}
      </div>

      <label className="flex items-start gap-3 rounded-lg border border-line bg-slate-50 p-3 text-sm">
        <input
          type="checkbox"
          checked={explicitConfirm}
          onChange={(event) => setExplicitConfirm(event.target.checked)}
          className="mt-1 size-4"
        />
        <span>
          I confirm the resolved values above.
          Sending is disabled until this is ticked.
        </span>
      </label>

      {error && <p className="text-sm font-bold text-mismatch">{error}</p>}
      <div className="flex gap-3">
        <button
          type="button"
          onClick={doPreview}
          disabled={busy || defectFields.some((f) => choices[f]?.choice === 'manual' && !choices[f]?.manual.trim())}
          className="rounded-lg bg-primary px-4 py-2 text-base font-semibold text-white shadow transition enabled:hover:opacity-90 disabled:opacity-50"
        >
          {busy ? 'Composing…' : 'Preview email'}
        </button>
      </div>
    </div>
  )
}

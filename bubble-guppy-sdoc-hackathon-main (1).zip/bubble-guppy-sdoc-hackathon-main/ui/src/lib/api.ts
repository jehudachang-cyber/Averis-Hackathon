/** Shared API types — mirrors the `api/` bridge payloads (issue 48). */

export type Category =
  | 'BL_COMPARISON'
  | 'SI_REQUEST'
  | 'INVOICE_QUERY'
  | 'GENERAL'
  | 'SPAM'

export type Status = 'OK' | 'MISMATCH' | 'NEEDS_REVIEW'

/** Effective status for emails whose correction email was sent (issue 78). */
export type EffectiveStatus = Status | 'RESOLVED'

export type Subset = 'showcase' | 'starter' | 'bl_comparison' | 'all'

export interface MeasuredScores {
  stage1_macro_f1: number
  stage3_defect_f1: number
  end_to_end: number
  escalation_precision: number
  escalation_recall: number
  final_score: number
  measured_on: string
}

export interface Overview {
  total_emails: number
  category_distribution: Record<Category, number>
  status_distribution: Record<EffectiveStatus, number>
  escalation_reasons: Record<string, number>
  defects: { mismatched_emails: number; field_counts: Record<string, number> }
  measured_scores: MeasuredScores
}

export interface EmailSummary {
  email_id: string
  subject: string
  category: Category
  status: Status
  review_reason: string | null
  has_defect: boolean
  defect_fields: string[]
  subsets: Subset[]
  matched_keyword: string
  /** Issue 78: effective RESOLVED overlay from the durable resolve trail. */
  resolved: boolean
  resolved_at: string | null
}

export interface EmailList {
  count: number
  emails: EmailSummary[]
}

export interface StoryAttachment {
  path: string
  kind: string
  scanned: boolean
  lines: string[]
  anchors: Record<string, number[]>
}

export interface Story {
  email_id: string
  subject: string
  body: string
  classification: { category: Category; confidence: number | null; reason: string }
  attachments: StoryAttachment[]
  comparison: Record<string, { si: string; bl: string; match: boolean | null }> | null
  verdict: {
    status: Status
    review_reason: string | null
    has_defect: boolean
    defect_fields: string[]
    decided_by: string
    detail: string
  }
  steps: { stage: string; decision: string; detail: string }[]
  /** Issue 78: true when a correction email was sent for this email. */
  resolved: boolean
  resolved_at: string | null
}

export const FIELD_LABELS: Record<string, string> = {
  shipper: 'Shipper',
  consignee: 'Consignee',
  notify_party: 'Notify Party',
  port_of_loading: 'Port of Loading',
  port_of_discharge: 'Port of Discharge',
  container_count: 'Container Count',
  gross_weight_kg: 'Gross Weight (KG)',
}

export async function api<T>(path: string): Promise<T> {
  const response = await fetch(`/api${path}`)
  if (!response.ok) {
    throw new Error(`${path}: ${response.status}`)
  }
  return (await response.json()) as T
}

/**
 * Session story cache (per page load): Pipeline shows one page (≤24) of story
 * cards at a time, but the server already holds every story in memory — the
 * cost is per-email round-trips on each remount. Cache the promise per
 * email_id so each story is fetched at most once per session and revisits are
 * free. Concurrent requests for the same story share one in-flight promise.
 */
const storyCache = new Map<string, Promise<Story>>()

export function fetchStoryCached(emailId: string): Promise<Story> {
  let cached = storyCache.get(emailId)
  if (!cached) {
    cached = api<Story>(`/emails/${emailId}/story`).catch((error: unknown) => {
      storyCache.delete(emailId) // don't pin failures — the next visit retries
      throw error
    })
    storyCache.set(emailId, cached)
  }
  return cached
}

export async function apiPost<T>(path: string, payload: unknown): Promise<T> {
  const response = await fetch(`/api${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  })
  if (!response.ok) {
    const detail = await response
      .json()
      .then((data: { detail?: string }) => data.detail)
      .catch(() => undefined)
    throw new Error(detail ?? `${path}: ${response.status}`)
  }
  return (await response.json()) as T
}

/** Per-field resolution choice (issue 51): SI is the prefilled default. */
export type ResolveChoice = 'si' | 'bl' | 'manual'

export interface ResolvePreviewRequest {
  email_id: string
  choices: Record<string, ResolveChoice>
  overrides: Record<string, string>
}

export interface ResolvePreview {
  email_id: string
  recipient: string
  sandboxed: boolean
  subject: string
  body: string
  risky_fields: string[]
}

export interface ResolveSendRequest extends ResolvePreviewRequest {
  confirmed: boolean
}

export interface ResolveSendResult {
  email_id: string
  recipient: string
  sandboxed: boolean
  logged: boolean
  resolved_at: string
}

export interface ResolveLogEntry {
  timestamp: string
  email_id: string
  recipient: string
  sandboxed: boolean
  resolutions: Record<string, { choice: ResolveChoice; value: string | null }>
}

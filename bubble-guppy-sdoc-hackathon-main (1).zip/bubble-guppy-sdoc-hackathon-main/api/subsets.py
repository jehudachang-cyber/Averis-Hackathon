"""Query-derived subsets for the demo dashboard (issue 48, plan decision #11).

Subsets are **derived from the run's own records** — never hand-picked lists
that go stale when the bundle changes:

- ``showcase``: five pinned, hand-picked hero stories (plan decision #11's
  documented override). Pins are email ids from the *plan*, chosen because
  they demonstrate one specific pipeline outcome each; they are not tuned
  against any answer key (they only need to *exist* in the inbox).
- ``starter``: ~30 varied emails — one per category, one per escalation
  reason, plus mismatches — picked deterministically by stable id order.
- ``bl_comparison``: every email classified as BL_COMPARISON.
- ``all``: everything.
"""

from __future__ import annotations

from typing import Any

# Hand-pinned Showcase stories (plan §Subsets): perfect OK, mismatch, spam,
# missing attachment, unreadable scan. Existence in the bundle is checked at
# runtime; missing pins are skipped rather than fabricating ids.
SHOWCASE_PINS: tuple[str, ...] = (
    "email_453",  # clean SI/BL pair, all seven fields match -> OK
    "email_001",  # visible multi-field mismatch
    "email_015",  # spam
    "email_004",  # SI+BL attached, consignee/notify_party differ -> MISMATCH
    "email_512",  # scanned SI+BL: transcribed via Gemini OCR, fields compare -> OK
    # Issue 46 multilingual threads (values byte-identical to their English
    # twins, so the verdicts below transfer by construction):
    "email_mzh_ok",  # Chinese SI/BL -> OK via Gemini label translation
    "email_mbm_ok",  # Bahasa Melayu SI/BL -> OK via Gemini label translation
    "email_mzh_mismatch",  # Chinese SI/BL -> MISMATCH (consignee, notify_party)
    "email_mbm_mismatch",  # Bahasa Melayu SI/BL -> MISMATCH (consignee, notify_party)
)

STARTER_SIZE = 30


def derive_subsets(records: list[dict[str, Any]]) -> dict[str, list[str]]:
    """Compute subset membership from the run's own records.

    Args:
        records: Submission-shaped record dicts with ``email_id``.

    Returns:
        ``{"showcase": [...], "starter": [...], "all": [...]}`` — email id
        lists, deterministic for a given bundle and pipeline version.
    """
    by_id = {record["email_id"]: record for record in records}
    ordered_ids = [record["email_id"] for record in records]

    showcase = [email_id for email_id in SHOWCASE_PINS if email_id in by_id]

    starter: list[str] = []
    seen: set[str] = set()

    def take(predicate: Any) -> None:
        for email_id in ordered_ids:
            if email_id in seen:
                continue
            record = by_id[email_id]
            if predicate(record):
                starter.append(email_id)
                seen.add(email_id)
                return

    # one per category
    for category in ("BL_COMPARISON", "SI_REQUEST", "INVOICE_QUERY", "GENERAL", "SPAM"):
        take(lambda r, c=category: r["category"] == c)
    # one per escalation reason
    for reason in (
        "wrong_doc_type",
        "missing_attachment",
        "unreadable",
        "missing_value",
    ):
        take(lambda r, x=reason: r["review_reason"] == x)
    # fill the rest with mismatches first, then a stable slice of everything
    take(lambda r: r["status"] == "MISMATCH")
    take(lambda r: r["status"] == "MISMATCH")
    for email_id in ordered_ids:
        if len(starter) >= STARTER_SIZE:
            break
        if email_id not in seen:
            starter.append(email_id)
            seen.add(email_id)

    bl_comparison = [
        email_id
        for email_id in ordered_ids
        if by_id[email_id]["category"] == "BL_COMPARISON"
    ]

    return {
        "showcase": showcase,
        "starter": starter,
        "bl_comparison": bl_comparison,
        "all": ordered_ids,
    }


def subset_tags(records: list[dict[str, Any]]) -> dict[str, list[str]]:
    """email_id → the subsets it belongs to (for the /api/emails list)."""
    subsets = derive_subsets(records)
    tags: dict[str, list[str]] = {record["email_id"]: [] for record in records}
    for name, members in subsets.items():
        for email_id in members:
            tags.setdefault(email_id, []).append(name)
    return tags

"""Per-email story assembly: inbox record + Trace → one demo payload (issue 48).

Every story is assembled **straight from the pipeline Trace** (issue 47
provenance events) plus the raw inbox/attachment files. No ground truth is
imported anywhere in ``api/`` and no display value is re-derived — anchors
come from the ``extract`` event, per-field values from the ``compare`` event.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, cast

from sdoc_hackathon.pipeline import BundleEmail, load_bundle_emails, run_pipeline
from sdoc_hackathon.trace import StepEvent, Trace


def _payload(event: StepEvent) -> dict[str, Any]:
    """Narrow the optional StepEvent payload (issue 47 events always set it)."""
    assert event.payload is not None
    return cast("dict[str, Any]", event.payload)


def _doc_lines(data_root: Path, attachment: str) -> list[str]:
    """Read one native attachment's text lines; missing files degrade visibly.

    Binary formats (pdf/xlsx/docx) are *not* decoded here: scanned PDFs
    reach the UI through their parse event's OCR rows (see ``build_story``);
    native txt renders from disk exactly as the pipeline read it.
    """
    path = data_root / attachment
    if not path.is_file():
        return [f"(attachment not found: {attachment})"]
    suffix = path.suffix.lower()
    if suffix not in (".txt", ".md", ""):
        return [f"({suffix} document — rendered by the pipeline; see parse step)"]
    return path.read_text(encoding="utf-8", errors="replace").splitlines()


def build_story(
    email_id: str,
    record_payload: dict[str, Any],
    trace: Trace,
    email: BundleEmail,
    data_root: Path,
) -> dict[str, Any]:
    """Assemble one email's full demo story.

    Args:
        email_id: Inbox identifier.
        record_payload: The submission-shaped record (category, status,
            review_reason, defect_fields, has_defect, decided_by).
        trace: The pipeline Trace for this email.
        email: The inbox email (subject/body/attachments).
        data_root: Bundle root, for reading attachment text.

    Returns:
        A JSON-ready dict: classify detail, per-attachment lines + extract
        anchors, per-field comparison values, and the review verdict.
    """
    classify = trace.stage("classify")
    parse_events = [e for e in trace.events if e.stage == "parse"]
    extract_event = trace.stage("extract")
    compare_event = trace.stage("compare")
    review = trace.stage("review")

    anchors_by_path: dict[str, dict[str, Any]] = {}
    if extract_event is not None:
        for doc in _payload(extract_event).get("documents", []):
            path = str(doc.get("path", ""))
            anchors_by_path[path] = cast("dict[str, Any]", doc)

    attachments: list[dict[str, Any]] = []
    for relative in email.attachments:
        # Parse events tag their attachment in the payload ("path") — the
        # detail string is a confidence reason and carries no path.
        parse_event = next(
            (e for e in parse_events if (e.payload or {}).get("path") == relative),
            None,
        )
        provenance = anchors_by_path.get(relative, {})
        field_anchors = cast("dict[str, dict[str, Any]]", provenance.get("fields", {}))
        anchors_out = {
            name: meta.get("rows", [])
            for name, meta in field_anchors.items()
            if meta.get("present")
        }
        # Parsed rows live in the parse event payload (all formats); the
        # extract payload carries the scanned flag for the OCR treatment.
        raw_rows = None
        if parse_event is not None and parse_event.payload:
            raw_rows = parse_event.payload.get("rows")
        rows = [str(row) for row in raw_rows] if isinstance(raw_rows, list) else None
        scanned = bool(provenance.get("scanned"))
        if parse_event is not None and parse_event.decision == "UNREADABLE":
            lines = [f"(unreadable — {parse_event.detail})"]
        elif rows:
            lines = rows
        else:
            lines = _doc_lines(data_root, relative)
        attachments.append(
            {
                "path": relative,
                "kind": provenance.get("kind")
                or (parse_event.decision if parse_event else "UNKNOWN"),
                "scanned": scanned,
                "lines": lines,
                "anchors": anchors_out,
            }
        )

    comparison = None
    if compare_event is not None:
        comparison = _payload(compare_event).get("fields")

    return {
        "email_id": email_id,
        "subject": email.subject,
        "body": email.body,
        "classification": {
            "category": record_payload["category"],
            "confidence": classify.confidence.score
            if classify and classify.confidence
            else None,
            "reason": classify.detail if classify else "",
        },
        "attachments": attachments,
        "comparison": comparison,
        "verdict": {
            "status": record_payload["status"],
            "review_reason": record_payload["review_reason"],
            "has_defect": record_payload["has_defect"],
            "defect_fields": list(record_payload["defect_fields"]),
            "decided_by": record_payload["decided_by"],
            "detail": review.detail if review else "",
        },
        "steps": [
            {"stage": e.stage, "decision": e.decision, "detail": e.detail}
            for e in trace.events
        ],
    }


def run_bundle(
    data_root: Path, ocr_keys: list[str] | None = None
) -> tuple[list[dict[str, Any]], dict[str, dict[str, Any]], list[Trace]]:
    """Run the pipeline over the bundle once and return demo-ready state.

    Args:
        data_root: Bundle directory containing ``inbox/`` and ``attachments/``.
        ocr_keys: Optional Gemini keys passed straight through to the
            pipeline (scanned PDFs); ``None`` keeps the deterministic
            no-OCR behavior.

    Returns:
        ``(records, stories, traces)`` where ``records`` are submission-
        shaped dicts (in input order), ``stories`` maps email_id → the
        full story payload, and ``traces`` are the raw Trace objects.
    """
    emails = load_bundle_emails(data_root)
    records, traces = run_pipeline(emails, data_root=data_root, ocr_keys=ocr_keys)
    stories: dict[str, dict[str, Any]] = {}
    records_out: list[dict[str, Any]] = []
    for record, trace in zip(records, traces, strict=True):
        payload = {
            "category": record.category,
            "status": record.status,
            "review_reason": record.review_reason,
            "has_defect": record.has_defect,
            "defect_fields": list(record.defect_fields),
            "decided_by": record.decided_by,
        }
        records_out.append({"email_id": record.email_id, **payload})
        story = build_story(
            record.email_id,
            payload,
            trace,
            cast("BundleEmail", dict(emails)[record.email_id]),
            data_root,
        )
        stories[record.email_id] = story
    return records_out, stories, traces


def load_inbox_subjects(data_root: Path) -> dict[str, str]:
    """email_id → subject, read from the inbox files (display only)."""
    subjects: dict[str, str] = {}
    inbox = data_root / "inbox"
    for path in sorted(inbox.glob("email_*.json")):
        data = json.loads(path.read_text(encoding="utf-8"))
        subjects[str(data["email_id"])] = str(data.get("subject", ""))
    return subjects

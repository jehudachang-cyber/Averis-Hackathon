"""Gmail SMTP mailer for the auto-resolve stage (issue 51).

Sends one composed email via Gmail's SMTP relay (``smtp.gmail.com:587``,
STARTTLS) authenticated with an App Password. Credentials arrive as plain
strings — the caller resolves them from the environment / Secret Manager;
nothing here reads, logs, or stores key material.

The composed body is markdown (issue 68): the message carries the markdown
source as the plain-text part and a rendered HTML alternative (tables look
nice in clients that support it).

Errors are raised as :class:`MailError` so the HTTP layer can answer with a
clean message instead of a raw SMTP traceback.
"""

from __future__ import annotations

import html
import re
import smtplib
from email.message import EmailMessage

#: Gmail SMTP relay: STARTTLS on the submission port.
SMTP_HOST = "smtp.gmail.com"
SMTP_PORT = 587

#: Socket timeout for the whole send (connect → login → send), in seconds.
SMTP_TIMEOUT_S = 30


class MailError(RuntimeError):
    """An email could not be sent (clean, HTTP-mappable failure).

    Example:
        >>> MailError("email send failed: auth rejected")
        MailError('email send failed: auth rejected')
    """


def _inline(text: str) -> str:
    """Render a line's inline markdown (**bold**, ``code``) to safe HTML.

    All plain text is HTML-escaped; only the recognised ``**…**`` and
    ``\`…\``\ spans become markup. Anything else, including raw ``<``/``>``,
    stays escaped — the body can never inject markup.

    Example:
        >>> _inline("SI <b> vs **BL** and `raw`")
        'SI &lt;b&gt; vs <strong>BL</strong> and <code>raw</code>'
    """
    tokens = re.split(r"(\*\*.+?\*\*|`[^`]+?`)", text)
    out: list[str] = []
    for token in tokens:
        if token.startswith("**") and token.endswith("**") and len(token) >= 4:
            out.append(f"<strong>{html.escape(token[2:-2])}</strong>")
        elif token.startswith("`") and token.endswith("`") and len(token) >= 2:
            out.append(f"<code>{html.escape(token[1:-1])}</code>")
        else:
            out.append(html.escape(token))
    return "".join(out)


def _split_row(line: str) -> list[str]:
    """Split one ``| a | b |`` table line into trimmed cells."""
    return [cell.strip() for cell in line.strip().strip("|").split("|")]


def _is_separator(cell: str) -> bool:
    """True for a markdown table-alignment cell (``:---:``, ``---``, …)."""
    return bool(re.fullmatch(r":?-+:?", cell))


def _table_html(lines: list[str]) -> str:
    """Render a markdown table block to a ``<table>`` element.

    Example:
        >>> _table_html(["| A | B |", "| --- | --- |", "| 1 | 2 |"])
        '<table><thead><tr><th>A</th><th>B</th></tr></thead><tbody><tr><td>1</td><td>2</td></tr></tbody></table>'
    """
    rows = [_split_row(line) for line in lines]
    header, body = None, rows
    if len(rows) >= 2 and all(_is_separator(cell) for cell in rows[1]):
        header, body = rows[0], rows[2:]
    parts = ["<table>"]
    if header:
        cells = "".join(f"<th>{_inline(cell)}</th>" for cell in header)
        parts.append(f"<thead><tr>{cells}</tr></thead>")
    parts.append("<tbody>")
    for row in body:
        cells = "".join(f"<td>{_inline(cell)}</td>" for cell in row)
        parts.append(f"<tr>{cells}</tr>")
    parts.append("</tbody></table>")
    return "".join(parts)


def markdown_to_html(markdown: str) -> str:
    """Render the composed markdown body (issue 68 subset) to HTML.

    Supports paragraphs, ``**bold**`` / ``code`` inline spans, and markdown
    tables (``| a | b |`` rows with a ``| --- | --- |`` separator). HTML in
    the input is never passed through.

    Example:
        >>> markdown_to_html("**Hi**\\n\\n| A | B |\\n| --- | --- |\\n| 1 | 2 |")
        '<p><strong>Hi</strong></p><table><thead><tr><th>A</th><th>B</th></tr></thead><tbody><tr><td>1</td><td>2</td></tr></tbody></table>'
    """
    blocks = re.split(r"\n\s*\n", markdown.strip())
    parts: list[str] = []
    for block in blocks:
        lines = [line for line in block.splitlines() if line.strip()]
        if not lines:
            continue
        if all(
            line.strip().startswith("|") and line.strip().endswith("|")
            for line in lines
        ):
            parts.append(_table_html(lines))
        else:
            parts.append(f"<p>{_inline(' '.join(lines))}</p>")
    return "".join(parts)


def send_email(user: str, app_password: str, to: str, subject: str, body: str) -> None:
    """Send one markdown email via Gmail SMTP STARTTLS.

    Args:
        user: Gmail account (envelope From and login username).
        app_password: Gmail App Password (never logged).
        to: Recipient address (sandbox inbox or, with ``ALLOW_REAL_SEND=1``,
            the original counterparty).
        subject: Full subject line (already threaded by the caller).
        body: Markdown email body; sent as the plain part and rendered as an
            HTML alternative (issue 68).

    Raises:
        MailError: On any SMTP/OSError; the original exception is chained.

    Note:
        No doctest on purpose: any example would touch the network.
    """
    message = EmailMessage()
    message["From"] = user
    message["To"] = to
    message["Subject"] = subject
    message.set_content(body)
    message.add_alternative(markdown_to_html(body), subtype="html")
    try:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=SMTP_TIMEOUT_S) as server:
            server.starttls()
            server.login(user, app_password)
            server.send_message(message)
    except (smtplib.SMTPException, OSError) as exc:
        raise MailError(f"email send failed: {exc}") from exc

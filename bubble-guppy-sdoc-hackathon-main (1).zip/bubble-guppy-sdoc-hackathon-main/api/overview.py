"""Overview rollups for the demo dashboard (issue 48).

All counts come from the run's own records — live *distributions* only.
The measured scores (macro-F1, defect-F1, e2e, FINAL) are **embedded labels**
(plan decisions #1/#8): they were measured once via ``score_cli.py`` and are
served as constants. Ground truth is never imported and no score is
recomputed here.
"""

from __future__ import annotations

from collections import Counter
from datetime import date
from typing import Any

#: Effective status for emails whose resolution was logged (issue 78).
_RESOLVED_STATUS = "RESOLVED"

#: Score values were measured over the full 520-email bundle with OCR live
#: (see docs/explanation/eval-report-2026-09-19.md). Display-only labels —
#: the browser never sees the answer key. The ``measured_on`` label is
#: assembled per request in :func:`build_overview`: this run's date, the
#: run's actual email count (main bundle + issue-46 fixture threads), and
#: whether OCR/translation was live.
MEASURED_SCORES: dict[str, Any] = {
    "stage1_macro_f1": 1.000,
    "stage3_defect_f1": 1.000,
    "end_to_end": 1.000,
    "escalation_precision": 1.000,
    "escalation_recall": 0.850,
    "final_score": 1.0000,
}

_ESCALATION_REASONS = (
    "wrong_doc_type",
    "missing_attachment",
    "unreadable",
    "missing_value",
)

_CATEGORIES = ("BL_COMPARISON", "SI_REQUEST", "INVOICE_QUERY", "GENERAL", "SPAM")

_STATUSES = ("OK", "MISMATCH", "NEEDS_REVIEW")


def build_overview(
    records: list[dict[str, Any]],
    *,
    ocr_live: bool = False,
    resolved: set[str] | None = None,
) -> dict[str, Any]:
    """Roll the run's records into the Overview page's distributions.

    Args:
        records: Submission-shaped record dicts (category, status,
            review_reason, defect_fields, has_defect).
        ocr_live: Whether this run used Gemini (scans + issue-46 label
            translation); reflected in the measured-scores date label.
        resolved: Email ids whose correction email was sent (issue 78);
            they move to the ``RESOLVED`` status bucket and stop counting
            as open mismatches (``defects.mismatched_emails``).

    Returns:
        Category/status/reason distributions, defect-field frequency over
        mismatched emails, headline counts, and the measured score strip.
    """
    resolved = resolved or set()
    category_counts = Counter(record["category"] for record in records)
    status_counts: Counter[str] = Counter()
    for record in records:
        effective = (
            _RESOLVED_STATUS
            if record["email_id"] in resolved and record["status"] == "MISMATCH"
            else record["status"]
        )
        status_counts[effective] += 1
    reason_counts = Counter(
        record["review_reason"] for record in records if record["review_reason"]
    )

    defect_field_counts: Counter[str] = Counter()
    mismatched = 0
    for record in records:
        if record["status"] == "MISMATCH" and str(record["email_id"]) not in resolved:
            mismatched += 1
            defect_field_counts.update(record["defect_fields"])

    return {
        "total_emails": len(records),
        "category_distribution": {
            category: category_counts.get(category, 0) for category in _CATEGORIES
        },
        "status_distribution": {
            status: status_counts.get(status, 0)
            for status in (*_STATUSES, _RESOLVED_STATUS)
        },
        "escalation_reasons": {
            reason: reason_counts.get(reason, 0) for reason in _ESCALATION_REASONS
        },
        "defects": {
            "mismatched_emails": mismatched,
            "field_counts": dict(defect_field_counts.most_common()),
        },
        "measured_scores": {
            **MEASURED_SCORES,
            "measured_on": (
                f"{date.today().isoformat()} ({len(records)} emails, "
                f"{'OCR live' if ocr_live else 'no OCR'})"
            ),
        },
    }

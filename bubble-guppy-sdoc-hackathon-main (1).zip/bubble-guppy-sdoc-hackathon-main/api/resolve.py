"""Auto-resolve stage: post-mismatch resolution + correction email (issue 51).

When the pipeline verdict is ``MISMATCH`` (all seven fields compared, both
values present), an operator picks the correct value per mismatched field —
``si`` (prefilled default), ``bl``, or a manual override — the bridge composes
a correction email, and the resolution is logged.

Hard invariants:
    - **Sandbox by default.** Unless ``ALLOW_REAL_SEND=1`` is set on a real
      GCP deploy, every send is redirected to ``SANDBOX_RECIPIENT`` while the
      UI still shows the real counterparty. Never delivered to a bundle
      domain during a demo.
    - **Immutable verdicts.** Resolutions are logged separately; the frozen
      pipeline ``SubmissionRecord``/verdicts are never mutated.
    - **Log never breaks the send path.** The Firestore backend downgrades
      to the file log on any error.
"""

from __future__ import annotations

import json
import os
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal


#: The fields whose resolution needs an explicit confirm (title-document
#: consequences: these name the parties/ports on the bill of lading).
RISKY_FIELDS: frozenset[str] = frozenset(
    {"consignee", "notify_party", "port_of_loading", "port_of_discharge"}
)

#: Per-field choice semantics.
Choice = Literal["si", "bl", "manual"]

_RESOLVE_LOG_DEFAULT = ".demo-logs/resolve.log"


# --------------------------------------------------------------------------- #
# Decision model
# --------------------------------------------------------------------------- #


def resolved_value(
    name: str,
    choice: Choice,
    si: str,
    bl: str,
    manual: str | None = None,
) -> str:
    """Resolve one field to its chosen value.

    Args:
        name: Canonical field name.
        choice: ``si`` / ``bl`` / ``manual``.
        si: The SI (reference) value.
        bl: The BL value.
        manual: Operator-typed value; required when ``choice == "manual"``.

    Returns:
        The resolved value (``""`` when nothing usable was chosen).

    Raises:
        ValueError: If ``choice == "manual"`` without a non-blank value.

    Example:
        >>> resolved_value("shipper", "si", "APRIL", "April Ltd")
        'APRIL'
        >>> resolved_value("shipper", "manual", "A", "B", " Corrected ")
        'Corrected'
        >>> resolved_value("shipper", "manual", "A", "B", "  ")
        Traceback (most recent call last):
            ...
        ValueError: manual choice requires a non-blank value
    """
    if choice == "manual":
        value = (manual or "").strip()
        if not value:
            msg = "manual choice requires a non-blank value"
            raise ValueError(msg)
        return value
    return si if choice == "si" else bl


def risk_tier(name: str) -> Literal["single_confirm", "explicit_confirm"]:
    """Risk tier for one field.

    Container count, gross weight, and shipper resolve with a single
    confirm; consignee/notify party/ports always require an explicit
    confirm — title-document consequences.

    Example:
        >>> risk_tier("container_count")
        'single_confirm'
        >>> risk_tier("consignee")
        'explicit_confirm'
    """
    return "explicit_confirm" if name in RISKY_FIELDS else "single_confirm"


def validate_resolution(
    choices: dict[str, Choice],
    overrides: dict[str, str] | None = None,
) -> list[str]:
    """Validate a full resolution against the risk-tier policy.

    Args:
        choices: field → chosen source for every mismatched field.
        overrides: field → operator-typed value (for ``manual`` choices).

    Returns:
        Human-readable error list; empty when the resolution is valid.

    Example:
        >>> validate_resolution({"shipper": "si", "consignee": "bl"})
        []
        >>> validate_resolution({"shipper": "manual"})
        ['shipper: manual choice requires a non-blank value']
        >>> validate_resolution({"shipper": "bl"}, {"shipper": "X"})
        ['shipper: override value given for a non-manual choice']
    """
    errors: list[str] = []
    overrides = overrides or {}
    for name, choice in choices.items():
        if choice == "manual" and not (overrides.get(name) or "").strip():
            errors.append(f"{name}: manual choice requires a non-blank value")
        if choice != "manual" and (overrides.get(name) or "").strip():
            errors.append(f"{name}: override value given for a non-manual choice")
    return errors


# --------------------------------------------------------------------------- #
# Email composition
# --------------------------------------------------------------------------- #


def compose_email(
    email_id: str,
    subject: str,
    comparison: dict[str, dict[str, Any]],
    defect_fields: list[str],
    choices: dict[str, Choice],
    overrides: dict[str, str] | None = None,
) -> tuple[str, str]:
    """Compose the correction email (subject + markdown body).

    Args:
        email_id: Inbox identifier (kept in the subject for traceability).
        subject: Original email subject; the composed subject threads it.
        comparison: field → ``{"si": str, "bl": str, "match": bool | None}``
            (the story payload's per-field comparison).
        defect_fields: Fields the operator is resolving.
        choices: field → chosen source (``si``/``bl``/``manual``).
        overrides: field → operator-typed value for ``manual`` choices.

    Returns:
        ``(subject, body)`` — the body is markdown: a discrepancy table
        followed by the chosen resolved values (issue 68).

    Example:
        >>> comparison = {"consignee": {"si": "A Co", "bl": "B Co", "match": False}}
        >>> subj, body = compose_email("email_004", "REQUEST BL DRAFT", comparison, ["consignee"], {"consignee": "si"})
        >>> subj
        'Re: REQUEST BL DRAFT (email_004)'
        >>> '| Field | SI value | BL value |' in body
        True
        >>> '| --- | --- | --- |' in body
        True
        >>> '| consignee | A Co | B Co |' in body
        True
        >>> 'RESOLVED VALUE' in body
        True
    """
    threaded = f"Re: {subject} ({email_id})"

    header = "| Field | SI value | BL value |"
    rules = "| --- | --- | --- |"
    rows = []
    for name in defect_fields:
        pair = comparison.get(name, {})
        rows.append(f"| {name} | {pair.get('si', '')} | {pair.get('bl', '')} |")

    resolved_rows = []
    for name in defect_fields:
        choice = choices.get(name, "si")
        value = resolved_value(
            name,
            choice,
            str(comparison.get(name, {}).get("si", "")),
            str(comparison.get(name, {}).get("bl", "")),
            (overrides or {}).get(name),
        )
        resolved_rows.append(f"| {name} | {value} |")

    lines = [
        "Hello,",
        "",
        "While verifying the Shipping Instruction against the draft Bill of",
        "Lading, we found discrepancies in the following field(s).",
        "",
        "**Discrepancy table (SI vs draft BL — unchanged values omitted)**",
        "",
        header,
        rules,
        *rows,
        "",
        "**RESOLVED VALUES (requested for the final BL)**",
        "",
        "| Field | Resolved value |",
        "| --- | --- |",
        *resolved_rows,
        "",
        "Please amend the draft Bill of Lading accordingly and share the",
        "corrected version at your earliest convenience.",
        "",
        "Best regards,",
        "Shipping Documentation Team",
    ]
    return threaded, "\n".join(lines)


# --------------------------------------------------------------------------- #
# Routing (sandbox by default)
# --------------------------------------------------------------------------- #


def route_recipient(real_recipient: str) -> tuple[str, bool]:
    """Decide where the send goes, and whether it was sandboxed.

    Real delivery requires an explicit ``ALLOW_REAL_SEND=1``; everything
    else — local dev, demos, misconfiguration — lands in the team's own
    sandbox inbox. Never a bundle domain.

    Args:
        real_recipient: The counterparty address (the email's ``from``).

    Returns:
        ``(recipient, sandboxed)``.

    Raises:
        ValueError: When real send is requested but no counterparty or
            sandbox address is resolvable.

    Example:
        >>> import os
        >>> _ = os.environ.pop("ALLOW_REAL_SEND", None)
        >>> _ = os.environ.pop("SANDBOX_RECIPIENT", None)
        >>> route_recipient("docs@vitalsolutions.sg")
        ('', True)
        >>> os.environ["SANDBOX_RECIPIENT"] = "team@example.com"
        >>> route_recipient("docs@vitalsolutions.sg")
        ('team@example.com', True)
        >>> os.environ["ALLOW_REAL_SEND"] = "1"
        >>> route_recipient("docs@vitalsolutions.sg")
        ('docs@vitalsolutions.sg', False)
        >>> _ = os.environ.pop("ALLOW_REAL_SEND", None)
        >>> _ = os.environ.pop("SANDBOX_RECIPIENT", None)
    """
    if os.environ.get("ALLOW_REAL_SEND", "").strip() == "1":
        if not real_recipient.strip():
            msg = "real send requested but the email has no from address"
            raise ValueError(msg)
        return real_recipient.strip(), False
    sandbox = os.environ.get("SANDBOX_RECIPIENT", "").strip()
    return sandbox, True


# --------------------------------------------------------------------------- #
# Resolve log (file JSONL default; Firestore optional, graceful downgrade)
# --------------------------------------------------------------------------- #


def log_entry(
    email_id: str,
    recipient: str,
    sandboxed: bool,
    choices: dict[str, Choice],
    overrides: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Build one immutable resolve-log entry (never mutates verdicts).

    Example:
        >>> entry = log_entry("email_004", "sandbox@example.com", True, {"shipper": "si"})
        >>> entry["email_id"], entry["sandboxed"]
        ('email_004', True)
        >>> entry["resolutions"]["shipper"]
        {'choice': 'si', 'value': None}
    """
    resolutions = {
        name: {"choice": choice, "value": (overrides or {}).get(name)}
        for name, choice in choices.items()
    }
    return {
        "timestamp": datetime.now(UTC).isoformat(timespec="seconds"),
        "email_id": email_id,
        "recipient": recipient,
        "sandboxed": sandboxed,
        "resolutions": resolutions,
    }


def _log_path() -> Path:
    """File-log location (``SDOC_RESOLVE_LOG_PATH``, gitignored default)."""
    return Path(os.environ.get("SDOC_RESOLVE_LOG_PATH", _RESOLVE_LOG_DEFAULT))


def append_file_log(entry: dict[str, Any]) -> None:
    """Append one entry to the file JSONL log (creating the directory).

    Example:
        >>> import os
        >>> import tempfile
        >>> os.environ["SDOC_RESOLVE_LOG_PATH"] = tempfile.mkdtemp() + "/r.log"
        >>> append_file_log(log_entry("e1", "a@b.c", True, {"shipper": "si"}))
        >>> entries = read_log()
        >>> entries[-1]["email_id"]
        'e1'
    """
    path = _log_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(entry, ensure_ascii=False) + "\n")


def resolved_map() -> dict[str, dict[str, Any]]:
    """Effective RESOLVED status per email, from the log (issue 78).

    Last entry per ``email_id`` wins; the read path never raises — a log
    backend failure (or one corrupt line) degrades to ``{}`` for that read.

    Returns:
        ``email_id → {resolved_at, recipient, sandboxed, resolutions}``.

    Example:
        >>> import os
        >>> import tempfile
        >>> os.environ["SDOC_RESOLVE_STORE"] = "file"
        >>> os.environ["SDOC_RESOLVE_LOG_PATH"] = tempfile.mkdtemp() + "/r.log"
        >>> resolved_map() == {}
        True
        >>> append_log(log_entry("e1", "a@b.c", True, {"shipper": "si"}))
        >>> append_log(log_entry("e1", "a@b.c", True, {"shipper": "bl"}))
        >>> resolved_map()["e1"]["resolutions"]["shipper"]["choice"]
        'bl'
    """
    resolved: dict[str, dict[str, Any]] = {}
    try:
        entries = read_log()
    except Exception:  # noqa: BLE001 — a broken trail never breaks the read path
        return resolved
    for entry in entries:
        try:
            email_id = str(entry["email_id"])
        except (KeyError, TypeError):
            continue
        resolved[email_id] = {
            "resolved_at": entry.get("timestamp", ""),
            "recipient": entry.get("recipient", ""),
            "sandboxed": bool(entry.get("sandboxed", False)),
            "resolutions": entry.get("resolutions", {}),
        }
    return resolved


def reset_log() -> int:
    """Wipe the durable resolve trail (issue 78, option A reset control).

    The file backend truncates/deletes the JSONL file. Firestore has no
    bulk delete, so the entries are streamed (the same read path as
    :func:`read_log`) and each document is deleted by its real id. Any
    backend error falls back to truncating the file log — the reset never
    crashes.

    Returns:
        Number of trail entries that existed before the reset.

    Example:
        >>> import os
        >>> import tempfile
        >>> os.environ["SDOC_RESOLVE_STORE"] = "file"
        >>> os.environ["SDOC_RESOLVE_LOG_PATH"] = tempfile.mkdtemp() + "/r.log"
        >>> append_log(log_entry("e1", "a@b.c", True, {"shipper": "si"}))
        >>> reset_log()
        1
        >>> read_log(), resolved_map()
        ([], {})
    """
    entries = read_log()
    if os.environ.get("SDOC_RESOLVE_STORE", "file").strip().lower() == "firestore":
        try:
            collection = _firestore_client().collection("resolve_log")
            for doc in collection.stream():
                collection.document(doc.id).delete()
            return len(entries)
        except Exception:  # noqa: BLE001 — downgrade, never crash the reset
            pass
    path = _log_path()
    if path.is_file():
        path.unlink()
    return len(entries)


def read_log() -> list[dict[str, Any]]:
    """Read every entry from the active log backend.

    The file backend reads the JSONL file (missing file → empty list).
    The Firestore backend reads the ``resolve_log`` collection; any error
    there downgrades to the file backend — the read path never crashes.

    Example:
        >>> entries = read_log()
        >>> isinstance(entries, list)
        True
    """
    if os.environ.get("SDOC_RESOLVE_STORE", "file").strip().lower() == "firestore":
        try:
            return _read_firestore()
        except Exception:  # noqa: BLE001 — downgrade, never crash the read path
            pass
    path = _log_path()
    if not path.is_file():
        return []
    entries: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line:
            entries.append(json.loads(line))
    return entries


def _firestore_client() -> Any:
    """Lazily construct the Firestore client (import cost stays local)."""
    from google.cloud import firestore

    project = os.environ.get("GCP_PROJECT") or os.environ.get("GOOGLE_CLOUD_PROJECT")
    return firestore.Client(project=project) if project else firestore.Client()


def _write_firestore(entry: dict[str, Any]) -> None:
    """Append one entry to the ``resolve_log`` Firestore collection."""
    _firestore_client().collection("resolve_log").add(entry)


def _read_firestore() -> list[dict[str, Any]]:
    """Read the ``resolve_log`` collection, oldest first."""
    docs = _firestore_client().collection("resolve_log").stream()
    return [dict(doc.to_dict() or {}) for doc in docs]


def append_log(entry: dict[str, Any]) -> None:
    """Append one entry to the configured backend, with graceful downgrade.

    Firestore is attempted only when ``SDOC_RESOLVE_STORE=firestore``; any
    failure there (missing credentials, network, quota) silently downgrades
    to the file log — the send path must never crash on logging.

    Example:
        >>> import os
        >>> import tempfile
        >>> os.environ["SDOC_RESOLVE_LOG_PATH"] = tempfile.mkdtemp() + "/r.log"
        >>> append_log(log_entry("e2", "a@b.c", True, {"shipper": "bl"}))
        >>> read_log()[-1]["email_id"]
        'e2'
    """
    if os.environ.get("SDOC_RESOLVE_STORE", "file").strip().lower() == "firestore":
        try:
            _write_firestore(entry)
            return
        except Exception:  # noqa: BLE001 — downgrade, never crash the send path
            pass
    append_file_log(entry)

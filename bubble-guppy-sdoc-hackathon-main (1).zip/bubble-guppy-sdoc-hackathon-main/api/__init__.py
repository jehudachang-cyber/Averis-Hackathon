"""Demo bridge API for the SDOC dashboard (issue 48)."""

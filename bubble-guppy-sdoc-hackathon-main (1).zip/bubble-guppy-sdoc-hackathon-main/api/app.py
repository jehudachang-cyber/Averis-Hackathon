"""Demo bridge API: pipeline Trace → dashboard JSON (issue 48).

Runs the real pipeline over the bundle **once** at startup and serves
everything from that cache: no ground truth anywhere, no re-derivation on
the read path, no stale artifacts.

**Snapshot cache (quota guard).** A full live run spends Gemini calls
(scanned-PDF OCR + issue-46 label translations). Restarts therefore reuse a
fingerprinted snapshot of the last successful run instead of re-running the
pipeline: the fingerprint covers the bundle files, the bridge/pipeline
sources, and *whether* LLM keys were live (never key material), so any
input change invalidates it automatically.

Endpoints
    GET /api/health            liveness + cache state
    GET /api/overview          rollups + measured score strip (labels)
    GET /api/emails            summary list, subset-filterable
    GET /api/emails/{id}/story full story from the Trace
    GET /api/subsets           the subsets (showcase/starter/bl_comparison/all)

Environment
    SDOC_DATA_ROOT   bundle directory (default: ``sdoc-hackathon-bundle``)
    SDOC_OCR_KEYS    optional Gemini keys override; set to empty to force
                     no-OCR. Unset: GEMINI_API_KEYS from .env are used.
    SDOC_MULTILINGUAL_ROOT   optional extra fixture bundle (issue 46 threads)
                     merged into the cache; default
                     ``sdoc-hackathon-bundle-multilingual`` when present.
    SDOC_SNAPSHOT    ``on`` (default) reuse + write the snapshot;
                     ``refresh`` ignore any snapshot, re-run, re-write;
                     ``off`` always run live, never read/write.
    SDOC_SNAPSHOT_PATH   snapshot file (default ``.demo-logs/bridge-snapshot.json``)
    SDOC_SNAPSHOT_BUCKET optional GCS bucket persisting the snapshot (issue 73);
                     set on Cloud Run so cold instances read/write the cache
                     there; unset keeps today's file-only behavior.
    SDOC_UI_DIST     built React app to serve statically (default: unset = API
                     only, local dev). On Cloud Run: ``/app/ui/dist`` — non-API
                     GETs serve the SPA (index.html), so one service hosts the
                     whole dashboard (issue 52). Static serving is mounted at
                     import time, after the ``/api`` routes above.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import tempfile
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Any, cast

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from api import mailer
from api.overview import build_overview
from api.resolve import (
    RISKY_FIELDS,
    Choice,
    append_log,
    compose_email,
    log_entry,
    read_log,
    reset_log,
    resolved_map,
    route_recipient,
    validate_resolution,
)
from api.story import load_inbox_subjects, run_bundle
from api.subsets import derive_subsets, subset_tags

logger = logging.getLogger("api.app")

app = FastAPI(
    title="SDOC Demo Bridge",
    version="1.0",
    description="Story + rollup + subset endpoints over the pipeline Trace.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)


@dataclass(frozen=True)
class _BridgeState:
    """Everything the endpoints serve, computed once from one pipeline run.

    ``classify_details`` is the per-email classifier evidence line (the one
    thing the raw traces contributed); keeping the state JSON-serializable
    is what makes the snapshot cache possible.
    """

    records: list[dict[str, object]]
    stories: dict[str, dict[str, object]]
    subjects: dict[str, str]
    classify_details: dict[str, str]
    ocr_live: bool = False
    source: str = "live"  # "live" | "snapshot"
    subsets: dict[str, list[str]] = field(default_factory=dict)
    tags: dict[str, list[str]] = field(default_factory=dict)


def _ocr_keys_from_env() -> list[str] | None:
    """Resolve the Gemini keys for this run (SDOC_OCR_KEYS override wins)."""
    ocr_raw = os.environ.get("SDOC_OCR_KEYS")
    if ocr_raw is None:
        from sdoc_hackathon.llm import load_api_keys_from_env

        return load_api_keys_from_env() or None
    return [key.strip() for key in ocr_raw.split(",") if key.strip()] or None


def _state_roots() -> list[Path]:
    """Bundle roots whose files feed the bridge state (main + fixtures)."""
    roots = [Path(os.environ.get("SDOC_DATA_ROOT", "sdoc-hackathon-bundle"))]
    multi_root = Path(
        os.environ.get("SDOC_MULTILINGUAL_ROOT", "sdoc-hackathon-bundle-multilingual")
    )
    if multi_root.is_dir():
        roots.append(multi_root)
    return roots


def _fingerprint(ocr_keys: list[str] | None) -> str:
    """Stable hash of every input the bridge state depends on.

    Covers bundle contents and the bridge/pipeline sources **by content**
    (relative-to-root path + size + sha256), the LLM on/off switch and
    model selection env — never the key material itself. Any byte change
    produces a different fingerprint and invalidates the snapshot.

    Content- (not mtime-)based on purpose: image builds bake fresh mtimes
    into every ``COPY`` layer, so an mtime fingerprint spuriously
    invalidates the snapshot on *every* identical redeploy (one wasted live
    Gemini run per deploy). Identical code+data → identical fingerprint →
    the cached snapshot is reused across Cloud Run revisions. Relative
    paths also make the hash environment-independent (local checkout vs
    the ``/app`` image).
    """
    digest = hashlib.sha256()
    for root in _state_roots():
        for pattern in ("inbox/*.json", "attachments/*"):
            for path in sorted(root.glob(pattern)):
                if path.is_file():
                    rel = path.relative_to(root).as_posix()
                    digest.update(f"{rel}:{path.stat().st_size}:".encode())
                    digest.update(hashlib.sha256(path.read_bytes()).digest())
    for src_dir in (Path("src/sdoc_hackathon"), Path("api")):
        for path in sorted(src_dir.rglob("*.py")):
            if "__pycache__" in path.parts:
                continue
            # ``src_dir`` is cwd-relative in both the repo and the /app image.
            rel = path.as_posix()
            digest.update(f"{rel}:{path.stat().st_size}:".encode())
            digest.update(hashlib.sha256(path.read_bytes()).digest())
    # Presence, not values: key material never enters the fingerprint.
    digest.update(f"ocr_live={bool(ocr_keys)}".encode())
    digest.update(f"models={os.environ.get('GEMINI_MODELS', '')}".encode())
    digest.update(f"model={os.environ.get('GEMINI_MODEL', '')}".encode())
    return digest.hexdigest()[:24]


def _snapshot_path() -> Path:
    return Path(os.environ.get("SDOC_SNAPSHOT_PATH", ".demo-logs/bridge-snapshot.json"))


def _snapshot_bucket() -> str | None:
    """GCS bucket for the persisted snapshot, or ``None`` when unconfigured."""
    return os.environ.get("SDOC_SNAPSHOT_BUCKET") or None


def _storage_client() -> Any:
    """Lazily construct a GCS client (import cost stays local)."""
    from google.cloud import storage

    return storage.Client()


def _download_snapshot(path: Path) -> None:
    """Pull the snapshot from GCS when a bucket is configured (issue 73).

    Best-effort: any storage error leaves the local state untouched and the
    caller falls through to a live run — the same downgrade philosophy as
    the Firestore resolve log.
    """
    bucket = _snapshot_bucket()
    if bucket is None:
        return
    try:
        blob = _storage_client().bucket(bucket).blob("bridge-snapshot.json")
        path.parent.mkdir(parents=True, exist_ok=True)
        blob.download_to_filename(str(path))
        logger.info("bridge snapshot pulled from gs://%s", bucket)
    except Exception as exc:  # noqa: BLE001 — degrade, never crash the load path
        logger.warning("snapshot pull from gs://%s failed (%s)", bucket, exc)
        path.unlink(missing_ok=True)


def _upload_snapshot(path: Path) -> None:
    """Push the snapshot to GCS when a bucket is configured (issue 73).

    Best-effort: a failed upload never breaks the write/send path.
    """
    bucket = _snapshot_bucket()
    if bucket is None or not path.is_file():
        return
    try:
        blob = _storage_client().bucket(bucket).blob("bridge-snapshot.json")
        blob.upload_from_filename(str(path))
        logger.info("bridge snapshot pushed to gs://%s", bucket)
    except Exception as exc:  # noqa: BLE001 — degrade, never crash the write path
        logger.warning("snapshot push to gs://%s failed (%s)", bucket, exc)


def _write_snapshot(path: Path, fingerprint: str, state: _BridgeState) -> None:
    """Atomically persist the bridge state under its fingerprint."""
    payload = {
        "fingerprint": fingerprint,
        "records": state.records,
        "stories": state.stories,
        "subjects": state.subjects,
        "classify_details": state.classify_details,
        "ocr_live": state.ocr_live,
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    handle = tempfile.NamedTemporaryFile(
        "w", encoding="utf-8", dir=path.parent, delete=False, suffix=".tmp"
    )
    try:
        json.dump(payload, handle, ensure_ascii=False)
        handle.close()
        Path(handle.name).replace(path)
    except OSError:
        handle.close()
        Path(handle.name).unlink(missing_ok=True)
        raise
    logger.info("bridge snapshot written: %s (fingerprint %s)", path, fingerprint)
    _upload_snapshot(path)


def _load_snapshot(path: Path, fingerprint: str) -> _BridgeState | None:
    """Load the bridge state from ``path`` when its fingerprint matches."""
    if not path.is_file():
        _download_snapshot(path)
    if not path.is_file():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        if payload.get("fingerprint") != fingerprint:
            logger.info("bridge snapshot stale (fingerprint changed) — re-running")
            return None
        state = _BridgeState(
            records=payload["records"],
            stories=payload["stories"],
            subjects=payload["subjects"],
            classify_details=payload["classify_details"],
            ocr_live=bool(payload["ocr_live"]),
            source="snapshot",
            subsets=derive_subsets(payload["records"]),
            tags=subset_tags(payload["records"]),
        )
    except (OSError, ValueError, KeyError, TypeError) as exc:
        logger.warning("bridge snapshot unreadable (%s) — re-running", exc)
        return None
    logger.info(
        "bridge state loaded from snapshot: %s (%d emails, zero Gemini calls)",
        path,
        len(state.records),
    )
    return state


def _run_live(ocr_keys: list[str] | None) -> _BridgeState:
    """Run the pipeline over every bundle once and build the bridge state."""
    records: list[dict[str, object]] = []
    stories: dict[str, dict[str, object]] = {}
    subjects: dict[str, str] = {}
    classify_details: dict[str, str] = {}
    for root in _state_roots():
        run_records, run_stories, run_traces = run_bundle(root, ocr_keys=ocr_keys)
        records = records + run_records
        stories.update(run_stories)
        subjects.update(load_inbox_subjects(root))
        for trace in run_traces:
            classify = trace.stage("classify")
            classify_details[trace.email_id] = classify.detail if classify else ""
    return _BridgeState(
        records=records,
        stories=stories,
        subjects=subjects,
        classify_details=classify_details,
        ocr_live=bool(ocr_keys),
        source="live",
        subsets=derive_subsets(records),
        tags=subset_tags(records),
    )


@lru_cache(maxsize=1)
def _state() -> _BridgeState:
    """Bridge state: snapshot cache first, one live pipeline run otherwise."""
    ocr_keys = _ocr_keys_from_env()
    fingerprint = _fingerprint(ocr_keys)
    mode = os.environ.get("SDOC_SNAPSHOT", "on").strip().lower()
    path = _snapshot_path()
    if mode != "refresh":
        snapshot = _load_snapshot(path, fingerprint)
        if snapshot is not None:
            return snapshot
    state = _run_live(ocr_keys)
    if mode != "off":
        _write_snapshot(path, fingerprint, state)
    return state


def _classify_detail(state: _BridgeState, email_id: str) -> str:
    """Classifier evidence line for one email."""
    return state.classify_details.get(email_id, "")


@app.get("/api/health")
def health() -> dict[str, object]:
    state = _state()
    return {
        "status": "ok",
        "emails": len(state.records),
        "source": state.source,
        "ocr_live": state.ocr_live,
    }


@app.get("/api/overview")
def overview() -> dict[str, object]:
    state = _state()
    return build_overview(
        state.records,
        ocr_live=state.ocr_live,
        resolved=set(resolved_map()),
    )


@app.get("/api/subsets")
def subsets() -> dict[str, list[str]]:
    return _state().subsets


@app.get("/api/emails")
def emails(subset: str | None = None) -> dict[str, object]:
    """Summary list for Browse; ``?subset=…`` filters."""
    state = _state()
    resolved = resolved_map()
    members: set[str] | None = None
    if subset:
        if subset not in state.subsets:
            raise HTTPException(404, f"unknown subset: {subset}")
        members = set(state.subsets[subset])

    items = [
        {
            "email_id": record["email_id"],
            "subject": state.subjects.get(str(record["email_id"]), ""),
            "category": record["category"],
            "status": record["status"],
            "review_reason": record["review_reason"],
            "has_defect": record["has_defect"],
            "defect_fields": record["defect_fields"],
            "subsets": state.tags.get(str(record["email_id"]), []),
            "matched_keyword": _classify_detail(state, str(record["email_id"])),
            "resolved": str(record["email_id"]) in resolved,
            "resolved_at": resolved.get(str(record["email_id"]), {}).get("resolved_at"),
        }
        for record in state.records
        if members is None or str(record["email_id"]) in members
    ]
    return {"count": len(items), "emails": items}


@app.get("/api/emails/{email_id}/story")
def story(email_id: str) -> dict[str, object]:
    try:
        payload = dict(_state().stories[email_id])
    except KeyError:
        raise HTTPException(404, f"no such email: {email_id}") from None
    resolved = resolved_map().get(email_id)
    payload["resolved"] = resolved is not None
    payload["resolved_at"] = resolved.get("resolved_at") if resolved else None
    return payload


# --------------------------------------------------------------------------- #
# Auto-resolve endpoints (issue 51)
# --------------------------------------------------------------------------- #


class ResolvePreviewRequest(BaseModel):
    """Request body for ``POST /api/resolve/preview``.

    Attributes:
        email_id: The MISMATCH email being resolved.
        choices: Per-mismatched-field choice (``si`` default / ``bl`` /
            ``manual``).
        overrides: Operator-typed values for ``manual`` choices.
    """

    email_id: str
    choices: dict[str, Choice]
    overrides: dict[str, str] = Field(default_factory=dict)


class ResolveSendRequest(ResolvePreviewRequest):
    """Request body for ``POST /api/resolve/send`` — a preview plus confirm."""

    confirmed: bool = False


def _real_recipient(email_id: str) -> str:
    """The counterparty address (the inbox email's ``from`` field)."""
    for root in _state_roots():
        path = root / "inbox" / f"{email_id}.json"
        if path.is_file():
            try:
                return str(json.loads(path.read_text(encoding="utf-8")).get("from", ""))
            except (OSError, ValueError):
                return ""
    return ""


def _resolve_context(email_id: str) -> tuple[dict[str, Any], dict[str, Any]]:
    """Fetch the frozen story for one email and its comparison payload.

    Raises:
        HTTPException: 404 unknown email; 409 anything but a clean MISMATCH
            (NEEDS_REVIEW / OK / missing comparison) is not resolvable.
    """
    story = _state().stories.get(email_id)
    if story is None:
        raise HTTPException(404, f"no such email: {email_id}")
    verdict = cast("dict[str, Any]", story["verdict"])
    comparison = cast("dict[str, Any]", story.get("comparison"))
    if verdict["status"] != "MISMATCH" or not comparison:
        raise HTTPException(
            409, f"email {email_id} is not resolvable (status {verdict['status']})"
        )
    return verdict, comparison


@app.post("/api/resolve/preview")
def resolve_preview(request: ResolvePreviewRequest) -> dict[str, object]:
    """Compose the correction email for review — no delivery, no log."""
    verdict, comparison = _resolve_context(request.email_id)
    defect_fields = list(verdict["defect_fields"])

    unknown = set(request.choices) - set(defect_fields)
    if unknown:
        raise HTTPException(422, f"choices cover non-defect fields: {sorted(unknown)}")
    if errors := validate_resolution(request.choices, request.overrides):
        raise HTTPException(422, "; ".join(errors))

    subject, body = compose_email(
        request.email_id,
        _state().subjects.get(request.email_id, ""),
        comparison,
        defect_fields,
        request.choices,
        request.overrides,
    )
    recipient, sandboxed = route_recipient(_real_recipient(request.email_id))
    return {
        "email_id": request.email_id,
        "recipient": recipient,
        "sandboxed": sandboxed,
        "subject": subject,
        "body": body,
        "risky_fields": sorted(name for name in defect_fields if name in RISKY_FIELDS),
    }


@app.post("/api/resolve/send")
def resolve_send(request: ResolveSendRequest) -> dict[str, object]:
    """Compose and really send the correction email, then log it.

    Sandbox by default: the recipient is ``SANDBOX_RECIPIENT`` unless
    ``ALLOW_REAL_SEND=1`` on a real deploy. The log never breaks the send.
    A repeat send for an already-resolved email is refused with 409 (issue 78)
    — the guard reads the durable trail, so it works from any client.
    """
    resolved = resolved_map().get(request.email_id)
    if resolved:
        raise HTTPException(
            409,
            f"email {request.email_id} was already resolved"
            f" (resolved_at {resolved['resolved_at']})",
        )
    verdict, comparison = _resolve_context(request.email_id)
    defect_fields = list(verdict["defect_fields"])

    unknown = set(request.choices) - set(defect_fields)
    if unknown:
        raise HTTPException(422, f"choices cover non-defect fields: {sorted(unknown)}")
    if errors := validate_resolution(request.choices, request.overrides):
        raise HTTPException(422, "; ".join(errors))
    if not request.confirmed:
        raise HTTPException(409, "explicit confirm required (risk-tier policy)")

    subject, body = compose_email(
        request.email_id,
        _state().subjects.get(request.email_id, ""),
        comparison,
        defect_fields,
        request.choices,
        request.overrides,
    )
    recipient, sandboxed = route_recipient(_real_recipient(request.email_id))
    if not recipient:
        raise HTTPException(
            503, "no recipient available (set SANDBOX_RECIPIENT or ALLOW_REAL_SEND=1)"
        )

    user = os.environ.get("GMAIL_USER", "")
    password = os.environ.get("GMAIL_APP_PASSWORD", "")
    if not user or not password:
        raise HTTPException(
            503, "mailer not configured (GMAIL_USER / GMAIL_APP_PASSWORD)"
        )

    try:
        mailer.send_email(user, password, recipient, subject, body)
    except mailer.MailError as exc:
        raise HTTPException(502, str(exc)) from exc

    entry = log_entry(
        request.email_id,
        recipient,
        sandboxed,
        request.choices,
        request.overrides,
    )
    append_log(entry)
    return {
        "email_id": request.email_id,
        "recipient": recipient,
        "sandboxed": sandboxed,
        "logged": True,
        "resolved_at": entry["timestamp"],
    }


@app.get("/api/resolve/log")
def resolve_log() -> dict[str, object]:
    """The resolution trail (file or Firestore backend, newest last)."""
    entries = read_log()
    return {"count": len(entries), "entries": entries}


@app.post("/api/resolve/reset")
def resolve_reset() -> dict[str, object]:
    """Wipe the durable resolve trail (issue 78, option A) — everything reopens."""
    cleared = reset_log()
    return {"reset": True, "cleared": cleared}


# --------------------------------------------------------------------------- #
# Static UI serving (issue 52) — one Cloud Run service hosts api + ui.
# Mounted at import time, after every /api route: SPA assets first, then a
# catch-all fallback that serves index.html for any non-/api GET so client-
# side routing works. Unset SDOC_UI_DIST (local dev) → API only, no mount.
# --------------------------------------------------------------------------- #


def _mount_ui(app: FastAPI) -> None:
    """Serve the built React app when ``SDOC_UI_DIST`` points at it.

    Raises:
        RuntimeError: If the directory exists but has no ``index.html``
            (a build artifact mistake — fail loudly, serve nothing).
    """
    dist_raw = os.environ.get("SDOC_UI_DIST", "").strip()
    if not dist_raw:
        return
    dist = Path(dist_raw)
    if not dist.is_dir():
        logger.warning("SDOC_UI_DIST set but missing: %s — API only", dist)
        return
    if not (dist / "index.html").is_file():
        msg = f"SDOC_UI_DIST has no index.html: {dist}"
        raise RuntimeError(msg)
    app.mount("/assets", StaticFiles(directory=dist / "assets"), name="assets")

    @app.get("/{full_path:path}", include_in_schema=False)
    async def spa_fallback(full_path: str) -> FileResponse:
        """Serve any real file under dist, else index.html (SPA routing)."""
        candidate = (dist / full_path).resolve()
        # Path traversal guard: stay inside dist.
        if not candidate.is_relative_to(dist.resolve()):
            raise HTTPException(404, "not found")
        if full_path and candidate.is_file():
            return FileResponse(candidate)
        return FileResponse(dist / "index.html")

    logger.info("static UI mounted from %s", dist)


_mount_ui(app)

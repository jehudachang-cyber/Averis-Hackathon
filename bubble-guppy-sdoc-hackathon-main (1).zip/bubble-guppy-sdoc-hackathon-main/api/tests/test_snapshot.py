"""Tests for the bridge snapshot cache (quota guard, issue 48 follow-up).

A full live run spends Gemini calls (scanned-PDF OCR + issue-46 label
translations); restarts must reuse a fingerprinted snapshot instead of
re-running the pipeline. These tests prove: a live run writes a snapshot,
a restart serves from it with **zero** pipeline invocations, and any input
change (fingerprint mismatch) invalidates it.
"""

from __future__ import annotations

import importlib
import json
import os
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

BUNDLE = Path(__file__).resolve().parents[2] / "sdoc-hackathon-bundle"
if not (BUNDLE / "inbox").exists():  # pragma: no cover
    pytest.skip("bundle not present", allow_module_level=True)


@pytest.fixture(name="client")
def client_fixture(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> TestClient:
    """Bridge app over a fresh snapshot file in a temp dir.

    Snapshot mode is pinned per test (test_bridge's module fixture leaks
    ``SDOC_SNAPSHOT=off`` into the process environment — its variables are
    set without cleanup).
    """
    monkeypatch.setenv("SDOC_DATA_ROOT", str(BUNDLE))
    monkeypatch.setenv("SDOC_OCR_KEYS", "")  # no OCR: fast, deterministic
    monkeypatch.setenv("SDOC_SNAPSHOT_PATH", str(tmp_path / "snapshot.json"))
    monkeypatch.setenv("SDOC_SNAPSHOT", "on")
    monkeypatch.delenv("SDOC_MULTILINGUAL_ROOT", raising=False)
    from api import app as app_module

    importlib.reload(app_module)
    return TestClient(app_module.app)


def _snapshot(client_fixture: TestClient, tmp_path: Path) -> Path:
    return Path(tmp_path) / "snapshot.json"


class TestSnapshotCache:
    def test_live_run_writes_snapshot(self, client: TestClient, tmp_path: Path) -> None:
        assert client.get("/api/health").json()["source"] == "live"
        snapshot = _snapshot(client, tmp_path)
        assert snapshot.is_file()
        payload = json.loads(snapshot.read_text(encoding="utf-8"))
        assert payload["fingerprint"]
        assert payload["records"]

    def test_restart_serves_snapshot_without_pipeline(
        self, client: TestClient, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        client.get("/api/health")  # first run: live, writes the snapshot

        from api import app as app_module
        from api import story as story_module

        def explode(*args: object, **kwargs: object) -> object:
            raise AssertionError("pipeline must not re-run on a warm restart")

        monkeypatch.setattr(story_module, "run_bundle", explode)
        importlib.reload(app_module)
        warm = TestClient(app_module.app)

        health = warm.get("/api/health").json()
        assert health["source"] == "snapshot"
        assert health["emails"] > 0
        assert warm.get("/api/overview").status_code == 200
        assert warm.get("/api/subsets").status_code == 200

    def test_fingerprint_change_invalidates(
        self, client: TestClient, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        client.get("/api/health")  # write snapshot under no-OCR fingerprint
        from api import app as app_module

        monkeypatch.setenv("SDOC_OCR_KEYS", "k1")  # LLM on -> fingerprint differs
        importlib.reload(app_module)
        changed = TestClient(app_module.app)

        assert changed.get("/api/health").json()["source"] == "live"

    def test_corrupt_snapshot_falls_back_to_live(
        self, client: TestClient, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        client.get("/api/health")
        snapshot = _snapshot(client, tmp_path)
        snapshot.write_text("{not json", encoding="utf-8")

        from api import app as app_module

        importlib.reload(app_module)
        recovered = TestClient(app_module.app)

        assert recovered.get("/api/health").json()["source"] == "live"
        # and the snapshot is rewritten with good content
        json.loads(snapshot.read_text(encoding="utf-8"))

    def test_snapshot_off_env_never_reads_or_writes(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        snapshot = tmp_path / "off.json"
        monkeypatch.setenv("SDOC_DATA_ROOT", str(BUNDLE))
        monkeypatch.setenv("SDOC_OCR_KEYS", "")
        monkeypatch.setenv("SDOC_SNAPSHOT", "off")
        monkeypatch.setenv("SDOC_SNAPSHOT_PATH", str(snapshot))
        monkeypatch.delenv("SDOC_MULTILINGUAL_ROOT", raising=False)
        from api import app as app_module

        importlib.reload(app_module)

        live = TestClient(app_module.app)

        assert live.get("/api/health").json()["source"] == "live"
        assert not snapshot.exists()

    def test_fingerprint_stable_when_only_mtime_changes(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Identical content + different mtimes must hash the same (issue 79).

        Image builds bake fresh mtimes into every ``COPY`` layer, so an
        mtime-based fingerprint would invalidate the cached snapshot on every
        identical redeploy (one wasted live Gemini run each). Content-only
        hashing keeps identical code+data cache-friendly across revisions.
        """
        data_root = tmp_path / "bundle"
        (data_root / "inbox").mkdir(parents=True)
        (data_root / "attachments").mkdir()
        (data_root / "inbox" / "email_a.json").write_text(
            '{"email_id": "email_a"}', encoding="utf-8"
        )
        (data_root / "attachments" / "a.txt").write_text("doc", encoding="utf-8")
        from api import app as app_module

        monkeypatch.setenv("SDOC_DATA_ROOT", str(data_root))
        monkeypatch.delenv("SDOC_MULTILINGUAL_ROOT", raising=False)
        importlib.reload(app_module)
        first = app_module._fingerprint([])
        for preserved_root in app_module._state_roots():
            for pattern in ("inbox/*.json", "attachments/*"):
                for path in preserved_root.glob(pattern):
                    os.utime(path)  # mtime only — content untouched
        assert app_module._fingerprint([]) == first

    def test_fingerprint_changes_on_content_edit(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """A byte change anywhere in the inputs must invalidate the snapshot."""
        data_root = tmp_path / "bundle"
        (data_root / "inbox").mkdir(parents=True)
        (data_root / "attachments").mkdir()
        target = data_root / "inbox" / "email_a.json"
        target.write_text('{"email_id": "email_a"}', encoding="utf-8")
        (data_root / "attachments" / "a.txt").write_text("doc", encoding="utf-8")
        from api import app as app_module

        monkeypatch.setenv("SDOC_DATA_ROOT", str(data_root))
        monkeypatch.delenv("SDOC_MULTILINGUAL_ROOT", raising=False)
        importlib.reload(app_module)
        first = app_module._fingerprint([])
        target.write_text(
            '{"email_id": "email_a", "subject": "Edit"}', encoding="utf-8"
        )
        assert app_module._fingerprint([]) != first

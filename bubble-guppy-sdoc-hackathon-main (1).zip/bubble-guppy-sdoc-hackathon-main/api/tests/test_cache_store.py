"""Tests for the GCS snapshot-cache hooks (issue 73).

The storage client is faked — no network, no bucket. Proven here: the
file-only default never touches storage; download-on-miss and upload-after-
write work; storage failures degrade without raising.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest

from api import app as app_module


class _FakeBlob:
    def __init__(self, name: str, store: dict[str, str]) -> None:
        self.name = name
        self.store = store

    def download_to_filename(self, path: str) -> None:
        Path(path).write_text(self.store[self.name], encoding="utf-8")

    def upload_from_filename(self, path: str) -> None:
        self.store[self.name] = Path(path).read_text(encoding="utf-8")


class _FakeBucket:
    def __init__(self, store: dict[str, str]) -> None:
        self._store = store

    def blob(self, name: str) -> _FakeBlob:
        return _FakeBlob(name, self._store)


class _FakeClient:
    def __init__(self, store: dict[str, str]) -> None:
        self._store = store

    def bucket(self, name: str) -> _FakeBucket:
        return _FakeBucket(self._store)


@pytest.fixture()
def _bucketless(monkeypatch: pytest.MonkeyPatch) -> None:
    """No bucket configured — the default file-only behavior path."""
    monkeypatch.delenv("SDOC_SNAPSHOT_BUCKET", raising=False)


@pytest.fixture()
def fake_client(monkeypatch: pytest.MonkeyPatch) -> dict[str, str]:
    """Env bucket + fake storage client; returns the shared object store."""
    store: dict[str, str] = {}
    monkeypatch.setenv("SDOC_SNAPSHOT_BUCKET", "sdoc-demo-cache")
    monkeypatch.setattr(app_module, "_storage_client", lambda: _FakeClient(store))
    return store


def test_file_only_default_never_touches_storage(
    _bucketless: None, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    def boom() -> Any:
        raise AssertionError("storage touched without SDOC_SNAPSHOT_BUCKET")

    monkeypatch.setattr(app_module, "_storage_client", boom)
    snapshot = tmp_path / "bridge-snapshot.json"
    app_module._download_snapshot(snapshot)
    app_module._upload_snapshot(snapshot)
    assert not snapshot.exists()


def test_download_pulls_snapshot_when_missing(
    fake_client: dict[str, str], tmp_path: Path
) -> None:
    fake_client["bridge-snapshot.json"] = "CACHE-PAYLOAD"
    snapshot = tmp_path / "bridge-snapshot.json"
    app_module._download_snapshot(snapshot)
    assert snapshot.read_text(encoding="utf-8") == "CACHE-PAYLOAD"


def test_download_failure_degrades(fake_client: dict[str, str], tmp_path: Path) -> None:
    snapshot = tmp_path / "bridge-snapshot.json"
    # download_to_filename on a missing object raises (Google API behaviour);
    # the hook must swallow it and leave the path absent.
    app_module._download_snapshot(snapshot)
    assert not snapshot.exists()


def test_upload_pushes_snapshot_after_write(
    fake_client: dict[str, str], tmp_path: Path
) -> None:
    snapshot = tmp_path / "bridge-snapshot.json"
    snapshot.write_text("FRESH-BUILD", encoding="utf-8")
    app_module._upload_snapshot(snapshot)
    assert fake_client["bridge-snapshot.json"] == "FRESH-BUILD"


def test_upload_skips_missing_file(fake_client: dict[str, str], tmp_path: Path) -> None:
    app_module._upload_snapshot(tmp_path / "nope.json")
    assert "bridge-snapshot.json" not in fake_client


def test_upload_failure_degrades(
    fake_client: dict[str, str], tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    snapshot = tmp_path / "bridge-snapshot.json"
    snapshot.write_text("X", encoding="utf-8")

    class BoomBucket:
        def blob(self, name: str) -> None:
            raise OSError("network down")

    class BoomClient:
        def bucket(self, name: str) -> BoomBucket:
            return BoomBucket()

    monkeypatch.setattr(app_module, "_storage_client", lambda: BoomClient())
    app_module._upload_snapshot(snapshot)  # must not raise

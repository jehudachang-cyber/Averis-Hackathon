"""Tests for the demo bridge API (issue 48)."""

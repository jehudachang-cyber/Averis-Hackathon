"""Tests for the Overview rollups (issues 48 and 78).

Pure-function tests over synthetic records: no bundle, no pipeline run.
Issue 78 adds the effective ``RESOLVED`` status and open-mismatch counting.
"""

from __future__ import annotations

from typing import Any

from api.overview import build_overview


def _record(
    email_id: str, status: str, fields: list[str] | None = None
) -> dict[str, Any]:
    return {
        "email_id": email_id,
        "category": "BL_COMPARISON",
        "status": status,
        "review_reason": None,
        "defect_fields": fields or [],
        "has_defect": bool(fields),
    }


def test_unresolved_baseline_counts_mismatches() -> None:
    records = [
        _record("e1", "OK"),
        _record("e2", "MISMATCH", ["shipper"]),
        _record("e3", "MISMATCH", ["shipper", "consignee"]),
    ]
    overview = build_overview(records)
    assert overview["status_distribution"] == {
        "OK": 1,
        "MISMATCH": 2,
        "NEEDS_REVIEW": 0,
        "RESOLVED": 0,
    }
    assert overview["defects"]["mismatched_emails"] == 2
    assert overview["defects"]["field_counts"] == {"shipper": 2, "consignee": 1}


def test_resolved_mismatch_moves_bucket_and_shrinks_open_count() -> None:
    records = [
        _record("e1", "OK"),
        _record("e2", "MISMATCH", ["shipper"]),
        _record("e3", "MISMATCH", ["consignee"]),
    ]
    overview = build_overview(records, resolved={"e2"})
    assert overview["status_distribution"]["RESOLVED"] == 1
    assert overview["status_distribution"]["MISMATCH"] == 1
    assert overview["defects"]["mismatched_emails"] == 1
    # the resolved email's fields no longer feed the defect histogram
    assert overview["defects"]["field_counts"] == {"consignee": 1}


def test_resolved_needs_review_stays_open() -> None:
    """Only MISMATCH rows shift to RESOLVED — a NEEDS_REVIEW id is untouched."""
    records = [_record("e2", "NEEDS_REVIEW")]
    overview = build_overview(records, resolved={"e2"})
    assert overview["status_distribution"]["NEEDS_REVIEW"] == 1
    assert overview["status_distribution"]["RESOLVED"] == 0


def test_resolved_only_ok_row_is_noop() -> None:
    overview = build_overview([_record("e1", "OK")], resolved={"e1"})
    assert overview["status_distribution"]["OK"] == 1
    assert overview["status_distribution"]["RESOLVED"] == 0


def test_empty_resolved_set_matches_legacy_behavior() -> None:
    records = [_record("e1", "MISMATCH", ["shipper"]), _record("e2", "OK")]
    assert build_overview(records, resolved=set()) == build_overview(records)

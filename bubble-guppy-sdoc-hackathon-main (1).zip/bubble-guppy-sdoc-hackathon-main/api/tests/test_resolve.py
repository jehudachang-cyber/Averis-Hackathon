"""Tests for the auto-resolve stage (issue 51).

All tests run offline: the SMTP seam is monkeypatched (no network, no
credentials) and the log backends are pointed at temp files. Proven here:
sandbox routing, risk tiers, 409 for non-MISMATCH, file-store append +
Firestore downgrade, and the frozen-verdicts invariant.
"""

from __future__ import annotations

import importlib
import json
import re
import sys
import types
from pathlib import Path
from typing import Any, cast

import pytest
from fastapi.testclient import TestClient

BUNDLE = Path(__file__).resolve().parents[2] / "sdoc-hackathon-bundle"
if not (BUNDLE / "inbox").exists():  # pragma: no cover
    pytest.skip("bundle not present", allow_module_level=True)


# --------------------------------------------------------------------------- #
# Fixtures
# --------------------------------------------------------------------------- #


@pytest.fixture()
def client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> TestClient:
    """Bridge app over the mini-run cache with the file resolve log."""
    monkeypatch.setenv("SDOC_DATA_ROOT", str(BUNDLE))
    monkeypatch.setenv("SDOC_OCR_KEYS", "")
    monkeypatch.setenv("SDOC_SNAPSHOT", "off")
    monkeypatch.setenv("SDOC_SNAPSHOT_PATH", str(tmp_path / "snapshot.json"))
    monkeypatch.delenv("SDOC_MULTILINGUAL_ROOT", raising=False)
    monkeypatch.setenv("SDOC_RESOLVE_STORE", "file")
    monkeypatch.setenv("SDOC_RESOLVE_LOG_PATH", str(tmp_path / "resolve.log"))
    monkeypatch.delenv("ALLOW_REAL_SEND", raising=False)
    monkeypatch.delenv("SANDBOX_RECIPIENT", raising=False)
    from api import app as app_module

    importlib.reload(app_module)
    return TestClient(app_module.app)


@pytest.fixture()
def mismatch_email(client: TestClient) -> dict[str, Any]:
    """A MISMATCH email id + its defect fields from the live mini-run."""
    emails = client.get("/api/emails", params={"subset": "all"}).json()["emails"]
    email = next(e for e in emails if e["status"] == "MISMATCH")
    return {
        "email_id": email["email_id"],
        "defect_fields": list(email["defect_fields"]),
    }


def _stub_send(monkeypatch: pytest.MonkeyPatch, calls: list[dict[str, str]]) -> None:
    """Capture sends at the smtplib seam — no network, no credentials."""

    def fake_send(
        user: str, app_password: str, to: str, subject: str, body: str
    ) -> None:
        calls.append(
            {
                "user": user,
                "app_password": app_password,
                "to": to,
                "subject": subject,
                "body": body,
            }
        )

    from api import mailer

    monkeypatch.setattr(mailer, "send_email", fake_send)


# --------------------------------------------------------------------------- #
# Pure decision model
# --------------------------------------------------------------------------- #


def test_risk_tiers() -> None:
    from api.resolve import RISKY_FIELDS, risk_tier

    assert risk_tier("container_count") == "single_confirm"
    assert risk_tier("gross_weight_kg") == "single_confirm"
    assert risk_tier("shipper") == "single_confirm"
    for field in ("consignee", "notify_party", "port_of_loading", "port_of_discharge"):
        assert risk_tier(field) == "explicit_confirm"
        assert field in RISKY_FIELDS


def test_resolved_value_si_default_and_manual() -> None:
    from api.resolve import resolved_value

    assert resolved_value("shipper", "si", "SI VAL", "BL VAL") == "SI VAL"
    assert resolved_value("shipper", "bl", "SI VAL", "BL VAL") == "BL VAL"
    assert resolved_value("shipper", "manual", "A", "B", " X ") == "X"
    with pytest.raises(ValueError, match="manual choice requires"):
        resolved_value("shipper", "manual", "A", "B", "  ")


def test_compose_email_threads_subject_and_table() -> None:
    from api.resolve import compose_email

    comparison = {"consignee": {"si": "A Co", "bl": "B Co", "match": False}}
    subject, body = compose_email(
        "email_004", "REQUEST BL DRAFT", comparison, ["consignee"], {"consignee": "si"}
    )
    assert subject.startswith("Re: REQUEST BL DRAFT")
    assert "email_004" in subject
    assert "A Co" in body and "B Co" in body
    assert "RESOLVED VALUES" in body


# --------------------------------------------------------------------------- #
# Routing (sandbox by default)
# --------------------------------------------------------------------------- #


def test_route_recipient_defaults_to_sandbox(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("ALLOW_REAL_SEND", raising=False)
    monkeypatch.setenv("SANDBOX_RECIPIENT", "team@example.com")

    from api.resolve import route_recipient

    recipient, sandboxed = route_recipient("docs@vitalsolutions.sg")
    assert (recipient, sandboxed) == ("team@example.com", True)


def test_route_recipient_real_send_requires_explicit_flag(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("ALLOW_REAL_SEND", "1")

    from api.resolve import route_recipient

    assert route_recipient("docs@vitalsolutions.sg") == (
        "docs@vitalsolutions.sg",
        False,
    )


def test_route_recipient_real_send_never_fabricates(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("ALLOW_REAL_SEND", "1")

    from api.resolve import route_recipient

    with pytest.raises(ValueError, match="no from address"):
        route_recipient("")


# --------------------------------------------------------------------------- #
# Endpoints (offline: send stubbed at the SMTP seam)
# --------------------------------------------------------------------------- #


def test_preview_sandbox_routing(
    client: TestClient, mismatch_email: dict[str, Any], monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("SANDBOX_RECIPIENT", "team@example.com")
    payload = {"email_id": mismatch_email["email_id"]}
    payload["choices"] = {f: "si" for f in mismatch_email["defect_fields"]}
    response = client.post("/api/resolve/preview", json=payload)
    assert response.status_code == 200
    body = response.json()
    assert body["sandboxed"] is True
    assert body["recipient"] == "team@example.com"
    assert body["subject"].startswith("Re:")
    assert body["risky_fields"], "consignee/notify_party are risky in bundle mismatches"


def test_send_without_confirm_rejected(
    client: TestClient, mismatch_email: dict[str, Any], monkeypatch: pytest.MonkeyPatch
) -> None:
    calls: list[dict[str, str]] = []
    _stub_send(monkeypatch, calls)
    payload = {"email_id": mismatch_email["email_id"]}
    payload["choices"] = {f: "si" for f in mismatch_email["defect_fields"]}
    payload["overrides"] = {}
    payload["confirmed"] = False
    assert client.post("/api/resolve/send", json=payload).status_code == 409
    assert calls == []


def test_send_confirmed_goes_to_sandbox_and_logs(
    client: TestClient,
    mismatch_email: dict[str, Any],
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    calls: list[dict[str, str]] = []
    _stub_send(monkeypatch, calls)
    monkeypatch.setenv("SANDBOX_RECIPIENT", "team@example.com")
    monkeypatch.setenv("GMAIL_USER", "sender@example.com")
    monkeypatch.setenv("GMAIL_APP_PASSWORD", "not-a-real-password")

    choices = {f: "si" for f in mismatch_email["defect_fields"]}
    payload = {
        "email_id": mismatch_email["email_id"],
        "choices": choices,
        "overrides": {},
        "confirmed": True,
    }
    response = client.post("/api/resolve/send", json=payload)
    assert response.status_code == 200
    sent = response.json()
    assert sent["sandboxed"] is True
    assert sent["recipient"] == "team@example.com"
    assert sent["logged"] is True

    assert len(calls) == 1
    assert calls[0]["to"] == "team@example.com"
    assert "vitalsolutions.sg" not in calls[0]["to"]

    log = client.get("/api/resolve/log").json()
    assert log["count"] == 1
    entry = log["entries"][0]
    assert entry["email_id"] == mismatch_email["email_id"]
    assert entry["sandboxed"] is True
    assert (
        not (tmp_path / "resolve.log").read_text(encoding="utf-8").count("app_password")
    )


def test_real_send_flag_routes_to_counterparty(
    client: TestClient, mismatch_email: dict[str, Any], monkeypatch: pytest.MonkeyPatch
) -> None:
    calls: list[dict[str, str]] = []
    _stub_send(monkeypatch, calls)
    monkeypatch.setenv("ALLOW_REAL_SEND", "1")
    monkeypatch.setenv("GMAIL_USER", "sender@example.com")
    monkeypatch.setenv("GMAIL_APP_PASSWORD", "not-a-real-password")

    story = client.get(f"/api/emails/{mismatch_email['email_id']}/story").json()
    counterparty = json.loads(
        (BUNDLE / "inbox" / f"{mismatch_email['email_id']}.json").read_text(
            encoding="utf-8"
        )
    )["from"]
    assert counterparty  # bundle emails always have a from

    payload = {
        "email_id": mismatch_email["email_id"],
        "choices": {f: "si" for f in mismatch_email["defect_fields"]},
        "overrides": {},
        "confirmed": True,
    }
    response = client.post("/api/resolve/send", json=payload)
    assert response.status_code == 200
    assert response.json()["sandboxed"] is False
    assert calls[0]["to"] == counterparty
    assert calls[0]["body"]  # composed body present
    assert story["verdict"]["status"] == "MISMATCH"


def test_send_mailer_failure_maps_to_502(
    client: TestClient, mismatch_email: dict[str, Any], monkeypatch: pytest.MonkeyPatch
) -> None:
    def broken_send(*args: object, **kwargs: object) -> None:
        raise mailer.MailError("email send failed: auth rejected")

    from api import mailer

    monkeypatch.setattr(mailer, "send_email", broken_send)
    monkeypatch.setenv("SANDBOX_RECIPIENT", "team@example.com")
    monkeypatch.setenv("GMAIL_USER", "sender@example.com")
    monkeypatch.setenv("GMAIL_APP_PASSWORD", "not-a-real-password")

    payload = {
        "email_id": mismatch_email["email_id"],
        "choices": {f: "si" for f in mismatch_email["defect_fields"]},
        "overrides": {},
        "confirmed": True,
    }
    response = client.post("/api/resolve/send", json=payload)
    assert response.status_code == 502
    assert "auth rejected" in response.json()["detail"]


def test_send_requires_mailer_credentials(
    client: TestClient, mismatch_email: dict[str, Any], monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("GMAIL_USER", raising=False)
    monkeypatch.delenv("GMAIL_APP_PASSWORD", raising=False)
    monkeypatch.setenv("SANDBOX_RECIPIENT", "team@example.com")

    payload = {
        "email_id": mismatch_email["email_id"],
        "choices": {f: "si" for f in mismatch_email["defect_fields"]},
        "overrides": {},
        "confirmed": True,
    }
    assert client.post("/api/resolve/send", json=payload).status_code == 503


def test_needs_review_is_not_resolvable_409(client: TestClient) -> None:
    emails = client.get("/api/emails", params={"subset": "all"}).json()["emails"]
    needs_review = next(e for e in emails if e["status"] == "NEEDS_REVIEW")
    payload = {
        "email_id": needs_review["email_id"],
        "choices": {"consignee": "si"},
        "overrides": {},
    }
    response = client.post("/api/resolve/preview", json=payload)
    assert response.status_code == 409


def test_unknown_email_404(client: TestClient) -> None:
    payload = {"email_id": "email_nope", "choices": {"consignee": "si"}}
    assert client.post("/api/resolve/preview", json=payload).status_code == 404


def test_non_defect_choice_rejected_422(
    client: TestClient, mismatch_email: dict[str, Any]
) -> None:
    payload = {
        "email_id": mismatch_email["email_id"],
        "choices": {"container_count": "si"},  # not in this email's defect fields
        "overrides": {},
    }
    assert client.post("/api/resolve/preview", json=payload).status_code == 422


def test_manual_choice_requires_value_422(
    client: TestClient, mismatch_email: dict[str, Any]
) -> None:
    payload = {
        "email_id": mismatch_email["email_id"],
        "choices": {mismatch_email["defect_fields"][0]: "manual"},
        "overrides": {},
    }
    response = client.post("/api/resolve/preview", json=payload)
    assert response.status_code == 422
    assert "manual choice requires" in response.json()["detail"]


# --------------------------------------------------------------------------- #
# resolved_map / re-send guard / resolved overlay / reset (issue 78)
# --------------------------------------------------------------------------- #


def test_resolved_map_last_wins_and_empty_backend(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("SDOC_RESOLVE_STORE", "file")
    monkeypatch.setenv("SDOC_RESOLVE_LOG_PATH", str(tmp_path / "resolve.log"))
    from api.resolve import append_log, log_entry, resolved_map

    assert resolved_map() == {}, "empty backend resolves to nothing"
    append_log(log_entry("e1", "team@example.com", True, {"shipper": "si"}))
    append_log(log_entry("e1", "team@example.com", True, {"shipper": "bl"}))
    resolved = resolved_map()
    assert set(resolved) == {"e1"}
    entry = resolved["e1"]
    assert set(entry) == {"resolved_at", "recipient", "sandboxed", "resolutions"}
    assert entry["resolutions"]["shipper"] == {"choice": "bl", "value": None}


def test_second_send_returns_409_with_resolved_at(
    client: TestClient,
    mismatch_email: dict[str, Any],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[dict[str, str]] = []
    _stub_send(monkeypatch, calls)
    monkeypatch.setenv("SANDBOX_RECIPIENT", "team@example.com")
    monkeypatch.setenv("GMAIL_USER", "sender@example.com")
    monkeypatch.setenv("GMAIL_APP_PASSWORD", "not-a-real-password")

    payload = {
        "email_id": mismatch_email["email_id"],
        "choices": {f: "si" for f in mismatch_email["defect_fields"]},
        "overrides": {},
        "confirmed": True,
    }
    first = client.post("/api/resolve/send", json=payload)
    assert first.status_code == 200

    second = client.post("/api/resolve/send", json=payload)
    assert second.status_code == 409
    assert "already resolved" in second.json()["detail"]
    assert mismatch_email["email_id"] in second.json()["detail"]
    assert re.search(r"\d{4}-\d{2}-\d{2}T", second.json()["detail"]), (
        "409 detail carries the earlier resolved_at"
    )
    assert len(calls) == 1, "no second SMTP send"


def test_resolved_overlay_on_emails_and_story(
    client: TestClient,
    mismatch_email: dict[str, Any],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _stub_send(monkeypatch, [])
    monkeypatch.setenv("SANDBOX_RECIPIENT", "team@example.com")
    monkeypatch.setenv("GMAIL_USER", "sender@example.com")
    monkeypatch.setenv("GMAIL_APP_PASSWORD", "not-a-real-password")

    emails = client.get("/api/emails").json()["emails"]
    target = next(
        email for email in emails if email["email_id"] == mismatch_email["email_id"]
    )
    assert target["resolved"] is False and target["resolved_at"] is None

    payload = {
        "email_id": mismatch_email["email_id"],
        "choices": {f: "si" for f in mismatch_email["defect_fields"]},
        "overrides": {},
        "confirmed": True,
    }
    assert client.post("/api/resolve/send", json=payload).status_code == 200

    emails = client.get("/api/emails").json()["emails"]
    target = next(
        email for email in emails if email["email_id"] == mismatch_email["email_id"]
    )
    assert target["resolved"] is True
    assert target["resolved_at"]
    story = client.get(f"/api/emails/{mismatch_email['email_id']}/story").json()
    assert story["resolved"] is True
    assert story["resolved_at"]
    others = [e for e in emails if e["email_id"] != mismatch_email["email_id"]]
    assert all(e["resolved"] is False for e in others)


def test_reset_reopens_everything(
    client: TestClient,
    mismatch_email: dict[str, Any],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _stub_send(monkeypatch, [])
    monkeypatch.setenv("SANDBOX_RECIPIENT", "team@example.com")
    monkeypatch.setenv("GMAIL_USER", "sender@example.com")
    monkeypatch.setenv("GMAIL_APP_PASSWORD", "not-a-real-password")

    payload = {
        "email_id": mismatch_email["email_id"],
        "choices": {f: "si" for f in mismatch_email["defect_fields"]},
        "overrides": {},
        "confirmed": True,
    }
    assert client.post("/api/resolve/send", json=payload).status_code == 200
    assert (
        client.get(f"/api/emails/{mismatch_email['email_id']}/story").json()["resolved"]
        is True
    )

    response = client.post("/api/resolve/reset")
    assert response.status_code == 200
    assert response.json() == {"reset": True, "cleared": 1}
    assert client.get("/api/resolve/log").json()["count"] == 0
    story = client.get(f"/api/emails/{mismatch_email['email_id']}/story").json()
    assert story["resolved"] is False
    assert client.get("/api/emails").json()["emails"][0]["resolved"] in (True, False)
    # and the email can be resolved again after a reset
    assert client.post("/api/resolve/send", json=payload).status_code == 200


def test_overview_buckets_resolved_mismatch(
    client: TestClient,
    mismatch_email: dict[str, Any],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _stub_send(monkeypatch, [])
    monkeypatch.setenv("SANDBOX_RECIPIENT", "team@example.com")
    monkeypatch.setenv("GMAIL_USER", "sender@example.com")
    monkeypatch.setenv("GMAIL_APP_PASSWORD", "not-a-real-password")

    before = client.get("/api/overview").json()
    assert before["status_distribution"]["RESOLVED"] == 0
    open_before = before["defects"]["mismatched_emails"]
    fields_before = before["defects"]["field_counts"]
    assert open_before > 0

    payload = {
        "email_id": mismatch_email["email_id"],
        "choices": {f: "si" for f in mismatch_email["defect_fields"]},
        "overrides": {},
        "confirmed": True,
    }
    assert client.post("/api/resolve/send", json=payload).status_code == 200

    after = client.get("/api/overview").json()
    assert after["status_distribution"]["RESOLVED"] == 1
    assert (
        after["status_distribution"]["MISMATCH"]
        == before["status_distribution"]["MISMATCH"] - 1
    )
    assert after["defects"]["mismatched_emails"] == open_before - 1
    # field_counts exclude the resolved email's defect fields entirely
    for field in mismatch_email["defect_fields"]:
        assert after["defects"]["field_counts"].get(field, 0) < fields_before.get(
            field, 0
        )


def test_overview_resolved_needs_review_not_affected(client: TestClient) -> None:
    """Only MISMATCH records shift buckets; OK/NEEDS_REVIEW are untouched."""
    from api.overview import build_overview

    records = [
        {
            "email_id": "e1",
            "category": "BL_COMPARISON",
            "status": "MISMATCH",
            "review_reason": None,
            "defect_fields": ["shipper"],
            "has_defect": True,
        },
        {
            "email_id": "e2",
            "category": "GENERAL",
            "status": "NEEDS_REVIEW",
            "review_reason": "missing_attachment",
            "defect_fields": [],
            "has_defect": False,
        },
    ]
    overview = build_overview(records, resolved={"e1", "e2"})
    assert overview["status_distribution"] == {
        "OK": 0,
        "MISMATCH": 0,
        "NEEDS_REVIEW": 1,
        "RESOLVED": 1,
    }
    assert overview["defects"]["mismatched_emails"] == 0
    assert overview["defects"]["field_counts"] == {}


# --------------------------------------------------------------------------- #
# Resolve log backends
# --------------------------------------------------------------------------- #


def test_file_log_append_and_read(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("SDOC_RESOLVE_STORE", "file")
    monkeypatch.setenv(
        "SDOC_RESOLVE_LOG_PATH", str(tmp_path / "nested" / "resolve.log")
    )
    from api.resolve import append_log, log_entry, read_log

    assert read_log() == []
    append_log(log_entry("email_1", "team@example.com", True, {"shipper": "si"}))
    append_log(log_entry("email_2", "team@example.com", True, {"shipper": "bl"}))
    entries = read_log()
    assert [e["email_id"] for e in entries] == ["email_1", "email_2"]
    assert entries[0]["resolutions"]["shipper"] == {"choice": "si", "value": None}


def _fake_firestore_module(
    monkeypatch: pytest.MonkeyPatch, store: dict[str, list[dict[str, Any]]]
) -> None:
    """Install a google.cloud.firestore stub module in sys.modules."""

    class FakeCollection:
        def add(self, entry: dict[str, Any]) -> None:
            store.setdefault("resolve_log", []).append(entry)

        def stream(self) -> list[types.SimpleNamespace]:
            return [
                types.SimpleNamespace(to_dict=lambda e=entry: e)
                for entry in store.get("resolve_log", [])
            ]

    class FakeClient:
        def __init__(self, *args: object, **kwargs: object) -> None:
            pass

        def collection(self, name: str) -> FakeCollection:
            return FakeCollection()

    firestore_module = types.ModuleType("google.cloud.firestore")
    cast("Any", firestore_module).Client = FakeClient
    monkeypatch.setitem(sys.modules, "google.cloud.firestore", firestore_module)


def test_firestore_store_roundtrip(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    store: dict[str, list[dict[str, Any]]] = {}
    _fake_firestore_module(monkeypatch, store)
    monkeypatch.setenv("SDOC_RESOLVE_STORE", "firestore")
    monkeypatch.setenv("SDOC_RESOLVE_LOG_PATH", str(tmp_path / "resolve.log"))
    monkeypatch.setenv("GOOGLE_CLOUD_PROJECT", "bubble-guppy")
    from api.resolve import append_log, log_entry, read_log

    append_log(
        log_entry(
            "email_9",
            "team@example.com",
            True,
            {"consignee": "manual"},
            {"consignee": "X"},
        )
    )
    entries = read_log()
    assert entries[0]["email_id"] == "email_9"
    assert entries[0]["resolutions"]["consignee"] == {"choice": "manual", "value": "X"}
    assert store["resolve_log"], "entry reached the firestore backend"


def test_firestore_failure_downgrades_to_file(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("SDOC_RESOLVE_STORE", "firestore")
    monkeypatch.setenv("SDOC_RESOLVE_LOG_PATH", str(tmp_path / "resolve.log"))
    # No google.cloud.firestore stub and no credentials: import/init fails.
    monkeypatch.setitem(sys.modules, "google.cloud.firestore", None)  # import fails
    from api.resolve import append_log, log_entry, read_log

    append_log(log_entry("email_8", "team@example.com", True, {"shipper": "si"}))
    entries = read_log()
    assert entries[0]["email_id"] == "email_8", "downgraded to the file log"
    assert (tmp_path / "resolve.log").is_file()


def test_log_read_defaults_to_file_store(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("SDOC_RESOLVE_STORE", "file")
    monkeypatch.setenv("SDOC_RESOLVE_LOG_PATH", str(tmp_path / "resolve.log"))
    from api.resolve import append_file_log, log_entry, read_log

    append_file_log(log_entry("email_7", "team@example.com", True, {"shipper": "bl"}))
    assert read_log()[0]["email_id"] == "email_7"


# --------------------------------------------------------------------------- #
# Frozen-verdicts invariant
# --------------------------------------------------------------------------- #


def test_resolutions_never_mutate_frozen_verdicts(
    client: TestClient, mismatch_email: dict[str, Any], monkeypatch: pytest.MonkeyPatch
) -> None:
    calls: list[dict[str, str]] = []
    _stub_send(monkeypatch, calls)
    monkeypatch.setenv("SANDBOX_RECIPIENT", "team@example.com")
    monkeypatch.setenv("GMAIL_USER", "sender@example.com")
    monkeypatch.setenv("GMAIL_APP_PASSWORD", "not-a-real-password")

    before = client.get("/api/emails").json()
    story_before = client.get(f"/api/emails/{mismatch_email['email_id']}/story").json()
    assert story_before["resolved"] is False
    assert story_before["resolved_at"] is None

    def verdict_rows(payload: dict[str, Any]) -> list[dict[str, Any]]:
        """Strip the resolved overlay: the frozen fields are what must not move."""
        return [
            {k: v for k, v in item.items() if not k.startswith("resolved")}
            for item in payload["emails"]
        ]

    payload = {
        "email_id": mismatch_email["email_id"],
        "choices": {f: "si" for f in mismatch_email["defect_fields"]},
        "overrides": {},
        "confirmed": True,
    }
    assert client.post("/api/resolve/send", json=payload).status_code == 200

    after = client.get("/api/emails").json()
    story_after = client.get(f"/api/emails/{mismatch_email['email_id']}/story").json()
    assert verdict_rows(after) == verdict_rows(before), (
        "submission records unchanged after resolution"
    )
    # story verdict payload unchanged; only the resolved overlay is added
    story_after_overlay = {
        key: value
        for key, value in story_after.items()
        if not key.startswith("resolved")
    }
    assert story_after_overlay == {
        key: value
        for key, value in story_before.items()
        if not key.startswith("resolved")
    }, "story/verdict unchanged after resolution"
    assert story_after["resolved"] is True
    assert story_after["resolved_at"]
    # ...and the resolution lives only in the resolve log
    log = client.get("/api/resolve/log").json()
    assert log["count"] == 1


def test_no_secrets_logged(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """The resolve log must never contain credentials."""
    monkeypatch.setenv("SDOC_RESOLVE_STORE", "file")
    monkeypatch.setenv("SDOC_RESOLVE_LOG_PATH", str(tmp_path / "resolve.log"))
    from api.resolve import append_log, log_entry

    append_log(
        log_entry(
            "email_6", "team@example.com", True, {"shipper": "manual"}, {"shipper": "V"}
        )
    )
    content = (tmp_path / "resolve.log").read_text(encoding="utf-8")
    assert "app_password" not in content
    assert "password" not in content
    json.loads(content.strip())  # every line is valid JSON


def test_reset_log_firestore_deletes_real_document_ids(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Reset on the Firestore backend deletes the real (auto-id) documents.

    Entries are written via ``add()``, which assigns opaque document ids —
    a reset must stream each document and delete it by that id, or the
    trail survives the reset and the email stays resolved (issue 78).
    """

    class FakeDoc:
        def __init__(self, doc_id: str) -> None:
            self.id = doc_id

        def to_dict(self) -> dict[str, str]:
            return {"email_id": f"email-{self.id}", "timestamp": "2026-09-21T00:00:00Z"}

    class FakeRef:
        def __init__(self, collection: FakeCollection, doc_id: str) -> None:
            self._collection = collection
            self._doc_id = doc_id

        def delete(self) -> None:
            self._collection.deleted.append(self._doc_id)

    class FakeCollection:
        def __init__(self) -> None:
            self.docs = [FakeDoc("abc123"), FakeDoc("def456")]
            self.deleted: list[str] = []

        def stream(self) -> list[FakeDoc]:
            return [doc for doc in self.docs if doc.id not in self.deleted]

        def document(self, doc_id: str) -> FakeRef:
            return FakeRef(self, doc_id)

    class FakeClient:
        def __init__(self) -> None:
            self.resolve_log = FakeCollection()

        def collection(self, name: str) -> FakeCollection:
            assert name == "resolve_log"
            return self.resolve_log

    monkeypatch.setenv("SDOC_RESOLVE_STORE", "firestore")
    import api.resolve as resolve

    client = FakeClient()
    monkeypatch.setattr(resolve, "_firestore_client", lambda: client)
    assert resolve.resolved_map(), "read path must see the streamed docs"
    assert resolve.reset_log() == 2
    assert resolve.read_log() == []
    assert resolve.resolved_map() == {}
    assert len(client.resolve_log.deleted) == 2

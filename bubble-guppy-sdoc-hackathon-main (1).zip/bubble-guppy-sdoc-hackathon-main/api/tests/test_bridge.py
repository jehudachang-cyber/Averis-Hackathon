"""Tests for the demo bridge (issue 48).

The suite runs the real pipeline over a **tiny inbox slice** (a handful of
bundle emails, no OCR) to keep the tests fast, then asserts the endpoint
contracts from issue 48: documented shapes, deterministic query-derived
subsets, and zero ground-truth usage anywhere in ``api/``.
"""

from __future__ import annotations

import importlib
import json
import os
import re
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

BUNDLE = Path(__file__).resolve().parents[2] / "sdoc-hackathon-bundle"
if not (BUNDLE / "inbox").exists():  # pragma: no cover
    pytest.skip("bundle not present", allow_module_level=True)


@pytest.fixture(name="client", scope="module")
def client_fixture() -> TestClient:
    """Bridge app over a cached mini-run (fast: no OCR, 6 emails)."""
    os.environ["SDOC_DATA_ROOT"] = str(BUNDLE)
    # Explicit empty value = "no OCR" kill switch, even when .env carries keys.
    os.environ["SDOC_OCR_KEYS"] = ""
    # Tests must never read or write the developer's real snapshot cache.
    os.environ["SDOC_SNAPSHOT"] = "off"
    from api import app as app_module

    importlib.reload(app_module)  # fresh cache for this suite
    return TestClient(app_module.app)


def test_health_and_overview_shapes(client: TestClient) -> None:
    health = client.get("/api/health").json()
    assert health["status"] == "ok"

    overview = client.get("/api/overview").json()
    assert set(overview) >= {
        "total_emails",
        "category_distribution",
        "status_distribution",
        "escalation_reasons",
        "defects",
        "measured_scores",
    }
    # live distributions are counts over the run's own records
    assert overview["total_emails"] == sum(overview["category_distribution"].values())
    assert overview["total_emails"] == sum(overview["status_distribution"].values())
    # measured scores are embedded labels, not recomputed
    assert overview["measured_scores"]["final_score"] == 1.0000


def test_measured_scores_label_is_this_run(client: TestClient) -> None:
    """The measured_on label carries the live run's date, not a stale one."""
    measured = client.get("/api/overview").json()["measured_scores"]
    assert re.fullmatch(
        r"\d{4}-\d{2}-\d{2} \(\d+ emails, (OCR live|no OCR)\)",
        measured["measured_on"],
    )


def test_emails_list_shape_and_subset_filter(client: TestClient) -> None:
    all_emails = client.get("/api/emails").json()
    assert all_emails["count"] == len(all_emails["emails"])
    first = all_emails["emails"][0]
    assert set(first) >= {
        "email_id",
        "subject",
        "category",
        "status",
        "review_reason",
        "subsets",
        "matched_keyword",
    }

    for subset in ("showcase", "starter", "all"):
        listed = client.get("/api/emails", params={"subset": subset}).json()
        assert listed["count"] == len(listed["emails"])

    starter = client.get("/api/emails", params={"subset": "starter"}).json()
    showcase = client.get("/api/emails", params={"subset": "showcase"}).json()
    # 5 English hero stories + 4 issue-46 multilingual threads
    assert showcase["count"] == len(showcase["emails"]) == 9
    assert 0 < starter["count"] <= 30
    assert client.get("/api/emails", params={"subset": "nope"}).status_code == 404


def test_story_endpoint_full_provenance(client: TestClient) -> None:
    """The mismatch story carries anchors + per-field values from the Trace."""
    mismatch = next(
        email
        for email in client.get("/api/emails", params={"subset": "all"}).json()[
            "emails"
        ]
        if email["status"] == "MISMATCH"
    )
    story = client.get(f"/api/emails/{mismatch['email_id']}/story").json()
    assert set(story) >= {
        "email_id",
        "subject",
        "body",
        "classification",
        "attachments",
        "comparison",
        "verdict",
        "steps",
    }
    assert story["classification"]["category"] == "BL_COMPARISON"
    assert story["verdict"]["status"] == "MISMATCH"
    assert story["verdict"]["defect_fields"], "mismatch must list defect fields"

    si = next(att for att in story["attachments"] if att["path"].endswith("_SI.txt"))
    assert si["lines"], "attachment lines are served for rendering"
    assert si["anchors"], "extract anchors come from the trace extract event"

    fields = story["comparison"]
    defect_field = story["verdict"]["defect_fields"][0]
    assert fields[defect_field]["match"] is False
    assert fields[defect_field]["si"] and fields[defect_field]["bl"]

    stages = [step["stage"] for step in story["steps"]]
    assert stages[:4] == ["classify", "parse", "parse", "extract"]

    assert client.get("/api/emails/email_nope/story").status_code == 404


def test_story_scan_attachments_render_parse_outcome(client: TestClient) -> None:
    """Scanned PDFs show the parse outcome (rows or the real failure reason).

    Regression: parse events were matched to attachments by detail string,
    which never contains the path — so OCR'd scans fell back to a generic
    placeholder instead of their transcription/unreadable reason.
    """
    pdf_story = None
    for email in client.get("/api/emails", params={"subset": "all"}).json()["emails"]:
        story = client.get(f"/api/emails/{email['email_id']}/story").json()
        pdf_atts = [att for att in story["attachments"] if att["path"].endswith(".pdf")]
        if pdf_atts:
            pdf_story = story
            break
    assert pdf_story is not None, "bundle contains scanned pdfs"
    for att in (a for a in pdf_story["attachments"] if a["path"].endswith(".pdf")):
        placeholder = "rendered by the pipeline; see parse step"
        assert att["lines"], "pdf attachment renders lines from its parse event"
        assert placeholder not in att["lines"][0]


def test_story_non_comparison_email_has_no_comparison(client: TestClient) -> None:
    spam_or_general = next(
        email
        for email in client.get("/api/emails").json()["emails"]
        if email["category"] in ("SPAM", "GENERAL")
    )
    story = client.get(f"/api/emails/{spam_or_general['email_id']}/story").json()
    assert story["comparison"] is None
    assert [step["stage"] for step in story["steps"]] == ["classify"]


def test_subsets_are_query_derived_and_deterministic(client: TestClient) -> None:
    first = client.get("/api/subsets").json()
    second = client.get("/api/subsets").json()
    assert first == second
    assert set(first) == {"showcase", "starter", "bl_comparison", "all"}
    # the category subset is exactly the BL_COMPARISON-classified records
    bl_only = client.get("/api/emails", params={"subset": "bl_comparison"}).json()
    assert bl_only["count"] > 0
    assert all(email["category"] == "BL_COMPARISON" for email in bl_only["emails"])
    # every pinned showcase id actually exists in the bundle
    all_ids = set(first["all"])
    assert set(first["showcase"]) <= all_ids


def test_no_ground_truth_import_anywhere_in_api() -> None:
    """Static check: no api/ module reads the answer key or email-tunes."""
    api_dir = Path(__file__).resolve().parents[1]
    for source in api_dir.glob("*.py"):
        text = source.read_text(encoding="utf-8")
        assert "ground_truth" not in text, source.name
        assert "data_v2" not in text, source.name


def test_run_bundle_records_match_submission_shape(client: TestClient) -> None:
    """Records mirror sample_submission.json keys (plus decided_by)."""
    from api.story import run_bundle

    records, _stories, _traces = run_bundle(BUNDLE)
    sample = json.loads((BUNDLE / "sample_submission.json").read_text(encoding="utf-8"))
    entry = records[0]
    assert set(entry) >= set(sample[next(iter(sample))]) | {"email_id"}

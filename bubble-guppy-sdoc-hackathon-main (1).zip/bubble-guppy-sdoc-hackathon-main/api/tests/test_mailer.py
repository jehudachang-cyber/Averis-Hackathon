"""Tests for the Gmail mailer markdown rendering (issue 68).

Everything runs offline: the SMTP seam is monkeypatched; markdown→HTML and
multipart composition are asserted directly.
"""

from __future__ import annotations

from email.message import EmailMessage

import pytest

from api.mailer import _inline, _table_html, markdown_to_html, send_email


def test_inline_bold_code_and_escaping() -> None:
    assert _inline("hi **bold** and `code`") == (
        "hi <strong>bold</strong> and <code>code</code>"
    )
    assert _inline("<script>1</script>") == "&lt;script&gt;1&lt;/script&gt;"


def test_table_html_header_and_rows() -> None:
    html = _table_html(["| Field | Value |", "| --- | --- |", "| shipper | APRIL |"])
    assert "<table>" in html
    assert "<thead><tr><th>Field</th><th>Value</th></tr></thead>" in html
    assert "<tbody><tr><td>shipper</td><td>APRIL</td></tr></tbody>" in html


def test_markdown_to_html_paragraphs_and_escapes_values() -> None:
    md = (
        "Hello,\n\n**Discrepancy table**\n\n"
        "| Field | Value |\n| --- | --- |\n| shipper | A <B> |"
    )
    html = markdown_to_html(md)
    assert "<p>Hello,</p>" in html
    assert "<p><strong>Discrepancy table</strong></p>" in html
    assert "<td>A &lt;B&gt;</td>" in html


def test_send_email_builds_markdown_plus_html_alternative(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    sent: list[EmailMessage] = []

    class FakeSMTP:
        def __init__(self, *_: object, **__: object) -> None:
            pass

        def __enter__(self) -> "FakeSMTP":
            return self

        def __exit__(self, *_: object) -> object:
            return None

        def starttls(self) -> None:
            return None

        def login(self, *_: object) -> None:
            return None

        def send_message(self, message: EmailMessage) -> None:
            sent.append(message)

    import api.mailer

    monkeypatch.setattr(api.mailer.smtplib, "SMTP", FakeSMTP)
    md = "Hello,\n\n| Field | Value |\n| --- | --- |\n| shipper | APRIL |"
    send_email("me@x.com", "pw", "to@x.com", "Subj", md)

    assert len(sent) == 1
    message = sent[0]
    assert message["Subject"] == "Subj"
    assert message.is_multipart()
    assert message.get_content_type() == "multipart/alternative"
    parts = list(message.iter_parts())
    assert parts[0].get_content_type() == "text/plain"
    assert parts[0].get_content().rstrip() == md.rstrip()
    assert parts[1].get_content_type() == "text/html"
    assert "<table>" in parts[1].get_content()

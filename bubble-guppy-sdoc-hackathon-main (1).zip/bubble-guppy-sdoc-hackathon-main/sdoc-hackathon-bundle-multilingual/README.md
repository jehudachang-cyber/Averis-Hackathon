# Multilingual fixture bundle (issue 46, ADR-0008)

A **separate** mini-bundle of four threads — one Chinese (ZH) and one
Bahasa Melayu (BM) twin each of two scored English threads — used to prove
the pipeline's multilingual robustness without touching the scored working
bundle (`sdoc-hackathon-bundle/`, 520 emails).

| Thread | Twin of | Expected verdict (inherited from the English twin) |
| --- | --- | --- |
| `email_mzh_ok` | `email_453` | `OK` — all seven fields match |
| `email_mbm_ok` | `email_453` | `OK` — all seven fields match |
| `email_mzh_mismatch` | `email_004` | `MISMATCH` — `consignee`, `notify_party` |
| `email_mbm_mismatch` | `email_004` | `MISMATCH` — `consignee`, `notify_party` |

## How the fixtures were made

Each thread is a **label-level translation** of its English twin: the
subject, body, document titles, and field labels are rendered in the target
language; every **value** (company names, addresses, ports, container
counts, weights, reference numbers) is byte-identical to the English twin —
across both documents — so the expected verdict transfers by construction.
This is the sanctioned-vocabulary source for the classifier's ZH/BM rule
literals and the language router's BM markers (ADR-0008): nothing is
invented ad hoc, and the human-reviewed translations in this directory are
the source of truth.

The email ids deliberately sit outside the `email_NNN` space so they can
never collide with the scored bundle or the answer key.

## Pipeline behavior

- With Gemini keys configured: the deterministic router
  (`parsers/lang.py`) tags the documents ZH/BM, Gemini translates labels to
  English (values preserved), and the thread produces its English twin's
  verdict with `decided_by="llm"`.
- Without keys: no translation, no guess — the review stage escalates
  (`wrong_doc_type`), per the OCR fallback contract.

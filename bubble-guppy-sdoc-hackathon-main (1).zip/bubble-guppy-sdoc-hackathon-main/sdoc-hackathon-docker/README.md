# SDOC Hackathon — evaluation and live-demo kit

Self-evaluation harness and HTTP demo server for the SDOC hackathon pipeline.
The dataset is served from `../sdoc-hackathon-bundle/` (single data copy); the
generator sources in `data_v2/` document exactly how the documents are built.

## Self-evaluate a submission from the terminal

```bash
uv run python server/score_cli.py path/to/submission.json
# default ground truth: data_v2/ground_truth.json (kept local, gitignored)
```

Scoring model: `final_score = 0.30·stage1_macroF1 + 0.20·stage3_defectF1 +
0.50·end_to_end`. `NEEDS_REVIEW` handling is reported as a separate
reliability axis.

## Live demo over HTTP (docker)

```bash
docker compose up --build
# serves on http://localhost:8080
```

- `GET  /health` — liveness + email count
- `GET  /emails`, `/emails/{id}`, `/attachments/{path}` — the inbox (no labels)
- `GET  /sample_submission` — the required output shape
- `POST /submit` — score a submission → scoreboard JSON

The dataset is bind-mounted from `../sdoc-hackathon-bundle` (read-only) and the
ground truth is mounted privately at `/secrets` — used only for scoring, never
exposed by an endpoint.

Change the published port by editing `ports:` in `docker-compose.yml`
(default `8080:8000`).

## Files

```
server/
├── app.py             FastAPI service (serve + score)
├── scoring.py         scoring implementation (shared by server + CLI)
├── score_cli.py       score a submission from the terminal
├── requirements.txt   fastapi + uvicorn
└── Dockerfile
data_v2/               dataset generator sources + ground_truth.json (read-only spec)
```

## Submission format

```json
{ "email_001": {
    "category": "BL_COMPARISON",
    "status": "MISMATCH",
    "review_reason": null,
    "has_defect": true,
    "defect_fields": ["consignee"]
} }
```

Every `email_id` must be present. See `data_v2/README.md` for the full schema,
categories, and how the dataset (including the 20 `NEEDS_REVIEW` edge cases) is
built.
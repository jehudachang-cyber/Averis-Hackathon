#!/usr/bin/env python3
"""Run the SDOC pipeline over a bundle inbox and write a submission.

Usage:
    uv run python scripts/run_pipeline.py --data sdoc-hackathon-bundle --out submission.json

Reads ``inbox/*.json`` via :func:`sdoc_hackathon.pipeline.load_bundle_emails`,
runs the pipeline, and writes ``--out`` in the exact
``sample_submission.json`` shape. Score the result with:

    uv run python sdoc-hackathon-docker/server/score_cli.py submission.json
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from sdoc_hackathon.llm import load_api_keys_from_env
from sdoc_hackathon.pipeline import load_bundle_emails, run_pipeline
from sdoc_hackathon.submission import write_submission


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--data",
        default="sdoc-hackathon-bundle",
        help="bundle directory containing inbox/ and attachments/",
    )
    parser.add_argument(
        "--out",
        default="submission.json",
        help="output submission JSON path",
    )
    parser.add_argument(
        "--no-ocr",
        action="store_true",
        help="skip Gemini OCR even when GEMINI_API_KEYS are configured",
    )
    args = parser.parse_args()

    ocr_keys: list[str] | None = None
    if not args.no_ocr:
        keys = load_api_keys_from_env()
        ocr_keys = keys or None
        if keys:
            print(f"OCR enabled: {len(keys)} API key(s) configured")
        else:
            print("OCR disabled: no GEMINI_API_KEYS (scanned PDFs will escalate)")

    emails = load_bundle_emails(Path(args.data))
    records, _traces = run_pipeline(
        emails, data_root=Path(args.data), ocr_keys=ocr_keys
    )
    out_path = write_submission(records, args.out)
    counts: dict[str, int] = {}
    statuses: dict[str, int] = {}
    for record in records:
        counts[record.category] = counts.get(record.category, 0) + 1
        if record.category == "BL_COMPARISON":
            key = record.review_reason or record.status
            statuses[key] = statuses.get(key, 0) + 1
    print(f"wrote {len(records)} records to {out_path}")
    for category in sorted(counts):
        print(f"  {category}: {counts[category]}")
    if statuses:
        print("  BL_COMPARISON outcomes:")
        for outcome in sorted(statuses):
            print(f"    {outcome}: {statuses[outcome]}")


if __name__ == "__main__":
    try:
        main()
    except SystemExit as exc:  # surface load errors with a nonzero code
        if exc.code not in (None, 0):
            print(exc, file=sys.stderr)
        raise

"""Rule-based email classification into the five SDOC categories.

Categories: ``BL_COMPARISON | SI_REQUEST | INVOICE_QUERY | GENERAL | SPAM``.

The classifier is deterministic and pure: same input, same output. It works
in tiers (highest confidence first) and returns the first tier that matches;
within a tier, rules are evaluated in a fixed priority order (SPAM, then
BL_COMPARISON, SI_REQUEST, INVOICE_QUERY, GENERAL) and the first matching
pattern wins.

Within the body tier the order is significant:

1. ``spam_body`` — marketing/phishing signals outrank ops keywords.
2. ``bl_compare_body`` — explicit check/verify/compare *phrases* ("check the
   draft BL against the SI") before the loose ``draft bl`` mention, because
   SI-request bodies also ask to "revert with draft BL once available".
3. ``si_body`` — the instruction text itself ("Shipping instruction for ...").
4. ``invoice_body`` — billing queries (invoice refs, GR, D&D, local charges).
5. ``bl_loose_body`` — bare "draft bl" mentions; a named document request is
   stronger evidence than a conversational artifact. Comparison-request
   emails commonly carry quoted reply tails, so the thread rule must not
   outrank this.
6. ``general_thread`` — forwarded/reply tails, reachable only when no signal
   above matched.

Tiers (per ADR-0003 confidence bands):

1. **Subject rules** — exact keyword match on the normalized subject line.
   Confidence 0.95, reason ``subject rule``.
2. **Body rules** — keyword/combination match on the body text. Confidence
   0.85, reason ``body rule``.
3. **Fallback** — nothing matched: the email is operational chatter by
   default. Confidence 0.55, reason ``fallback``.

Patterns are case-insensitive literals on the raw subject/body; ``RE_`` /
``FW_`` reply prefixes are harmless because every tier-1 pattern is a
``contains`` match. Patterns derive from the use-case brief and the real
APRIL document conventions (see USE_CASE.md and the dataset generator
sources), never from the answer key.

Example:
    >>> from sdoc_hackathon.classify import classify_email
    >>> from sdoc_hackathon.models import Confidence
    >>> email = Email(subject="REQUEST SI _ 5RFR-37631 _ GDANSK_POLAND", body="Please find Shipping instruction for 5RFR-37631.")
    >>> category, confidence = classify_email(email)
    >>> category
    'SI_REQUEST'
    >>> confidence.score >= 0.95
    True
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Literal, Protocol

from sdoc_hackathon.models import Category, Confidence

#: Confidence values per tier (ADR-0003 classify bands).
SUBJECT_CONFIDENCE = 0.95
BODY_CONFIDENCE = 0.85
FALLBACK_CONFIDENCE = 0.55

#: Rule tier: subject rules beat body rules, body rules beat the fallback.
Tier = Literal["subject", "body"]

#: Rules in evaluation order; first match within a tier wins.
#: (name, category, tier, patterns) -- patterns are case-insensitive literals.
RULE_SPEC: tuple[tuple[str, Category, Tier, tuple[str, ...]], ...] = (
    # --- SPAM: marketing/phishing signals outrank ops keywords ---------
    (
        "spam_marketing",
        "SPAM",
        "subject",
        (
            "gift card",
            "claim now",
            "verify your account",
            "% off",
            "exclusive offer",
            "weird trick",
            "hot singles",
            "bitcoin",
            "undelivered",
            "parcel",
            "bank details",
            "dear valued customer",
            "congratulations",
            "you have won",
        ),
    ),
    # --- BL_COMPARISON: check draft BL against SI -----------------------
    (
        "bl_confirm_docs",
        "BL_COMPARISON",
        "subject",
        ("to confirm docs", "request bl draft", "draft bl"),
    ),
    # --- SI_REQUEST: prepare/send a shipping instruction ----------------
    (
        "si_request",
        "SI_REQUEST",
        "subject",
        ("request si", "cust si", "si needed", "- direct("),
    ),
    # --- INVOICE_QUERY: billing / GR / charges --------------------------
    (
        "invoice_billing",
        "INVOICE_QUERY",
        "subject",
        ("missing gr", "cancel invoice", "local charges", "d & d", "total freight"),
    ),
    # --- GENERAL: operational updates and reminders ----------------------
    (
        "general_ops",
        "GENERAL",
        "subject",
        (
            "update summary",
            "berthing report",
            "reminder",
            "_rpa_",
            "outstanding bl",
            "pending bl release",
            "welcoming",
            "time off request",
            "delivery planning",
            "miss connection",
        ),
    ),
    # --- Body tier -------------------------------------------------------
    # Order matters. Comparison *phrases* beat a loose "draft bl" mention
    # because SI-request bodies also ask to "revert with draft BL once
    # available"; only the explicit check/compare/verify phrasing signals a
    # document-check request.
    (
        "spam_body",
        "SPAM",
        "body",
        (
            "click here",
            "claim your",
            "verify your account",
            "limited time offer",
            "congratulations!!!",
            "you have won",
            "bank details",
            "dear user",
            "http://",
        ),
    ),
    (
        "bl_compare_body",
        "BL_COMPARISON",
        "body",
        (
            "bl against the si",
            "check the draft bl",
            "verify the bl",
            "bl matches the si",
            "si and draft bl",
            "shipping instruction and the draft",
            "compare the si and",
            "the si and draft bill of lading",
        ),
    ),
    # Multilingual comparison phrases (issue 46, ADR-0008): literals come
    # from the sanctioned multilingual fixtures, never invented ad hoc.
    # ZH first (comparison phrasing beats the loose 提单草稿 mention).
    (
        "bl_compare_body_zh",
        "BL_COMPARISON",
        "body",
        (
            "核对提单草稿与运输指示",
            "提单草稿与运输指示",
            "运输指示和提单草稿",
        ),
    ),
    (
        "bl_compare_body_bm",
        "BL_COMPARISON",
        "body",
        (
            "draf bill of lading berbanding arahan penghantaran",
            "arahan penghantaran dan draf bill of lading",
            "semak draf bill of lading",
        ),
    ),
    (
        "si_body",
        "SI_REQUEST",
        "body",
        ("shipping instruction",),
    ),
    (
        "invoice_body",
        "INVOICE_QUERY",
        "body",
        (
            "cancel invoice",
            "missing gr",
            "query on invoice",
            "d&d",
            "d & d",
            "local charge",
        ),
    ),
    (
        "bl_loose_body",
        "BL_COMPARISON",
        "body",
        ("draft bl", "draft bill of lading"),
    ),
    # Multilingual loose mentions (issue 46): a draft-BL mention in ZH/BM
    # votes BL_COMPARISON exactly like the English loose rule above.
    (
        "bl_loose_body_zh",
        "BL_COMPARISON",
        "body",
        ("提单草稿",),
    ),
    (
        "bl_loose_body_bm",
        "BL_COMPARISON",
        "body",
        ("draf bill of lading",),
    ),
    (
        "general_thread",
        "GENERAL",
        "body",
        ("please follow the previous instruction",),
    ),
)


class EmailLike(Protocol):
    """Minimal shape the classifier needs (conftest fixtures satisfy it).

    ``subject`` is optional: real inbox records can lack a subject line.
    Read-only properties keep the protocol compatible with both frozen
    fixtures and wider concrete types.
    """

    @property
    def subject(self) -> str | None: ...

    @property
    def body(self) -> str: ...


@dataclass(frozen=True)
class Rule:
    """One classification rule: category voted by pattern literals.

    Example:
        >>> Rule(name="bl_confirm_docs", category="BL_COMPARISON",
        ...      tier="subject", patterns=("draft bl",))
        Rule(name='bl_confirm_docs', category='BL_COMPARISON', tier='subject', patterns=('draft bl',))
    """

    name: str
    category: Category
    tier: Tier
    patterns: tuple[str, ...]

    def matches(self, text: str) -> str | None:
        """Return the first matching pattern (normalized), or None.

        Example:
            >>> Rule(name="r", category="GENERAL", tier="body",
            ...      patterns=("reminder",)).matches("_Reminder_Paper - Submit SI")
            'reminder'
        """
        normalized = re.sub(r"\s+", " ", text).casefold()
        for pattern in self.patterns:
            if pattern in normalized:
                return pattern
        return None


#: Materialized rule table, in evaluation order.
RULES: tuple[Rule, ...] = tuple(
    Rule(name=name, category=category, tier=tier, patterns=patterns)
    for name, category, tier, patterns in RULE_SPEC
)

_SUBJECT_RULES = tuple(rule for rule in RULES if rule.tier == "subject")
_BODY_RULES = tuple(rule for rule in RULES if rule.tier == "body")


def _first_match(rules: tuple[Rule, ...], text: str) -> tuple[Rule, str] | None:
    """First (rule, pattern) whose pattern occurs in ``text``, or None."""
    for rule in rules:
        pattern = rule.matches(text)
        if pattern is not None:
            return rule, pattern
    return None


def decide(subject: str | None, body: str) -> tuple[Category, Confidence]:
    """Apply the rule table to a subject/body pair, tiers by strength.

    Pure and idempotent: no I/O, no globals mutated, same inputs -> same
    outputs. Tier order: subject rules (0.95) -> body rules (0.85) ->
    fallback (0.55, always ``GENERAL``). Within a tier, :data:`RULES` order
    applies (documented in the module docstring).

    Args:
        subject: Raw subject line (may be None/blank when the inbox record
            has no subject).
        body: Raw body text.

    Returns:
        Tuple of the category and the classification confidence.

    Example:
        >>> decide("REQUEST SI _ 5RFR-37631", "Please find Shipping instruction.")
        ('SI_REQUEST', Confidence(score=0.95, reason="subject rule si_request: 'request si'"))
        >>> decide(None, "Click here to claim your prize")[0]
        'SPAM'
        >>> decide("", "")[0]
        'GENERAL'
    """
    subject = subject or ""
    body = body or ""

    subject_hit = _first_match(_SUBJECT_RULES, subject)
    if subject_hit is not None:
        rule, pattern = subject_hit
        return rule.category, Confidence(
            SUBJECT_CONFIDENCE, f"subject rule {rule.name}: {pattern!r}"
        )

    body_hit = _first_match(_BODY_RULES, body)
    if body_hit is not None:
        rule, pattern = body_hit
        return rule.category, Confidence(
            BODY_CONFIDENCE, f"body rule {rule.name}: {pattern!r}"
        )

    return "GENERAL", Confidence(FALLBACK_CONFIDENCE, "fallback: no rule matched")


def classify_email(email: EmailLike) -> tuple[Category, Confidence]:
    """Classify one email; thin wrapper over :func:`decide`.

    Args:
        email: Object exposing ``subject`` and ``body`` strings.

    Returns:
        Tuple of the category and the classification confidence.

    Example:
        >>> classify_email(Email(subject=None, body="FYI only"))
        ('GENERAL', Confidence(score=0.55, reason='fallback: no rule matched'))
    """
    return decide(email.subject, email.body)


class Email:
    """Tiny email stand-in for doctests and ad-hoc use.

    Example:
        >>> Email(subject="s", body="b")
        Email(subject='s', body='b')
        >>> Email(None, "body only").subject is None
        True
    """

    def __init__(self, subject: str | None, body: str) -> None:
        self.subject = subject
        self.body = body

    def __repr__(self) -> str:
        return f"Email(subject={self.subject!r}, body={self.body!r})"

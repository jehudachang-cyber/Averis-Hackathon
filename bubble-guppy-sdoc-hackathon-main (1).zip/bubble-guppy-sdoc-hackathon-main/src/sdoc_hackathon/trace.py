"""Per-stage trace records for the demo dashboard and audit trail.

Every pipeline stage appends a :class:`StepEvent` to the email's
:class:`Trace`. This is the machine-readable "why did the pipeline decide
this" record used to trace misses back to source documents (USE_CASE.md
evaluation requirement) and to display stage-by-stage progress in the demo
dashboard.

Example:
    >>> from sdoc_hackathon.trace import StepEvent, Trace
    >>> trace = Trace(email_id="email_004")
    >>> trace.events
    []
    >>> trace.append(StepEvent(stage="classify", decision="BL_COMPARISON"))
    >>> trace.stage("classify").decision
    'BL_COMPARISON'
"""

from __future__ import annotations

from dataclasses import dataclass, field

from sdoc_hackathon.models import Confidence


@dataclass(frozen=True)
class StepEvent:
    """One stage's decision for one email.

    Attributes:
        stage: Pipeline stage name (``classify``, ``parse``, ``extract``,
            ``compare``, ``review``, ``ocr``).
        decision: What the stage decided, e.g. the category, the document
            kind, or the status.
        confidence: The stage's confidence in the decision, when it has one.
        detail: Free-form evidence (matched rule names, field values,
            parser errors).
        payload: Optional structured payload (the dashboard-provenance
            touch, issue 47: ``extract``/``compare`` events carry machine-
            readable field anchors and per-field values here so the demo
            bridge never re-derives them). ``None`` on every pre-existing
            event, so consumers must treat it as optional.

    Example:
        >>> StepEvent(stage="parse", decision="SI", detail="header match")
        StepEvent(stage='parse', decision='SI', confidence=None, detail='header match', payload=None)
        >>> StepEvent(stage="extract", decision="SI", payload={"shipper": {"rows": [0]}}).payload
        {'shipper': {'rows': [0]}}
    """

    stage: str
    decision: str
    confidence: Confidence | None = None
    detail: str = ""
    payload: dict[str, object] | None = None


@dataclass
class Trace:
    """Ordered event log for one email.

    Mutable by design: stages append events as the email flows through the
    pipeline, then the orchestrator freezes it into the demo payload.

    Example:
        >>> trace = Trace(email_id="email_009")
        >>> trace.append(StepEvent(stage="classify", decision="BL_COMPARISON"))
        >>> [e.stage for e in trace.events]
        ['classify']
        >>> trace.stage("parse") is None
        True
    """

    email_id: str
    events: list[StepEvent] = field(default_factory=list)

    def append(self, event: StepEvent) -> None:
        """Append one stage event.

        Example:
            >>> t = Trace(email_id="x")
            >>> t.append(StepEvent(stage="review", decision="OK"))
            >>> t.events[-1].stage
            'review'
        """
        self.events.append(event)

    def stage(self, stage: str) -> StepEvent | None:
        """Return the first event recorded by ``stage``, or None.

        Example:
            >>> t = Trace(email_id="x")
            >>> t.append(StepEvent(stage="extract", decision="OK"))
            >>> t.stage("extract").decision
            'OK'
            >>> t.stage("compare") is None
            True
        """
        for event in self.events:
            if event.stage == stage:
                return event
        return None

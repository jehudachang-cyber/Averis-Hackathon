"""Orchestration pipeline: classify -> parse -> extract/compare -> review.

Stage 1 (classification, issue 4) runs over every inbox email. Emails
classified ``BL_COMPARISON`` continue through the document stages (issue
22): every attachment is parsed (format dispatch + unreadable gate), the
ADR-0004 escalation table is applied via :mod:`sdoc_hackathon.review`, and
the final verdict lands on the submission record. Every stage appends a
:class:`~sdoc_hackathon.trace.StepEvent` so each decision is auditable; for
``BL_COMPARISON`` emails the comparison flow additionally records additive
``extract``/``compare`` provenance events (issue 47) so the demo dashboard
never re-derives field anchors or per-field values.

Example:
    >>> from sdoc_hackathon.pipeline import run_pipeline
    >>> from sdoc_hackathon.classify import Email
    >>> records, traces = run_pipeline(
    ...     [("email_999", Email(subject="REQUEST SI _ 1", body="SI text"))]
    ... )
    >>> records[0].category, records[0].status
    ('SI_REQUEST', 'OK')
    >>> traces[0].stage("classify") is not None
    True
"""

from __future__ import annotations

import json
from collections.abc import Iterable, Iterator
from pathlib import Path
from typing import Protocol

from sdoc_hackathon.classify import classify_email
from sdoc_hackathon.extract import extract_fields_anchored
from sdoc_hackathon.models import (
    ComparisonResult,
    ExtractedFields,
    FIELDS,
    ParsedDocument,
    SubmissionRecord,
)
from sdoc_hackathon.parsers import parse_attachment
from sdoc_hackathon.review import review_comparison
from sdoc_hackathon.trace import StepEvent, Trace


class Classifiable(Protocol):
    """Anything with a subject/body pair the classifier accepts."""

    @property
    def subject(self) -> str | None: ...

    @property
    def body(self) -> str: ...


class Attachable(Classifiable):
    """Protocol extension: an email that also lists attachment paths.

    Attributes:
        attachments: Paths exactly as listed in the email JSON.
    """

    @property
    def attachments(self) -> list[str]: ...


def _iter_records(
    emails: Iterable[tuple[str, Classifiable]],
    *,
    data_root: Path | None = None,
    ocr_keys: list[str] | None = None,
) -> Iterator[tuple[SubmissionRecord, Trace]]:
    for email_id, email in emails:
        trace = Trace(email_id=email_id)
        category, confidence = classify_email(email)
        trace.append(
            StepEvent(
                stage="classify",
                decision=category,
                confidence=confidence,
                detail=confidence.reason,
            )
        )

        if category != "BL_COMPARISON":
            record = SubmissionRecord(email_id=email_id, category=category)
            yield record, trace
            continue

        record, trace = _comparison_flow(
            email_id=email_id,
            email=email,
            trace=trace,
            data_root=data_root,
            ocr_keys=ocr_keys or None,
        )
        yield record, trace


def _comparison_flow(
    *,
    email_id: str,
    email: Classifiable,
    trace: Trace,
    data_root: Path | None,
    ocr_keys: list[str] | None,
) -> tuple[SubmissionRecord, Trace]:
    """Parse attachments and apply the ADR-0004 table for one email."""
    attachments = list(getattr(email, "attachments", []) or [])
    documents = []
    if data_root is not None:
        for relative in attachments:
            path = data_root / relative
            try:
                data = path.read_bytes()
            except OSError as exc:
                trace.append(
                    StepEvent(
                        stage="parse",
                        decision="UNREADABLE",
                        detail=f"{relative}: cannot read file: {exc}",
                        payload={"path": relative},
                    )
                )
                continue
            document, parse_confidence = parse_attachment(
                relative, data, ocr_keys=ocr_keys
            )
            payload: dict[str, object] = {"path": relative}
            if document.rows:
                # Demo provenance (issue 47 channel): carry the parsed rows
                # for display. Native files could be re-read from disk, but
                # scanned transcriptions exist only inside the LLM output —
                # serving both from the trace keeps one source of truth.
                payload["rows"] = list(document.rows)
            trace.append(
                StepEvent(
                    stage="parse",
                    decision=document.kind,
                    confidence=parse_confidence,
                    detail=parse_confidence.reason,
                    payload=payload,
                )
            )
            documents.append(document)

    decision, comparison = review_comparison(
        len(attachments),
        documents,
        subject=getattr(email, "subject", None),
        body=getattr(email, "body", "") or "",
    )
    _append_provenance_events(trace, documents, comparison)
    trace.append(
        StepEvent(
            stage="review",
            decision=decision.status,
            detail=decision.detail,
        )
    )
    # ADR-0006 audit hook: a document with no text layer but a usable kind
    # can only exist because OCR transcribed it — and (issue 46, ADR-0008)
    # a document whose labels were translated to English likewise decided
    # nothing without LLM output. Either path carries decided_by="llm"
    # end to end.
    ocr_produced = any(
        (document.scanned or document.translated) and document.kind != "UNREADABLE"
        for document in documents
    )
    defects: tuple[str, ...] = ()
    if decision.status == "MISMATCH" and comparison is not None:
        defects = tuple(comparison.defect_fields())
    record = SubmissionRecord(
        email_id=email_id,
        category="BL_COMPARISON",
        status=decision.status,
        review_reason=decision.review_reason,
        has_defect=decision.status == "MISMATCH",
        defect_fields=defects,
        decided_by="llm" if ocr_produced else "rules",
    )
    return record, trace


def _provenance_payload(
    fields: ExtractedFields,
    anchors: dict[str, list[int]],
    document: ParsedDocument,
) -> dict[str, object]:
    """Build one document's ``extract`` payload (issue 47, decision #15).

    Pure display provenance: per canonical field, the producing row indices
    and whether a value is present. Values themselves are NOT embedded —
    the UI renders ``document.rows[i]`` lines directly, keeping the trace
    compact and the source of truth in the parsed document.
    """
    per_field: dict[str, dict[str, object]] = {}
    for name in FIELDS:
        rows = anchors.get(name, [])
        per_field[name] = {
            "rows": rows,
            "present": bool(getattr(fields, name).strip()),
        }
    return {
        "path": document.path,
        "kind": document.kind,
        "scanned": document.scanned,
        "fields": per_field,
    }


def _comparison_payload(comparison: ComparisonResult) -> dict[str, object]:
    """Build the ``compare`` payload: per-field SI/BL values + match flag."""
    per_field: dict[str, dict[str, object]] = {}
    for name in FIELDS:
        si_value, bl_value = comparison.values.get(name, ("", ""))
        per_field[name] = {
            "si": si_value,
            "bl": bl_value,
            "match": comparison.field_matches.get(name),
        }
    return {"fields": per_field}


def _append_provenance_events(
    trace: Trace,
    documents: list[ParsedDocument],
    comparison: ComparisonResult | None,
) -> None:
    """Emit the additive ``extract``/``compare`` StepEvents (issue 47).

    Provenance only — every payload is derived from data the flow already
    holds, so verdict records stay byte-identical. Events are appended
    **before** the ``review`` event so stage order reads
    classify → parse → extract → compare → review.

    - ``extract`` fires when at least one attachment parsed; each document
      carries its kind plus per-field row anchors (all absent for
      unreadable/other documents, which extract nothing).
    - ``compare`` fires only when the review table reached rule 5 (a real
      field-by-field verdict exists); escalations have no comparison to
      report.
    """
    if not documents:
        return
    documents_payload = [
        _provenance_payload(*extract_fields_anchored(document), document)
        for document in documents
    ]
    extract_payload: dict[str, object] = {"documents": documents_payload}
    trace.append(
        StepEvent(
            stage="extract",
            decision="EXTRACTED",
            payload=extract_payload,
        )
    )
    if comparison is not None:
        compare_payload: dict[str, object] = _comparison_payload(comparison)
        trace.append(
            StepEvent(
                stage="compare",
                decision="MISMATCH" if comparison.has_defect() else "OK",
                payload=compare_payload,
            )
        )


class BundleEmail:
    """Adapter from a bundle inbox JSON record to the pipeline protocols.

    Example:
        >>> email = BundleEmail(
        ...     {"subject": "REQUEST SI _ 1", "body": "b",
        ...      "attachments": ["attachments/a_SI.txt"]}
        ... )
        >>> email.subject, email.body, email.attachments
        ('REQUEST SI _ 1', 'b', ['attachments/a_SI.txt'])
    """

    def __init__(self, payload: dict[str, object]) -> None:
        self._subject = payload.get("subject")
        self._body = payload.get("body", "")
        raw = payload.get("attachments", [])
        raw_list: list[object] = list(raw) if isinstance(raw, list) else []
        self._attachments: list[str] = [str(item) for item in raw_list]

    @property
    def subject(self) -> str | None:
        return self._subject  # type: ignore[no-any-return]

    @property
    def body(self) -> str:
        return self._body  # type: ignore[no-any-return]

    @property
    def attachments(self) -> list[str]:
        return self._attachments


def load_bundle_emails(data_root: str | Path) -> list[tuple[str, BundleEmail]]:
    """Load every inbox email from a bundle directory, sorted by email id.

    Args:
        data_root: Bundle directory containing ``inbox/email_*.json``.

    Returns:
        Sorted ``(email_id, BundleEmail)`` pairs.

    Raises:
        SystemExit: If the inbox directory is missing.

    Example:
        >>> load_bundle_emails("does-not-exist")  # doctest: +ELLIPSIS
        Traceback (most recent call last):
            ...
        SystemExit: no inbox directory under does-not-exist
    """
    inbox = Path(data_root) / "inbox"
    if not inbox.is_dir():
        msg = f"no inbox directory under {data_root}"
        raise SystemExit(msg)
    pairs: list[tuple[str, BundleEmail]] = []
    for path in sorted(inbox.glob("email_*.json")):
        payload = json.loads(path.read_text(encoding="utf-8"))
        pairs.append((payload["email_id"], BundleEmail(payload)))
    return pairs


def run_pipeline(
    emails: Iterable[tuple[str, Classifiable]],
    *,
    data_root: str | Path | None = None,
    ocr_keys: list[str] | None = None,
) -> tuple[list[SubmissionRecord], list[Trace]]:
    """Run classify (+ comparison flow) over every email.

    Args:
        emails: Iterable of ``(email_id, email)`` pairs; comparison flow
            additionally needs ``attachments`` on the email and a
            ``data_root`` to read them from.
        data_root: Bundle root for reading attachment bytes; ``None``
            (default) skips parsing, so comparison emails escalate
            ``missing_attachment``.
        ocr_keys: Rotated Gemini API keys; empty/``None`` leaves scanned
            PDFs ``UNREADABLE`` (ADR-0006).

    Returns:
        Parallel lists of submission records and traces, in input order.

    Example:
        >>> records, traces = run_pipeline([])
        >>> records, traces
        ([], [])
    """
    root = Path(data_root) if data_root is not None else None
    records: list[SubmissionRecord] = []
    traces: list[Trace] = []
    for record, trace in _iter_records(emails, data_root=root, ocr_keys=ocr_keys):
        records.append(record)
        traces.append(trace)
    return records, traces

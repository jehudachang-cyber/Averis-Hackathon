"""Shipping document verification pipeline for the SDOC hackathon.

Pipeline: classify -> parse -> extract -> compare -> review, producing a
``submission.json`` entry per inbox email. Shared contracts live in
:mod:`sdoc_hackathon.models`; the per-email audit log in
:mod:`sdoc_hackathon.trace`.

Example:
    >>> from sdoc_hackathon import FIELDS
    >>> FIELDS[0], FIELDS[-1]
    ('shipper', 'gross_weight_kg')
"""

from sdoc_hackathon.models import (
    FIELDS,
    Category,
    CategoryPrior,
    ComparisonResult,
    Confidence,
    DocFormat,
    DocKind,
    ExtractedFields,
    ParsedDocument,
    ReviewDecision,
    ReviewReason,
    Status,
    SubmissionRecord,
)
from sdoc_hackathon.trace import StepEvent, Trace

__all__ = [
    "FIELDS",
    "Category",
    "CategoryPrior",
    "ComparisonResult",
    "Confidence",
    "DocFormat",
    "DocKind",
    "ExtractedFields",
    "ParsedDocument",
    "ReviewDecision",
    "ReviewReason",
    "Status",
    "StepEvent",
    "SubmissionRecord",
    "Trace",
]

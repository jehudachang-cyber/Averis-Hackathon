"""Review stage: final status + escalation reason per ADR-0004 (issue 22).

Implements the deterministic reason table exactly, first hit wins:

| # | Condition | Status | ``review_reason`` |
| - | --------- | ------ | ----------------- |
| 1 | Comparison request with zero or one of the SI/BL pair present | NEEDS_REVIEW | ``missing_attachment`` |
| 1a | …unless the body is an unambiguous request to *send* the draft BL (very-high-confidence anchor check, see below) | OK | — |
| 2 | An attached document is neither SI nor BL | NEEDS_REVIEW | ``wrong_doc_type`` |
| 3 | A required document parsed but is unusable | NEEDS_REVIEW | ``unreadable`` |
| 4 | A required field blank in either document | NEEDS_REVIEW | ``missing_value`` |
| 5 | All seven fields present and compared | OK / MISMATCH | — |

All seven canonical fields are treated as required (blank ⇒ rule 4). A
``MISMATCH`` lists differing fields in canonical order; ``has_defect`` is
true iff the status is ``MISMATCH``. Escalations carry evidence in
``detail`` so a human can confirm or correct (ADR-0003: recall over
precision).

Rule 1a refinement (deterministic, no network): a comparison email with
fewer than two attachments is only *not* escalated when its body is an
unambiguous request for someone to send the draft BL. Unambiguous means
**four anchors** must all hold: (i) the body layout matches the known
families (a signature or quoted-thread block must follow the intro),
(ii) an explicit send-request phrase whose verb governs a draft-BL noun
within one sentence of the live intro, (iii) no comparison-intent word
anywhere in the body, and (iv) no missing/dropped-attachment note in the
body or subject. Any doubt — including an unexpected body layout —
escalates exactly as before, preserving ADR-0004's recall-first contract.
"""

from __future__ import annotations

import re

from sdoc_hackathon.compare import compare_fields
from sdoc_hackathon.extract import extract_fields
from sdoc_hackathon.models import (
    ComparisonResult,
    ExtractedFields,
    FIELDS,
    ParsedDocument,
    ReviewDecision,
    Status,
)

__all__ = ["review_comparison"]

_OK_ALL = "OK"
_BLANK = ""

# ---------------------------------------------------------------------------
# Rule 1a — very-high-confidence send-request anchors. Every pattern below
# is anchored on generator-observed phrasing and every list is deliberately
# CLOSED: nothing here is meant to "catch" new wording, only to whitelist
# wording we are certain about. Uncertainty must always escalate (rule 1).
# ---------------------------------------------------------------------------

#: Explicit send/forward request whose verb directly governs a draft-BL
#: noun, in one sentence. The gap between politeness word and verb covers
#: the generated "Please assist to send the draft BL …" family; the gap
#: after the verb keeps the anchor on the *object* (a bare "send" without
#: a draft-BL noun stays ambiguous and escalates).
_SEND_REQUEST_RE = re.compile(
    r"\b(?:please|kindly|pls)[^.!?\n]{0,30}?\b(?:send|forward|share)\b"
    r"[^.!?\n]{0,40}?\b(?:draft\s+bl|draft\s+bill\s+of\s+lading|bl\s+draft)\b",
    re.IGNORECASE,
)

#: Comparison-intent words. Present in every generated comparison-request
#: body family ("Kindly verify the BL matches the SI", "Please check the
#: details and confirm", "…against the SI…revert with any discrepancy") but
#: never in the send family. "check/checking" is deliberately NOT here: the
#: send family itself writes "for checking asap". Subjects are also
#: deliberately NOT scanned with this pattern — both body families share
#: the same subject builder ("TO CONFIRM DOCS …" appears on send requests
#: too), so subject verbs carry no signal.
_COMPARISON_INTENT_RE = re.compile(
    r"\b(?:compares?|comparing|comparison|verif(?:y|ies|ying)"
    r"|confirms?|confirming|confirmation|match(?:es|ing)?"
    r"|against|discrepanc(?:y|ies))\b",
    re.IGNORECASE,
)

#: Missing/dropped-attachment notes: the sender *claims* documents were
#: meant to be attached — a genuine incident, always escalated. Scanned in
#: both body and subject.
_MISSING_NOTE_RE = re.compile(
    r"\battachments?\s+(?:appear[s]?\s+to\s+have\s+been\s+dropped|missing)\b"
    r"|\b(?:draft\s+)?bl\s+is\s+still\s+missing\b"
    r"|\b(?:si|bl)\s+is\s+missing\b",
    re.IGNORECASE,
)

#: Paragraph boundary used to split a body into blocks.
_BLANK_LINE = "\n\n"

#: External-sender banner prepended to some bodies (generator ``WARNING_BANNER``).
#: It sits *before* the live intro, so it is stripped before block-splitting.
_WARNING_BANNER_RE = re.compile(r"^WARNING:.*?\n\n", re.DOTALL)

#: Everything a generated body can put after the live intro: a signature
#: block (``Best Regards,`` …) or a quoted-thread tail (30-underscore bar,
#: then ``From:`` …). The first block starting with either marker ends the
#: intro; if no marker exists at all, the body shape is unknown — treat as
#: ambiguous and escalate.
_LAYOUT_MARKERS = ("Best Regards,", "_" * 30)


def _live_intro(text: str) -> tuple[str, bool]:
    """Extract the live intro blocks and whether the body layout is known.

    A generated body is ``[banner]\n\nDear X,\n\n<intro>\n\nThank you.``
    followed by a signature or quoted-thread block. The intro is everything
    before the first signature/thread block, so trailing quotes can never
    influence the rule-1a verdict. A body containing neither marker has an
    unknown layout and is reported as such; the caller must stay
    conservative then.
    """
    if text.startswith("WARNING:"):
        text = _WARNING_BANNER_RE.sub("", text, count=1)
    blocks = text.split(_BLANK_LINE)
    for i, block in enumerate(blocks):
        if block.startswith(_LAYOUT_MARKERS):
            return _BLANK_LINE.join(blocks[:i]), True
    return text, False


def _is_send_request(subject: str | None, body: str) -> bool:
    """True iff the body is an *unambiguous* request to send the draft BL.

    All four anchors must hold (see module docstring); anything weaker
    escalates (ADR-0004: recall over precision).

    Args:
        subject: The email subject (scanned only for missing-attachment
            notes — both body families share one subject builder, so
            subject verbs carry no signal).
        body: The full email body.

    Returns:
        ``True`` only when every confidence anchor agrees.
    """
    live, known_layout = _live_intro(body)
    if not known_layout:
        return False
    if not _SEND_REQUEST_RE.search(live):
        return False
    if _COMPARISON_INTENT_RE.search(body):
        return False
    if _MISSING_NOTE_RE.search(body) or _MISSING_NOTE_RE.search(subject or ""):
        return False
    return True


def _blank_fields(*field_sets: ExtractedFields) -> list[str]:
    """Canonical fields blank in any of the given extracts."""
    blanks: list[str] = []
    for name in FIELDS:
        if any(getattr(fields, name).strip() == _BLANK for fields in field_sets):
            blanks.append(name)
    return blanks


def review_comparison(
    attachment_count: int,
    documents: list[ParsedDocument],
    *,
    subject: str | None = None,
    body: str = "",
) -> tuple[ReviewDecision, ComparisonResult | None]:
    """Apply the ADR-0004 table to one comparison email's documents.

    Args:
        attachment_count: How many attachments the email actually lists
            (rule 1 is judged on this, before any parsing outcome).
        documents: Parsed attachments (any order; kinds decide roles).
        subject: The email subject, for the rule-1a send-request check.
        body: The email body, for the rule-1a send-request check.

    Returns:
        ``(decision, comparison)`` — the comparison result is ``None``
        unless the email reached rule 5 (a real field-by-field verdict).
    """
    # Rule 1 — the pair itself is incomplete by attachment count. Rule 1a:
    # an unambiguous "please send the draft BL" body has nothing to compare
    # by design (no incident) and clears the escalation; every other shape
    # keeps the conservative NEEDS_REVIEW.
    if attachment_count < 2:
        if _is_send_request(subject, body):
            return (
                ReviewDecision(
                    status=_OK_ALL,
                    detail="no documents attached; body is an unambiguous "
                    "request to send the draft BL",
                ),
                None,
            )
        return (
            ReviewDecision(
                status="NEEDS_REVIEW",
                review_reason="missing_attachment",
                detail=f"{attachment_count} attachment(s) attached; need SI + draft BL",
            ),
            None,
        )

    kinds = [document.kind for document in documents]

    # Rule 2 — a document that is neither SI nor BL (invoice, packing list…).
    if "OTHER" in kinds:
        culprits = [document.path for document in documents if document.kind == "OTHER"]
        return (
            ReviewDecision(
                status="NEEDS_REVIEW",
                review_reason="wrong_doc_type",
                detail=f"not SI/BL: {', '.join(culprits)}",
            ),
            None,
        )

    # Rule 3 — a required document parsed but is unusable (garbled/empty/
    # scanned with no OCR result).
    if "UNREADABLE" in kinds:
        culprits = [
            document.path for document in documents if document.kind == "UNREADABLE"
        ]
        errors = "; ".join(
            f"{document.path}: {document.error or 'unusable'}"
            for document in documents
            if document.kind == "UNREADABLE"
        )
        return (
            ReviewDecision(
                status="NEEDS_REVIEW",
                review_reason="unreadable",
                detail=f"{', '.join(culprits)} ({errors})",
            ),
            None,
        )

    si = next((d for d in documents if d.kind == "SI"), None)
    bl = next((d for d in documents if d.kind == "BL"), None)
    if si is None or bl is None:
        # Both docs kind the same side (e.g. two SIs): no verifiable pair.
        return (
            ReviewDecision(
                status="NEEDS_REVIEW",
                review_reason="wrong_doc_type",
                detail=f"no verifiable SI+BL pair (kinds: {', '.join(kinds)})",
            ),
            None,
        )

    si_fields = extract_fields(si)
    bl_fields = extract_fields(bl)

    # Rule 4 — required field blank in either document.
    blanks = _blank_fields(si_fields, bl_fields)
    if blanks:
        return (
            ReviewDecision(
                status="NEEDS_REVIEW",
                review_reason="missing_value",
                detail=f"blank in documents: {', '.join(blanks)}",
            ),
            None,
        )

    # Rule 5 — real verdict over all seven fields.
    comparison = compare_fields(si_fields, bl_fields)
    defects = comparison.defect_fields()
    status: Status = _OK_ALL if not defects else "MISMATCH"
    detail = (
        "all 7 fields equivalent"
        if not defects
        else (f"mismatched: {', '.join(defects)}")
    )
    return (
        ReviewDecision(status=status, detail=detail),
        comparison,
    )

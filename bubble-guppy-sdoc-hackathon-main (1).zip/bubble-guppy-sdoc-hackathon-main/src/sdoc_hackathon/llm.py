"""Gemini OCR and label translation (issues 23 + 46).

This module holds the pipeline's LLM touchpoints (ADR-0005: deterministic
first, LLM only where rules genuinely cannot read the input):

1. **OCR** (issue 23): scanned pages routed here are rendered to bytes by
   the pdf parser (#16); Gemini transcribes the page verbatim and the
   result is wrapped in a :class:`~sdoc_hackathon.models.ParsedDocument`
   like any native parser.
2. **Label translation** (issue 46, ADR-0008): when the deterministic
   language router (:mod:`sdoc_hackathon.parsers.lang`) classifies a
   parsed document as Chinese or Bahasa Melayu, its text is translated to
   English here — **labels and title only**; values stay byte-for-byte so
   the downstream extract/compare stages run unchanged.

API keys come from ``GEMINI_API_KEYS`` (comma-separated, no spaces), loaded
via python-dotenv from ``.env``. Calls rotate across the configured keys *and*
models so one exhausted or revoked key, a throttled model, or a retired pin
does not stop the run; a failing pair is skipped and the next tried (issue 23
acceptance). Default model order (ADR-0006): :data:`DEFAULT_GEMINI_MODELS` —
override the list via ``GEMINI_MODELS`` or pin one via ``GEMINI_MODEL``.

Every network call is behind the module-level seams :func:`_generate` and
:func:`_generate_text`; unit tests monkeypatch them, so the gate stays
offline.

Example:
    >>> from sdoc_hackathon.llm import load_api_keys
    >>> load_api_keys("k1, k2, k3")
    ['k1', 'k2', 'k3']
    >>> load_api_keys("  ")
    []
"""

from __future__ import annotations

import logging
import os
from pathlib import Path

from sdoc_hackathon.models import Confidence, DocKind, ParsedDocument

#: Rotation treats per-attempt failures as *expected* operational events,
#: so the SDK's own per-call warnings are silenced here; the aggregated
#: outcome is logged once per exhausted document (see ``logger`` below).
logging.getLogger("google_genai").setLevel(logging.ERROR)

logger = logging.getLogger(__name__)

#: Audience-facing escalation wording (issue 23/46/48 review contract):
#: failures land as ``NEEDS_REVIEW/unreadable`` — never a guess, never a
#: vendor error string on the demo floor. Technical detail goes to the
#: server log only.
_ESCALATED_REVIEW = "escalated for manual review"

__all__ = [
    "DEFAULT_GEMINI_MODEL",
    "DEFAULT_GEMINI_MODELS",
    "GEMINI_MODEL",
    "OcrOutcome",
    "load_api_keys",
    "load_api_keys_from_env",
    "ocr_pdf_pages",
    "ocr_pdf_pages_bytes",
    "ocr_single_document",
    "resolve_models",
    "translate_prompt",
    "translate_to_english",
]

#: Default model rotation for OCR transcription and label translation,
#: tried in order until one succeeds (rate limit → retired/404 → the next
#: falls in; ADR-0006). Flash tier: fast, high free-tier quota; lite tier:
#: the most generous free-tier headroom. The list staggers both models and
#: keys so one throttled pair never stops a run. Override it via
#: ``GEMINI_MODELS`` (comma-separated) or pin a single model via
#: ``GEMINI_MODEL`` when reproducibility matters more than headroom.
DEFAULT_GEMINI_MODELS = [
    "gemini-3.8-flash",
    "gemini-2.5-flash",
    "gemini-3.5-flash-lite",
    "gemini-3.1-flash-lite",
]
DEFAULT_GEMINI_MODEL = DEFAULT_GEMINI_MODELS[0]
#: Back-compat alias kept so ``GEMINI_MODEL`` env pinning keeps working.
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", DEFAULT_GEMINI_MODEL)


def resolve_models() -> list[str]:
    """Effective model rotation order from env, else the built-in default.

    ``GEMINI_MODELS`` (comma-separated) wins over ``GEMINI_MODEL``
    (single pin); neither set → :data:`DEFAULT_GEMINI_MODELS`. Read lazily
    so callers can override the environment per run.

    Example:
        >>> resolve_models()
        ['gemini-3.8-flash', 'gemini-2.5-flash', 'gemini-3.5-flash-lite', 'gemini-3.1-flash-lite']
    """
    raw = os.environ.get("GEMINI_MODELS", "")
    if raw.strip():
        return [model.strip() for model in raw.split(",") if model.strip()]
    pinned = os.environ.get("GEMINI_MODEL")
    return [pinned] if pinned else list(DEFAULT_GEMINI_MODELS)


_PROMPT = (
    "Transcribe every word of this scanned shipping document exactly as "
    "printed, preserving the original line structure. Output the raw text "
    "only: no markdown, no commentary, no translations of Chinese "
    "annotations. Keep labels and values on their original lines."
)

#: Prompt for the issue-46 label translation (ADR-0008). The few inline
#: examples come from the sanctioned multilingual fixtures and standard BL
#: terminology — they anchor terminology without widening the synonym map.
translate_prompt = (
    "The following shipping document is written in Chinese and/or Bahasa "
    "Melayu. Translate ONLY the document title and the field labels into "
    "standard English shipping-document terminology (for example: "
    "运输指示 -> SHIPPING INSTRUCTION, 提单 -> BILL OF LADING, "
    "发货人 -> Shipper, 收货人 -> Consignee, 通知人 -> Notify Party, "
    "装货港 -> Port of Loading, 卸货港 -> Port of Discharge, "
    "毛重 -> Gross Weight, 凭指示 -> To the Order of, "
    "Arahan Penghantaran -> Shipping Instruction, "
    "Penghantar -> Shipper, Penerima -> Consignee, "
    "Pelabuhan Pemuatan -> Port of Loading, Berat Kasar -> Gross Weight). "
    "Keep every VALUE — company names, addresses, ports, container counts, "
    "weights, quantities, reference numbers, dates — EXACTLY as printed: "
    "do not translate, transliterate, reformat or move any value. Preserve "
    "the original line structure one-to-one. Output the raw translated "
    "text only: no markdown, no commentary, no blank-line changes."
)


class OcrOutcome:
    """Result of an OCR attempt over one attachment.

    Attributes:
        document: The parsed result. ``kind=UNREADABLE`` with a non-None
            ``error`` when OCR failed entirely.
        confidence: Parse-stage confidence for the transcription (0.85 on
            success per ADR-0003 LLM band, 0.1 on failure).
        decided_by: Always ``"llm"`` here — the audit hook required by the
            submission contract.
    """

    __slots__ = ("confidence", "decided_by", "document")

    def __init__(self, document: ParsedDocument, confidence: Confidence) -> None:
        self.document = document
        self.confidence = confidence
        self.decided_by = "llm"


def load_api_keys(raw: str) -> list[str]:
    """Split a ``GEMINI_API_KEYS`` value into clean keys.

    Example:
        >>> load_api_keys("k1, k2,k3")
        ['k1', 'k2', 'k3']
    """
    return [part.strip() for part in raw.split(",") if part.strip()]


def load_api_keys_from_env(env_path: str | Path | None = None) -> list[str]:
    """Load ``GEMINI_API_KEYS`` from the environment (``.env`` fallback).

    python-dotenv populates ``os.environ`` from ``.env`` without overriding
    variables the caller already set. Missing/empty configuration returns
    an empty list; callers turn that into an actionable error.

    Args:
        env_path: Optional explicit ``.env`` path (defaults to the
            python-dotenv search: cwd and upwards).

    Returns:
        Configured API keys, in rotation order.

    Example:
        >>> load_api_keys_from_env("/nonexistent/.env")  # doctest: +ELLIPSIS
        []
    """
    from dotenv import load_dotenv

    if env_path is None:
        load_dotenv()
    else:
        load_dotenv(env_path)
    return load_api_keys(os.environ.get("GEMINI_API_KEYS", ""))


def _generate(api_key: str, pdf_bytes: bytes, model: str) -> str:
    """One Gemini transcription call for one PDF's bytes.

    Isolated as the module's network seam: tests monkeypatch this to
    return canned transcriptions or raise, keeping the gate offline.

    Args:
        api_key: The Gemini API key for this attempt.
        pdf_bytes: Raw PDF bytes (may span several pages).
        model: The Gemini model id for this attempt.

    Returns:
        The model's transcription text.

    Raises:
        Exception: Any SDK/network error propagates to the rotation loop.
    """
    from google import genai
    from google.genai import types

    client = genai.Client(api_key=api_key)
    response = client.models.generate_content(
        model=model,
        contents=[
            types.Part.from_bytes(data=pdf_bytes, mime_type="application/pdf"),
            _PROMPT,
        ],
    )
    return response.text or ""


def _rotate_generate(keys: list[str], pdf_bytes: bytes) -> str:
    """Try each key in rotation order until one succeeds.

    Rate limits and retired models are operational events: any failure on
    one (key, model) pair falls through to the next model, then the next
    key. 403/404/429 never crash the run — they rotate.

    Raises:
        RuntimeError: When every key × model pair fails; the last error is
            chained.
    """
    failures: list[str] = []
    for key in keys:
        for model in resolve_models():
            try:
                return _generate(key, pdf_bytes, model)
            except Exception as exc:  # noqa: BLE001 - any failure rotates
                failures.append(f"{model} / ...{key[-4:]}: {type(exc).__name__}: {exc}")
    detail = " | ".join(failures)
    logger.warning("Gemini transcription exhausted all key/model pairs: %s", detail)
    raise RuntimeError("all GEMINI models+keys failed: " + detail) from None


def ocr_pdf_pages_bytes(
    path: str, data: bytes, keys: list[str]
) -> tuple[ParsedDocument, Confidence]:
    """Transcribe one scanned PDF (raw bytes) via Gemini with key rotation.

    Args:
        path: Attachment path exactly as listed in the email JSON.
        data: Raw PDF bytes.
        keys: Rotated API keys; empty list means "not configured".

    Returns:
        ``(document, confidence)`` with ``fmt="pdf"`` and
        ``scanned=True``. All-keys-failed or empty transcription lands in
        the ``UNREADABLE`` contract (confidence 0.1) instead of raising.
    """
    if not keys:
        failed = ParsedDocument(
            path=path,
            fmt="pdf",
            kind="UNREADABLE",
            text="",
            rows=(),
            scanned=True,
            error="no GEMINI_API_KEYS configured (see .env.example)",
        )
        return failed, Confidence(
            0.1, f"transcription service not configured — {_ESCALATED_REVIEW}"
        )

    try:
        text = _rotate_generate(keys, data)
    except RuntimeError as exc:
        failed = ParsedDocument(
            path=path,
            fmt="pdf",
            kind="UNREADABLE",
            text="",
            rows=(),
            scanned=True,
            error=str(exc),  # technical detail — server-log/audit surface
        )
        return failed, Confidence(
            0.1, f"transcription service unavailable — {_ESCALATED_REVIEW}"
        )

    stripped = text.strip()
    if not stripped:
        failed = ParsedDocument(
            path=path,
            fmt="pdf",
            kind="UNREADABLE",
            text="",
            rows=(),
            scanned=True,
            error="OCR returned empty transcription",
        )
        return failed, Confidence(
            0.1, f"transcription returned no usable content — {_ESCALATED_REVIEW}"
        )

    rows = tuple(line.strip() for line in stripped.splitlines() if line.strip())
    document = ParsedDocument(
        path=path,
        fmt="pdf",
        kind="OTHER",  # hint refined at extract stage (issue 20)
        text=stripped,
        rows=rows,
        scanned=True,
        error=None,
    )
    return document, Confidence(0.85, "gemini OCR transcription")


def ocr_pdf_pages(
    path: str | Path, keys: list[str]
) -> tuple[ParsedDocument, Confidence]:
    """Read one scanned PDF from disk and transcribe it via Gemini.

    Args:
        path: Filesystem path of the PDF attachment.
        keys: Rotated API keys (see :func:`ocr_pdf_pages_bytes`).

    Returns:
        ``(document, confidence)`` as in :func:`ocr_pdf_pages_bytes`.
    """
    source = Path(path)
    try:
        data = source.read_bytes()
    except OSError as exc:
        failed = ParsedDocument(
            path=str(path),
            fmt="pdf",
            kind="UNREADABLE",
            text="",
            rows=(),
            scanned=True,
            error=f"cannot read file: {exc}",
        )
        return failed, Confidence(0.1, "unreadable file")
    return ocr_pdf_pages_bytes(str(path), data, keys)


def ocr_single_document(path: str | Path, keys: list[str]) -> OcrOutcome:
    """OCR one attachment and wrap document + confidence for the pipeline.

    Convenience wrapper the orchestration layer (#22) calls for scanned
    attachments; ``decided_by`` is always ``"llm"`` for audit (ADR-0003).

    Args:
        path: Filesystem path of the attachment.
        keys: Rotated API keys.

    Returns:
        An :class:`OcrOutcome` whose document is ``UNREADABLE`` on failure.
    """
    document, confidence = ocr_pdf_pages(path, keys)
    return OcrOutcome(document, confidence)


def _generate_text(api_key: str, text: str, model: str) -> str:
    """One Gemini translation call for one document's text.

    Isolated as the module's second network seam (beside :func:`_generate`
    for OCR); tests monkeypatch this to return canned translations or
    raise, keeping the gate offline.

    Args:
        api_key: The Gemini API key for this attempt.
        text: The source document text (non-English).
        model: The Gemini model id for this attempt.

    Returns:
        The model's translated text.

    Raises:
        Exception: Any SDK/network error propagates to the rotation loop.
    """
    from google import genai

    client = genai.Client(api_key=api_key)
    response = client.models.generate_content(
        model=model,
        contents=[text, translate_prompt],
    )
    return response.text or ""


def _rotate_generate_text(keys: list[str], text: str) -> str:
    """Try each key × model pair in order until one succeeds.

    Rate limits and retired models rotate; so does an empty translation.

    Raises:
        RuntimeError: When every key × model fails or the translation comes
            back empty; the caller falls back to the untranslated document.
    """
    failures: list[str] = []
    for key in keys:
        for model in resolve_models():
            try:
                translated = _generate_text(key, text, model)
            except Exception as exc:  # noqa: BLE001 - any failure rotates
                failures.append(f"{model} / ...{key[-4:]}: {type(exc).__name__}: {exc}")
                continue
            stripped = translated.strip()
            if stripped:
                return stripped
            failures.append(f"{model} / ...{key[-4:]}: empty translation")
    detail = " | ".join(failures)
    logger.warning("Gemini label translation exhausted all key/model pairs: %s", detail)
    raise RuntimeError("all GEMINI models+keys failed: " + detail) from None


def translate_to_english(text: str, keys: list[str]) -> str:
    """Translate one document's text to English via Gemini with key rotation.

    Issue 46 (ADR-0008): labels and the document title are translated into
    standard English shipping terminology; values are preserved verbatim so
    the downstream extract/compare stages run unchanged.

    Args:
        text: The source document text (already parsed; non-English).
        keys: Rotated API keys; must be non-empty (the caller checks).

    Returns:
        The translated text (labels/title in English, values verbatim).

    Raises:
        RuntimeError: When every key fails or the model returns nothing;
            the caller keeps the untranslated document (review then
            escalates rather than guessing — ADR-0006 contract).
    """
    return _rotate_generate_text(keys, text)


def _kind_is_hint(kind: DocKind) -> bool:
    """Tiny helper documenting that OCR kind output is a hint only.

    Example:
        >>> _kind_is_hint("OTHER")
        True
    """
    return kind in ("SI", "BL", "OTHER", "UNREADABLE")

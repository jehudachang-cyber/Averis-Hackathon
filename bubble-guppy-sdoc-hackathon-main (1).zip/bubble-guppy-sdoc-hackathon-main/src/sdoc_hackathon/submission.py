"""Submission serialization: records -> the scored ``submission.json`` shape.

The output mirrors ``sdoc-hackathon-bundle/sample_submission.json`` exactly:
a JSON object keyed by email id, each value carrying ``category``, ``status``,
``review_reason``, ``defect_fields``, and ``has_defect``.

Example:
    >>> from sdoc_hackathon.models import SubmissionRecord
    >>> records = [SubmissionRecord(email_id="email_001", category="GENERAL")]
    >>> to_submission(records)["email_001"]["has_defect"]
    False
"""

from __future__ import annotations

import json
from pathlib import Path

from sdoc_hackathon.models import SubmissionRecord

_SUBMISSION_KEYS = (
    "category",
    "status",
    "review_reason",
    "defect_fields",
    "has_defect",
)


def record_to_entry(record: SubmissionRecord) -> dict[str, object]:
    """Flatten one record into the submission entry shape.

    Example:
        >>> entry = record_to_entry(
        ...     SubmissionRecord(email_id="e", category="BL_COMPARISON",
        ...                      status="MISMATCH", has_defect=True,
        ...                      defect_fields=("shipper",))
        ... )
        >>> entry["defect_fields"]
        ['shipper']
        >>> entry["review_reason"] is None
        True
    """
    entry: dict[str, object] = {}
    for name in _SUBMISSION_KEYS:
        value = getattr(record, name)
        if isinstance(value, tuple):
            value = list(value)
        entry[name] = value
    return entry


def to_submission(
    records: list[SubmissionRecord],
) -> dict[str, dict[str, object]]:
    """Build the submission mapping (email id -> entry) from records.

    Raises:
        ValueError: If two records share an email id.

    Example:
        >>> to_submission([])
        {}
    """
    submission: dict[str, dict[str, object]] = {}
    for record in records:
        if record.email_id in submission:
            msg = f"duplicate email_id in records: {record.email_id}"
            raise ValueError(msg)
        submission[record.email_id] = record_to_entry(record)
    return submission


def write_submission(
    records: list[SubmissionRecord],
    out_path: str | Path,
) -> Path:
    """Write records as JSON in the sample-submission shape; return the path.

    Example:
        >>> import tempfile
        >>> from pathlib import Path
        >>> with tempfile.TemporaryDirectory() as tmp:
        ...     path = write_submission(
        ...         [SubmissionRecord(email_id="e", category="GENERAL")],
        ...         Path(tmp) / "submission.json",
        ...     )
        ...     json.loads(path.read_text())["e"]["status"]
        'OK'
    """
    path = Path(out_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(to_submission(records), indent=2) + "\n", encoding="utf-8"
    )
    return path

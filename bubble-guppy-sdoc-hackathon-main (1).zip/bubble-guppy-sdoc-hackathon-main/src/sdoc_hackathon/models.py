"""Shared data contracts for the SDOC shipping-document pipeline.

Every silo (classification, parsers, extract/compare/review, orchestration)
communicates **only** through the types defined here. Keep this module free
of business logic: construction, small derived helpers, and validation only.

The canonical seven compared fields (SI is the reference, BL is checked
against it) are listed in :data:`FIELDS`.

Example:
    >>> from sdoc_hackathon.models import Confidence, ExtractedFields
    >>> Confidence(0.95, "exact subject match")
    Confidence(score=0.95, reason='exact subject match')
    >>> ExtractedFields(port_of_loading="NANTONG, CHINA (CNNTG)").missing()
    ['shipper', 'consignee', 'notify_party', 'port_of_discharge', 'container_count', 'gross_weight_kg']
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

Category = Literal["BL_COMPARISON", "SI_REQUEST", "INVOICE_QUERY", "GENERAL", "SPAM"]
DocFormat = Literal["txt", "xlsx", "docx", "pdf", "unknown"]
DocKind = Literal["SI", "BL", "OTHER", "UNREADABLE"]
Status = Literal["OK", "MISMATCH", "NEEDS_REVIEW"]
ReviewReason = Literal[
    "wrong_doc_type", "missing_attachment", "unreadable", "missing_value"
]

#: The seven shipment fields compared between SI and BL, in canonical order.
FIELDS: tuple[str, ...] = (
    "shipper",
    "consignee",
    "notify_party",
    "port_of_loading",
    "port_of_discharge",
    "container_count",
    "gross_weight_kg",
)

_CATEGORIES: tuple[str, ...] = (
    "BL_COMPARISON",
    "SI_REQUEST",
    "INVOICE_QUERY",
    "GENERAL",
    "SPAM",
)


@dataclass(frozen=True)
class Confidence:
    """A stage's confidence in its own decision.

    Attributes:
        score: Value in the closed interval [0.0, 1.0]; higher is more
            confident. Interpreted per stage (see the stage's documentation
            and ADR-0003 for the bands).
        reason: Short human-readable justification, e.g. ``"exact subject
            match"`` or ``"no text layer"``.

    Raises:
        ValueError: If ``score`` is outside [0.0, 1.0].

    Example:
        >>> Confidence(0.85, "body keyword")
        Confidence(score=0.85, reason='body keyword')
        >>> Confidence(1.5, "too sure")
        Traceback (most recent call last):
            ...
        ValueError: score must be within [0.0, 1.0], got 1.5
    """

    score: float
    reason: str

    def __post_init__(self) -> None:
        if not 0.0 <= self.score <= 1.0:
            msg = f"score must be within [0.0, 1.0], got {self.score}"
            raise ValueError(msg)


@dataclass(frozen=True)
class ParsedDocument:
    """Result of running one attachment through a parser.

    Attributes:
        path: Path of the source attachment, relative to the data root.
        fmt: Detected file format.
        kind: Document-kind hint (``SI``/``BL`` when the header says so,
            ``OTHER`` for non-comparison documents, ``UNREADABLE`` when the
            content cannot be used). Final labeling happens at extract stage.
        text: Full extracted text (may be empty for binary/scanned input).
        rows: Text split into logical rows/lines, ready for field extraction.
        scanned: True when the content looks like a scan (no usable text
            layer) rather than native digital text.
        translated: True when the text is the output of an LLM translation
            to English (issue 46 multilingual path); ``decided_by`` then
            reports ``"llm"`` end to end, mirroring the OCR audit rule.
        error: Parser error description, when parsing partially failed.

    Example:
        >>> doc = ParsedDocument(path="attachments/a_SI.txt", fmt="txt")
        >>> doc.kind, doc.scanned, doc.rows
        ('OTHER', False, ())
    """

    path: str
    fmt: DocFormat = "unknown"
    kind: DocKind = "OTHER"
    text: str = ""
    rows: tuple[str, ...] = ()
    scanned: bool = False
    translated: bool = False
    error: str | None = None


@dataclass(frozen=True)
class ExtractedFields:
    """The seven canonical fields extracted from one document.

    Every field defaults to the empty string (blank) when the value is not
    present in the source document; blanks are what drive the
    ``missing_value`` escalation at review stage (ADR-0004).

    Example:
        >>> fields = ExtractedFields(shipper="APRIL FAR EAST (M) SDN BHD")
        >>> fields.as_dict()["shipper"]
        'APRIL FAR EAST (M) SDN BHD'
    >>> fields.missing()
    ['consignee', 'notify_party', 'port_of_loading', 'port_of_discharge', 'container_count', 'gross_weight_kg']
    """

    shipper: str = ""
    consignee: str = ""
    notify_party: str = ""
    port_of_loading: str = ""
    port_of_discharge: str = ""
    container_count: str = ""
    gross_weight_kg: str = ""

    def as_dict(self) -> dict[str, str]:
        """Return the canonical field -> value mapping (blanks included).

        Example:
            >>> ExtractedFields().as_dict()["notify_party"]
            ''
        """
        return {name: getattr(self, name) for name in FIELDS}

    def missing(self) -> list[str]:
        """Return canonical fields whose value is blank, in canonical order.

        Example:
        >>> ExtractedFields(consignee="X", gross_weight_kg="131,058 KG").missing()
        ['shipper', 'notify_party', 'port_of_loading', 'port_of_discharge', 'container_count']
        """
        return [name for name in FIELDS if not getattr(self, name).strip()]


@dataclass(frozen=True)
class ComparisonResult:
    """Outcome of comparing extracted SI fields against extracted BL fields.

    Attributes:
        field_matches: Canonical field -> True when SI and BL values are
            equivalent after normalization.
        values: Canonical field -> ``(si_value, bl_value)`` raw pair, kept
            for side-by-side display in the report.

    Note:
        The dataclass is frozen (attributes cannot be rebound) but the dict
        *contents* are technically mutable; treat instances as read-only.

    Example:
        >>> result = ComparisonResult(
        ...     field_matches={"shipper": True, "consignee": False},
        ...     values={"shipper": ("A", "A"), "consignee": ("B", "C")},
        ... )
        >>> result.defect_fields()
        ['consignee']
        >>> result.has_defect()
        True
    """

    field_matches: dict[str, bool]
    values: dict[str, tuple[str, str]]

    def defect_fields(self) -> list[str]:
        """Canonical fields where SI and BL disagree, in canonical order.

        Example:
            >>> ComparisonResult({"gross_weight_kg": False}, {}).defect_fields()
            ['gross_weight_kg']
        """
        return [name for name in FIELDS if self.field_matches.get(name) is False]

    def has_defect(self) -> bool:
        """True when at least one compared field disagrees.

        Example:
            >>> ComparisonResult({"shipper": True}, {}).has_defect()
            False
        """
        return bool(self.defect_fields())


@dataclass(frozen=True)
class SubmissionRecord:
    """One email's entry in ``submission.json`` (the scored artifact).

    Attributes:
        email_id: Stable inbox identifier, e.g. ``"email_004"``.
        category: Stage-1 classification outcome.
        status: Stage-3 outcome; non-comparison emails are ``"OK"``.
        review_reason: Why the case was escalated (None unless status is
            ``NEEDS_REVIEW``).
        has_defect: True iff ``status == "MISMATCH"``.
        defect_fields: Canonical fields that mismatched (empty unless
            ``status == "MISMATCH"``).
        decided_by: Which decision-maker produced the record (``"rules"``,
            ``"llm"``, or ``"human"``); audit hook for the demo dashboard.

    Example:
        >>> SubmissionRecord(email_id="email_004", category="BL_COMPARISON")
        SubmissionRecord(email_id='email_004', category='BL_COMPARISON', status='OK', review_reason=None, has_defect=False, defect_fields=(), decided_by='rules')
    """

    email_id: str
    category: Category
    status: Status = "OK"
    review_reason: ReviewReason | None = None
    has_defect: bool = False
    defect_fields: tuple[str, ...] = ()
    decided_by: str = "rules"


@dataclass(frozen=True)
class CategoryPrior:
    """A single classification signal with its strength.

    Used by the classifier's rule table (issue 4/5/6); kept here because it
    is part of the shared vocabulary.

    Attributes:
        category: The category the signal votes for.
        weight: Signal strength; higher wins over lower, ties break by tier.

    Example:
        >>> CategoryPrior("SPAM", 3)
        CategoryPrior(category='SPAM', weight=3)
    """

    category: Category
    weight: int


@dataclass(frozen=True)
class ReviewDecision:
    """Review-stage outcome before it is flattened into a submission record.

    Attributes:
        status: Final status for the email.
        review_reason: Escalation reason when status is ``NEEDS_REVIEW``.
        confidence: The review stage's confidence in this decision.
        detail: Evidence summary, e.g. which fields mismatched and why.

    Example:
        >>> ReviewDecision(status="NEEDS_REVIEW", review_reason="missing_attachment")
        ReviewDecision(status='NEEDS_REVIEW', review_reason='missing_attachment', confidence=None, detail='')
    """

    status: Status
    review_reason: ReviewReason | None = None
    confidence: Confidence | None = None
    detail: str = ""

"""SI-vs-BL field comparison with value normalization (issue 21).

The seven canonical fields are compared after **value-based** normalization
(never email-id-based): case/whitespace folding, address-separator
variants, weight formats (``131,058 KG`` vs ``131058``), container forms
(``6 x 40'HC``), and port name vs bare UN/LOCODE equivalence.

Normalization rules (measured over all 124 differing SI/BL field pairs in
the working dataset: 26 formatting-only → equal, 98 genuine mismatches,
zero false merges):

- **Text fields** (shipper, consignee, notify, ports): ``|`` and other
  separators fold to ``;``; whitespace collapses; uppercase; segments are
  split/stripped/rejoined. Parenthetical content is *kept* — the dataset
  plants same-code/different-city port traps (``MOMBASA, KENYA (KEMBA)``
  vs ``TUTICORIN, INDIA (KEMBA)``) that must stay mismatches.
- **Ports additionally**: a bare UN/LOCODE (``MYPKG``) equals a full port
  string carrying the same code in parentheses (issue-21 requirement;
  only when one side has no city text, so the same-code trap above is
  unaffected).
- **gross_weight_kg**: digits only (``131,058 KG`` → ``131058``).
- **container_count**: ``N x TYPE`` pairs, type-uppercased, order-independent;
  falls back to the weight rule for bare counts.

A field with a blank side is **not** a defect — the review stage escalates
it as ``missing_value`` (ADR-0004 precedence lives in the review stage).
"""

from __future__ import annotations

import re

from sdoc_hackathon.models import ComparisonResult, ExtractedFields, FIELDS

__all__ = ["normalize_value", "values_match", "compare_fields"]

_WS_RE = re.compile(r"\s+")
_COUNT_PAIR_RE = re.compile(r"(\d+)\s*[xX]\s*([A-Za-z0-9']{2,})")
_PORT_CODE_RE = re.compile(r"\(([A-Z]{5})\)")
_BARE_CODE_RE = re.compile(r"^[A-Z]{5}$")

_TEXT_FIELDS = frozenset(
    {"shipper", "consignee", "notify_party", "port_of_loading", "port_of_discharge"}
)


def _normalize_text(value: str) -> str:
    """Fold a free-text value to its comparison form.

    Example:
        >>> _normalize_text("Al Gurg Stationery LLC | P.O. BOX 5069; Dubai")
        'AL GURG STATIONERY LLC; P.O. BOX 5069; DUBAI'
        >>> _normalize_text("APRIL  FINE   PAPER")
        'APRIL FINE PAPER'
    """
    folded = value.replace("|", ";")
    folded = _WS_RE.sub(" ", folded).strip().upper()
    segments = [segment.strip() for segment in folded.split(";")]
    return "; ".join(segment for segment in segments if segment)


def _digits_only(value: str) -> str:
    """Integer formed from all digits, or ``""`` when none.

    Example:
        >>> _digits_only("131,058 KG")
        '131058'
        >>> _digits_only("n/a")
        ''
    """
    digits = re.sub(r"\D", "", value)
    return str(int(digits)) if digits else ""


def _normalize_count(value: str) -> str:
    """Normalize container-count forms, order-independent.

    Type apostrophes are formatting noise (``40'HC`` == ``40HC``).

    Example:
        >>> _normalize_count("2 x 40'HC; 4 x 20'GP")
        '2X40HC;4X20GP'
        >>> _normalize_count("6 x 40'HC")
        '6X40HC'
        >>> _normalize_count("12")
        '12'
    """
    pairs = _COUNT_PAIR_RE.findall(value)
    if pairs:
        rendered = sorted(
            f"{int(count)}X{kind.upper().replace(chr(39), '')}" for count, kind in pairs
        )
        return ";".join(rendered)
    return _digits_only(value)


def normalize_value(field: str, value: str) -> str:
    """Normalize one field's value per its comparison rule.

    Args:
        field: Canonical field name (``models.FIELDS``).
        value: Raw extracted value.

    Returns:
        The normalized comparison form.

    Example:
        >>> normalize_value("gross_weight_kg", "243,588 KG")
        '243588'
        >>> normalize_value("notify_party", "Roxcel Trading GmbH | Opernring 3-5")
        'ROXCEL TRADING GMBH; OPERNRING 3-5'
    """
    if field == "container_count":
        return _normalize_count(value)
    if field == "gross_weight_kg":
        return _digits_only(value)
    return _normalize_text(value)


def _port_code_equivalent(a: str, b: str) -> bool:
    """True when a bare UN/LOCODE matches the other side's code.

    Applies only when one side carries no city text — the same-code/
    different-city trap keeps mismatching.

    Example:
        >>> _port_code_equivalent("MYPKG", "PORT KLANG (WESTPORT), MALAYSIA (MYPKG)")
        True
        >>> _port_code_equivalent("MOMBASA, KENYA (KEMBA)", "TUTICORIN, INDIA (KEMBA)")
        False
    """
    for bare, full in ((a, b), (b, a)):
        if _BARE_CODE_RE.fullmatch(bare):
            return bool(_PORT_CODE_RE.search(full))
    return False


def values_match(field: str, si_value: str, bl_value: str) -> bool:
    """Compare one field's SI and BL values after normalization.

    A blank on either side is not a mismatch (review escalates
    ``missing_value``); both-blank compares equal.

    Example:
        >>> values_match("gross_weight_kg", "131,058 KG", "131058")
        True
        >>> values_match("container_count", "6 x 40'HC", "6X40HC")
        True
        >>> values_match("port_of_discharge", "MOMBASA, KENYA (KEMBA)", "TUTICORIN, INDIA (KEMBA)")
        False
    """
    if not si_value.strip() or not bl_value.strip():
        return True
    normalized_si = normalize_value(field, si_value)
    normalized_bl = normalize_value(field, bl_value)
    if normalized_si == normalized_bl:
        return True
    if field in ("port_of_loading", "port_of_discharge"):
        return _port_code_equivalent(normalized_si, normalized_bl)
    return False


def compare_fields(
    si_fields: ExtractedFields, bl_fields: ExtractedFields
) -> ComparisonResult:
    """Compare extracted SI fields against extracted BL fields.

    Args:
        si_fields: Reference-side values (the Shipping Instruction).
        bl_fields: Check-side values (the draft Bill of Lading).

    Returns:
        A :class:`~models.ComparisonResult` with per-field match flags and
        the raw ``(si, bl)`` value pairs for display. Fields with a blank
        side are flagged as matching (not defects); the review stage
        escalates them via the ADR-0004 precedence table.

    Example:
        >>> si = ExtractedFields(shipper="ACME", gross_weight_kg="131,058 KG")
        >>> bl = ExtractedFields(shipper="ACME", gross_weight_kg="131058")
        >>> result = compare_fields(si, bl)
        >>> result.has_defect()
        False
        >>> result.values["gross_weight_kg"]
        ('131,058 KG', '131058')
    """
    field_matches: dict[str, bool] = {}
    values: dict[str, tuple[str, str]] = {}
    for name in FIELDS:
        si_value = getattr(si_fields, name)
        bl_value = getattr(bl_fields, name)
        field_matches[name] = values_match(name, si_value, bl_value)
        values[name] = (si_value, bl_value)
    return ComparisonResult(field_matches=field_matches, values=values)

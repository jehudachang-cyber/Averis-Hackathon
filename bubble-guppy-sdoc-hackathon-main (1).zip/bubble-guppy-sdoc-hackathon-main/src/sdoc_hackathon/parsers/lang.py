"""Deterministic language routing for parsed documents (issue 46, ADR-0008).

The router decides whether a parsed document needs LLM label translation
before extraction. It is deliberately **rule-based and pure** (ADR-0005):
the decision of *whether* to involve the LLM must be reproducible and
traceable, even though the translation itself is not.

Two signals, checked in order:

1. **Chinese** — a document whose field labels *start* with a CJK
   character (``发货人: ACME``) is native-ZH. English labels with ZH
   *annotations* (``Shipper (发货人):`` — the working bundle's only ZH
   style) start with Latin characters and therefore do **not** trigger:
   annotation-level bilingual documents keep running fully deterministic.
   Two or more CJK-first rows (title or labels) count as native ZH.
2. **Bahasa Melayu** — Latin script, so script ratio cannot see it.
   Instead a fixed set of distinctive BM shipping markers (from the
   sanctioned multilingual fixtures, ADR-0008) is matched on the casefolded
   text; two or more *distinct* markers classify the document as BM.
   Single accidental tokens ("Dan" a name, "ini" inside a longer word)
   never reach the threshold on their own.

Anything else is ``"en"`` and keeps the existing deterministic path.

Example:
    >>> from sdoc_hackathon.parsers.lang import detect_document_language
    >>> detect_document_language("发货人: ACME\\n收货人: ORBIS\\n装货港: BUATAN")
    'zh'
    >>> detect_document_language("Shipper (发货人): ACME\\nCONSIGNEE: ORBIS")
    'en'
"""

from __future__ import annotations

import re
from typing import Literal

__all__ = ["Language", "detect_document_language"]

#: Languages the router distinguishes; ``"en"`` keeps the deterministic path.
Language = Literal["en", "zh", "bm"]

#: CJK unified ideographs (plus extension A) — the extract stage already
#: strips exactly this range from labels (issue 12).
_CJK_RE = re.compile(r"[\u4e00-\u9fff\u3400-\u4dbf]")

#: Row counts as a native-ZH label row when its first non-space character is
#: CJK (title rows included).
#: Distinctive BM shipping markers (ADR-0008 sanctioned vocabulary). Phrases
#: are matched on the casefolded text; every marker is deliberately specific
#: to BM document language so English bundle documents cannot accumulate the
#: threshold of two distinct markers.
_BM_MARKERS: tuple[str, ...] = (
    "arahan penghantaran",
    "draf bill of lading",
    "bill of lading (draf)",
    "penghantar",
    "penerima",
    "pemberitahu",
    "pelabuhan pemuatan",
    "pelabuhan bongkar",
    "jumlah kontena",
    "berat kasar",
    "sila semak",
    "sila dapati",
    "terlampir",
    "percanggahan",
)

#: Distinct-marker threshold for the BM classification.
_BM_MARKER_THRESHOLD = 2

#: CJK-first rows required to classify a document native-ZH.
_ZH_ROW_THRESHOLD = 2


def _cjk_first_rows(text: str) -> int:
    """Count rows whose first non-space character is a CJK ideograph.

    Example:
        >>> _cjk_first_rows("SHIPPER: A\\n\\u53d1\\u8d27\\u4eba: B")
        1
    """
    count = 0
    for row in text.splitlines():
        stripped = row.lstrip()
        if stripped and _CJK_RE.match(stripped[0]):
            count += 1
    return count


def _distinct_bm_markers(text: str) -> int:
    """Count distinct BM markers present in the casefolded text.

    Example:
        >>> _distinct_bm_markers("Sila semak draf Bill of Lading") >= 2
        True
    """
    casefolded = text.casefold()
    return sum(1 for marker in _BM_MARKERS if marker in casefolded)


def detect_document_language(text: str) -> Language:
    """Classify one parsed document's language: ``"zh"``, ``"bm"`` or ``"en"``.

    Pure and deterministic (ADR-0005/ADR-0008): same text, same answer,
    no network. ``"en"`` is the default — annotation-level bilingual
    documents (English labels with CJK glosses) and all existing bundle
    documents keep the fully deterministic path.

    Args:
        text: The parsed document's full text (title, labels, values).

    Returns:
        The detected language tag.

    Example:
        >>> detect_document_language("Arahan Penghantaran\\nPenghantar: ACME\\nPenerima: ORBIS")
        'bm'
        >>> detect_document_language("SHIPPING INSTRUCTION\\nShipper: ACME")
        'en'
    """
    if _cjk_first_rows(text) >= _ZH_ROW_THRESHOLD:
        return "zh"
    if _distinct_bm_markers(text) >= _BM_MARKER_THRESHOLD:
        return "bm"
    return "en"

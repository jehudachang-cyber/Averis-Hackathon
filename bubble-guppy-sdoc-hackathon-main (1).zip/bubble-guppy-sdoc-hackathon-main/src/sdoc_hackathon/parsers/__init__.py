"""Attachment parsers: turn raw attachment bytes into ``ParsedDocument``.

One module per format (``txt``, ``xlsx``, ``docx``, ``pdf``). Every parser
returns the same ``(ParsedDocument, Confidence)`` pair so the extract stage
(issue 20) is format-agnostic. Parsers never read the answer key and never
see email ids: they take paths/text and detect document kind from the
document text itself.

After any parser runs, :func:`mark_unreadable` is the uniform gate that
keeps technically-parsed but useless documents (garbled, empty, too short
for their claimed kind) from reaching extract — issue 11. The orchestration
layer (issue 22) calls ``parse_attachment`` / ``gate_parsed`` instead of
invoking format parsers directly.

Example:
    >>> from sdoc_hackathon.parsers import read_attachment_text
    >>> read_attachment_text(bytes([0x70, 0xFF, 0x71]))
    'p\\ufffdq'
"""

from __future__ import annotations

from pathlib import Path

from sdoc_hackathon.models import Confidence, ParsedDocument
from sdoc_hackathon.parsers.docx import parse_docx, parse_docx_bytes
from sdoc_hackathon.parsers.lang import Language, detect_document_language
from sdoc_hackathon.parsers.pdf import parse_pdf, parse_pdf_bytes
from sdoc_hackathon.parsers.txt import _fold_continuations, detect_kind, parse_txt
from sdoc_hackathon.parsers.xlsx import parse_xlsx, parse_xlsx_bytes

__all__ = [
    "detect_document_language",
    "detect_kind",
    "gate_parsed",
    "mark_unreadable",
    "parse_attachment",
    "parse_docx",
    "parse_docx_bytes",
    "parse_pdf",
    "parse_pdf_bytes",
    "parse_txt",
    "parse_xlsx",
    "parse_xlsx_bytes",
    "read_attachment_text",
]


def read_attachment_text(data: bytes) -> str:
    """Decode attachment bytes the way every parser expects.

    UTF-8 with undecodable bytes replaced (U+FFFD), newline normalization
    left to the caller. Centralized here so all formats decode identically.

    Example:
        >>> read_attachment_text(b"SHIPPER: A\\nCONSIGNEE: B")
        'SHIPPER: A\\nCONSIGNEE: B'
    """
    return data.decode("utf-8", errors="replace")


#: Minimum usable characters for a document to count as readable at all.
DEFAULT_MIN_TEXT_LEN = 20

#: Minimum *field-bearing* rows for the document to support extraction.
MIN_ROWS_FOR_EXTRACTION = 3


def mark_unreadable(
    parsed: ParsedDocument,
    confidence: Confidence,
    min_text_len: int = DEFAULT_MIN_TEXT_LEN,
) -> tuple[ParsedDocument, Confidence]:
    """Gate one parsed document: demote it to ``UNREADABLE`` when unusable.

    Triggered when the text is shorter than ``min_text_len`` after
    normalization, when field-bearing rows are too few to extract from, or
    when the text still looks garbled despite a parser accepting it. On
    trigger: ``kind='UNREADABLE'``, ``error='insufficient_text_layer'``
    (or ``'insufficient_field_rows'``), confidence 0.1 — issue 11's
    contract. Already-``UNREADABLE`` documents pass through unchanged.

    Args:
        parsed: The parser's output document.
        confidence: The parser's confidence (kept when the gate passes).
        min_text_len: Minimum usable character count (issue 11 default 20).

    Returns:
        ``(document, confidence)`` — either the inputs unchanged (gate
        passed) or the demoted pair (gate triggered).

    Example:
        >>> parsed = ParsedDocument(path="a.txt", fmt="txt", text="\\x00\\x01\\x02")
        >>> doc, conf = mark_unreadable(parsed, Confidence(0.9, "parsed"))
        >>> (doc.kind, doc.error, conf.score)
        ('UNREADABLE', 'insufficient_text_layer', 0.1)
        >>> ok = ParsedDocument(
        ...     path="b.txt",
        ...     fmt="txt",
        ...     text="Shipper: A; Consignee: B; Port of Loading: C",
        ...     rows=("Shipper: A", "Consignee: B", "Port of Loading: C"),
        ... )
        >>> doc, conf = mark_unreadable(ok, Confidence(0.95, "clean"))
        >>> (doc.kind, doc.error, conf.score)
        ('OTHER', None, 0.95)
    """
    if parsed.kind == "UNREADABLE":
        return parsed, confidence

    normalized = parsed.text.replace("\ufffd", "").strip()
    usable_rows = sum(1 for row in parsed.rows if ":" in row)
    if len(normalized) < min_text_len:
        demoted = ParsedDocument(
            path=parsed.path,
            fmt=parsed.fmt,
            kind="UNREADABLE",
            text=parsed.text,
            rows=parsed.rows,
            scanned=parsed.scanned,
            error="insufficient_text_layer",
        )
        return demoted, Confidence(0.1, "insufficient text layer")
    if usable_rows < MIN_ROWS_FOR_EXTRACTION:
        demoted = ParsedDocument(
            path=parsed.path,
            fmt=parsed.fmt,
            kind="UNREADABLE",
            text=parsed.text,
            rows=parsed.rows,
            scanned=parsed.scanned,
            error="insufficient_field_rows",
        )
        return demoted, Confidence(0.1, "too few field rows to extract")
    return parsed, confidence


def gate_parsed(
    parsed: ParsedDocument, confidence: Confidence
) -> tuple[ParsedDocument, Confidence]:
    """Convenience wrapper: :func:`mark_unreadable` with issue-11 defaults."""
    return mark_unreadable(parsed, confidence)


def _maybe_translate(
    document: ParsedDocument,
    confidence: Confidence,
    *,
    ocr_keys: list[str],
) -> tuple[ParsedDocument, Confidence]:
    """Translate one non-English document's labels to English (issue 46).

    The deterministic router (:func:`detect_document_language`) decides
    *whether* the LLM is involved; Gemini (via
    :func:`sdoc_hackathon.llm.translate_to_english`) then translates the
    title and labels — values stay byte-for-byte, so extraction and
    comparison run unchanged downstream (ADR-0008). The re-parsed document
    carries ``translated=True`` for the ``decided_by="llm"`` audit rule.

    Failure contract (mirrors OCR, ADR-0006): when every key fails or the
    model returns nothing, the document is demoted to ``UNREADABLE`` with
    the reason attached — review escalates, never a guess. English and
    annotation-level bilingual documents return unchanged.
    """
    language: Language = detect_document_language(document.text)
    if language == "en":
        return document, confidence
    from sdoc_hackathon.llm import translate_to_english

    try:
        translated = translate_to_english(document.text, ocr_keys)
    except RuntimeError:
        # Technical detail is already logged by the rotation seam; the
        # document surfaces the professional escalation wording only
        # (issue 48 demo contract — no vendor error strings on stage).
        demoted = ParsedDocument(
            path=document.path,
            fmt=document.fmt,
            kind="UNREADABLE",
            text=document.text,
            rows=document.rows,
            scanned=document.scanned,
            error="label translation service unavailable — escalated for manual review",
        )
        return demoted, Confidence(
            0.1,
            f"label translation unavailable ({language}) — escalated for manual review",
        )

    lines = translated.splitlines()
    # Mirror parse_txt's row convention exactly: kind hint from the first
    # non-empty line, title/rule lines excluded, continuations folded —
    # so the translated document is indistinguishable in shape from a
    # natively parsed one (same extract expectations).
    first = next((line for line in lines if line.strip()), "")
    kind = detect_kind(first)
    translated_doc = ParsedDocument(
        path=document.path,
        fmt=document.fmt,
        kind=kind,
        text=translated,
        rows=_fold_continuations(lines),
        scanned=document.scanned,
        translated=True,
    )
    return mark_unreadable(
        translated_doc,
        Confidence(0.85, f"gemini label translation ({language} -> en)"),
    )


def parse_attachment(
    path: str,
    data: bytes,
    *,
    ocr_keys: list[str] | None = None,
) -> tuple[ParsedDocument, Confidence]:
    """Parse one attachment (any supported format) and apply the gate.

    Dispatches on the file extension; unknown formats return an
    ``UNREADABLE`` document at 0.1 rather than raising. Scanned PDFs are
    transcribed via Gemini when ``ocr_keys`` are configured (ADR-0006),
    otherwise they surface as ``UNREADABLE`` (scanned) for review.
    Non-English documents (native-ZH labels, BM markers — issue 46) are
    routed through Gemini label translation when keys are configured;
    without keys they keep their parsed text and the review stage
    escalates (ADR-0008).

    Args:
        path: Attachment path exactly as listed in the email JSON.
        data: Raw attachment bytes.
        ocr_keys: Optional rotated Gemini API keys for scanned PDFs and
            non-English label translation.

    Returns:
        ``(document, confidence)`` gated through :func:`mark_unreadable`.

    Example:
        >>> raw = chr(10).join(
        ...     ["SHIPPING INSTRUCTION", "====", "Shipper: A", "Consignee: B", "POL: C"]
        ... )
        >>> parsed, conf = parse_attachment("attachments/a.txt", raw.encode())
        >>> (parsed.fmt, parsed.kind, conf.score)
        ('txt', 'SI', 0.95)
    """
    suffix = Path(path).suffix.lower()
    if suffix == ".txt":
        document, confidence = parse_txt(path, read_attachment_text(data))
    elif suffix == ".xlsx":
        document, confidence = parse_xlsx_bytes(path, data)
    elif suffix == ".docx":
        document, confidence = parse_docx_bytes(path, data)
    elif suffix == ".pdf":
        document, confidence = parse_pdf_bytes(path, data, ocr_keys=ocr_keys)
    else:
        document = ParsedDocument(
            path=path,
            fmt="unknown",
            kind="UNREADABLE",
            text="",
            rows=(),
            scanned=False,
            error=f"unsupported attachment format: {suffix or '(none)'}",
        )
        return document, Confidence(0.1, "unsupported format")

    document, confidence = mark_unreadable(document, confidence)
    if document.kind != "UNREADABLE" and ocr_keys:
        document, confidence = _maybe_translate(document, confidence, ocr_keys=ocr_keys)
    return document, confidence

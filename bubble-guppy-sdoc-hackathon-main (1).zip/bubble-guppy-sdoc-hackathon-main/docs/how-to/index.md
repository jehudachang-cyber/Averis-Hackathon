# How-To

## Run the demo dashboard

The one-command launcher from the repo root starts the API bridge and the
React dashboard together and stops both on Ctrl+C:

```bash
./demo.sh                 # dashboard on http://localhost:5173, bridge on :8000
./demo.sh --logs          # also tail both log streams
./demo.sh --refresh       # force a fresh pipeline run (spends Gemini calls)
API_PORT=9000 UI_PORT=3000 ./demo.sh   # override ports
```

Restarts reuse a **fingerprinted snapshot** of the last successful run
(`.demo-logs/bridge-snapshot.json`) — a warm start costs zero Gemini calls.
Any relevant change (bundle files, bridge/pipeline sources, LLM on/off)
invalidates it automatically; `SDOC_SNAPSHOT=off` disables the cache.

Manual start, if you prefer:

```bash
uv run uvicorn api.app:app --port 8000   # bridge (runs the 520-email pipeline at startup)
cd ui && npm install && npm run dev       # dashboard on http://localhost:5173 (proxies /api)
```

Notes:

- The bridge runs the real pipeline over all 520 emails **once** at startup;
  page stats and subsets refilter that cached run — no re-run, no mocks.
- Scanned PDFs are transcribed live (Gemini) when `GEMINI_API_KEYS` is set in
  `.env`. Set `SDOC_OCR_KEYS=""` to force the no-OCR path (scans then show
  their `unreadable` escalation instead).
- The subset selector (Showcase (5) / Starter (~30) / BL Comparison / All 520)
  is shared by the Pipeline and Browse pages — one selection across both.

## Resolve a mismatch (auto-resolve, issue 51)

Open any `MISMATCH` story in Browse → the **ResolvePanel** appears below the
verdict:

1. Pick a value per field — the SI value is prefilled; switch to the BL value
   or type a manual override.
2. Tick the explicit confirm (always required when consignee / notify party /
   ports are involved — title-document fields).
3. **Preview email** shows the exact recipient banner: `SANDBOX → …` by
   default, `REAL SEND → …` only when `ALLOW_REAL_SEND=1`.
4. Send — the correction email goes out via Gmail SMTP and the resolution is
   appended to the resolve log. Verdicts never change.

Credentials (all optional; unset = the send endpoint answers 503):

```bash
# .env
gmail_user=...        # sending account
GMAIL_APP_PASSWORD=...        # 16-char App Password (2FA required)
SANDBOX_RECIPIENT=...         # where sandbox sends land
# ALLOW_REAL_SEND=1           # ONLY on a real GCP deploy
```

The log lives at `.demo-logs/resolve.log` (gitignored) by default, or in
Firestore with `SDOC_RESOLVE_STORE=firestore` (auto-downgrades to the file on
any error). `GET /api/resolve/log` reads it back.

## Deploy to Cloud Run (issue 52)

One service hosts the API bridge, the built React app, and the pipeline:

```bash
gcloud auth login
./deploy/deploy.sh            # preflight checks → Cloud Build → Cloud Run
```

All preflight checks are read-only and abort before any spend. Cost caps
(`min-instances=0`, `max-instances=1`), the sandbox mail default, and the
no-ground-truth guard are asserted by the script itself. Full runbook:
`deploy/README.md` in the repo root · one-time GCP provisioning:
[gcp-setup.md](gcp-setup.md).

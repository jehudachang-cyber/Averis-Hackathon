# GCP Setup – Step by Step (living doc)

> Status: **infra provisioned, secrets filled; deploy kit merged (issue #52,
> PR #60) — first real deploy pending**. Update this file as we go.
>
> What this page is: a plain-English, copy-paste runbook for hosting the demo
> dashboard on Google Cloud. It tracks what we configured, why each piece
> exists, and the exact commands/URLs to verify or reproduce it.
>
> **Deploying:** the day-to-day deploy runbook now lives in the repo at
> [`deploy/README.md`](https://github.com/OctakoPy/bubble-guppy-sdoc-hackathon/blob/main/deploy/README.md)
> (`./deploy/deploy.sh` — preflight checks, cost caps, Cloud Build). This
> page covers the one-time provisioning below it.

## TL;DR — what we're building

One **Cloud Run** service that serves the whole webapp (API bridge + the
compiled React dashboard) from a single public HTTPS URL. The pipeline runs
inside it; on a deploy, outbound correction emails are **sandboxed by
default** (never delivered to real counterparties).

| Piece | Why it exists | Status |
| --- | --- | --- |
| Project `bubble-guppy` | everything lives under it | ✅ created |
| Billing linked | Cloud Run/Cloud Build refuse to run without it | ✅ linked |
| $1 budget alert → email | avoid surprise bills | ✅ created |
| APIs enabled | each service maps to an API (Run, Cloud Build, Artifact Registry, Secret Manager, Firestore) | ✅ enabled |
| Firestore DB | stores the auto-resolve log (+ future records) | ✅ native, asia-southeast1 |
| IAM grants | lets Cloud Run's service account read secrets + Firestore + images | ✅ granted |
| Artifact Registry repo `sdoc-demo` | stores the Docker image | ✅ created |
| Secrets ×4 | Gemini keys + Gmail creds + sandbox recipient | ✅ filled + SMTP login verified |

## Prerequisites

- One Google account owns the project (no org needed).
- **Billing account + card** already exist on it.
- `gcloud` CLI installed; PATH set for Git Bash:
  ```bash
  echo 'export PATH="$PATH:/c/Users/caleb/AppData/Local/Google/Cloud SDK/google-cloud-sdk/bin"' >> ~/.bashrc
  ```

## Auth + project pin

```bash
gcloud auth login
gcloud config set project bubble-guppy
gcloud config get-value project   # must print bubble-guppy
```

> The CLI silently operating on the wrong project is the classic failure — check
> `gcloud config list project` at the start of every session.

## Billing + budget alert

```bash
# link the project to a billing account
gcloud billing projects link bubble-guppy --billing-account=01801A-A46AA0-3B78C0
gcloud billing projects describe bubble-guppy   # expect billingEnabled: true
```

Doorstopper: a project with no billing account attached fails every deploy with
a confusing "billing not associated" error. Verify the enable bit before going
any further.

```bash
# enable the APIs budgets/monitoring need
gcloud services enable billingbudgets.googleapis.com monitoring.googleapis.com
gcloud beta monitoring channels create --type=email \
  --display-name="Budget alerts" \
  --channel-labels=email_address=octakopy@gmail.com
gcloud billing budgets create \
  --billing-account=01801A-A46AA0-3B78C0 \
  --display-name="sdoc-hackathon-demo budget alert" \
  --budget-amount=1 \
  --filter-projects=projects/216911340018 \
  --calendar-period=MONTH \
  --threshold-rule=percent=0.9 \
  --threshold-rule=percent=1.0 \
  --notifications-rule-monitoring-notification-channels=projects/bubble-guppy/notificationChannels/<CHANNEL_ID>
```

Result: an email at 90% and 100% of a 1-unit budget (currency = the billing
account's, here MYR ≈ USD 0.90).

## API enablement

```bash
gcloud services enable run.googleapis.com cloudbuild.googleapis.com \
  artifactregistry.googleapis.com secretmanager.googleapis.com firestore.googleapis.com
gcloud services list --enabled --format="value(config.name)" | grep -E "run\.googleapis|cloudbuild|artifactregistry|secretmanager|firestore"
```

Each service corresponds to a capability we need:

| API | Feeds |
| --- | --- |
| Cloud Run | runs the app container |
| Cloud Build | builds the image (and later the GitHub→auto-deploy trigger) |
| Artifact Registry | stores the image |
| Secret Manager | holds keys/creds (injected as env at runtime) |
| Firestore | resolve-log storage |

## Firestore

Our **resolve log** (issue #51) writes completed resolutions here so the send
trail survives restarts and shows up in the cloud.

```bash
gcloud firestore databases create --location=asia-southeast1 --type=firestore-native
gcloud firestore databases list   # expect FIRESTORE_NATIVE, asia-southeast1
```

> Must be **native (Firestore) mode**, not Datastore. If a Datastore-mode DB
> already exists, the project must be recreated.

## IAM grants

Cloud Run runs as the project's default compute service account; it needs
permission to read the secrets and Firestore and pull images:

```bash
PROJECT_NUM=$(gcloud projects describe bubble-guppy --format='value(projectNumber)')
SA="$PROJECT_NUM-compute@developer.gserviceaccount.com"
for ROLE in roles/secretmanager.secretAccessor roles/datastore.user roles/artifactregistry.reader; do
  gcloud projects add-iam-policy-binding bubble-guppy --member="serviceAccount:$SA" --role="$ROLE"
done
```

Without `secretAccessor`, `gcloud run deploy --set-secrets` fails with a
confusing permission error.

## Artifact Registry

```bash
gcloud artifacts repositories create sdoc-demo \
  --repository-format=docker --location=asia-southeast1
```

## Secrets (filled)

All four secrets carry version 1 values; SMTP login against the app password
was verified (`SMTP login OK`). Re-run the add commands below to bump a
value (new version becomes latest):

```bash
printf 'AIza...AAA,AIza...BBB'    | gcloud secrets versions add GEMINI_API_KEYS --data-file=-
printf 'sender@gmail.com'         | gcloud secrets versions add GMAIL_USER --data-file=-
printf 'abcd efgh ijkl mnop'      | gcloud secrets versions add GMAIL_APP_PASSWORD --data-file=-
printf 'team-sandbox@gmail.com'   | gcloud secrets versions add SANDBOX_RECIPIENT --data-file=-
gcloud secrets list && gcloud secrets versions access latest --secret=GMAIL_USER
```

- `GEMINI_API_KEYS` — comma-separated keys from https://aistudio.google.com/apikey
- `GMAIL_USER` — the sender account (SMTP)
- `GMAIL_APP_PASSWORD` — 16-char App Password, requires 2FA on the sender account (myaccount.google.com/apppasswords)
- `SANDBOX_RECIPIENT` — throwaway inbox sandbox sends land in (never a bundle domain)

## Verify-everything cheat sheet

```bash
gcloud config get-value project                 # bubble-guppy
gcloud billing projects describe bubble-guppy   # billingEnabled: true
gcloud services list --enabled | grep -E "run|cloudbuild|artifactregistry|secretmanager|firestore"
gcloud firestore databases list
gcloud artifacts repositories list --location=asia-southeast1
gcloud secrets list
```

## Remaining / fill-in-as-we-go

- [x] Build issue #51 (auto-resolve: `api/resolve.py`, `api/mailer.py`, Firestore log, ResolvePanel UI) — merged (PR #59)
- [x] Build issue #52 (`deploy/Dockerfile`, `cloudbuild.yaml`, `deploy.sh`, static-UI hook in `api/app.py`) — merged (PR #60)
- [ ] First `./deploy/deploy.sh` → public URL (record it here)
- [ ] Sandbox send confirmed (test email lands in `SANDBOX_RECIPIENT`)
- [ ] GitHub → Cloud Build trigger (auto-deploy on push to `main`) — optional; steps in `deploy/README.md`
- [ ] Decide `ALLOW_REAL_SEND` policy (stays `0`/unset unless live delivery wanted)
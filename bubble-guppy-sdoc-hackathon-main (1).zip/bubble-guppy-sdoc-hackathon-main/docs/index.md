# SDOC Hackathon — Shipping Document Verification

A pipeline that reads a shipping-operations inbox, classifies each email, and
for document-checking requests compares the Shipping Instruction (SI) against
the draft Bill of Lading (BL) over seven shipment fields, producing a
discrepancy report and escalating undecidable cases to a human.

See the requirements checklist at the repository root (`USE_CASE.md`) and the
[how-to guides](how-to/index.md) for running the pipeline and scoring a
submission.
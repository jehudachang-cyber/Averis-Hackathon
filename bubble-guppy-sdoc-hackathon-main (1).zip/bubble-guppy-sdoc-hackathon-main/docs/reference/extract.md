# Extract

Stage 3a: turn a `ParsedDocument`'s rows into the seven canonical fields of
`ExtractedFields`. Two layers:

1. **Vocabulary** — `normalize_label` strips presentation noise (case,
   whitespace, trailing colons, Chinese annotations, parenthetical
   qualifiers) and `SYNONYM_MAP` maps the normalized label to one of the
   canonical fields in `models.FIELDS`. Labels like `Load Port`,
   `POL`, and `装货港` all land on `port_of_loading`. The inventory is
   derived from the generator's label-pool spec cross-checked against the
   working dataset's attachments — the answer key is never consulted.
2. **Extraction** — `extract_fields` walks the rows and fills the fields;
   `assign_roles` decides which attachment is the SI (reference) and which
   the draft BL. Two row styles are supported: `Label: value` colon rows
   and bare-label blocks (pdf tables). Missing fields stay blank — the
   `missing_value` escalation trigger (ADR-0004).

`extract_fields_anchored` is the issue-47 variant that additionally reports
the row indices that produced each value (dashboard provenance); the plain
function delegates to it, so there is exactly one extraction implementation.

::: sdoc_hackathon.extract
    options:
      members: false

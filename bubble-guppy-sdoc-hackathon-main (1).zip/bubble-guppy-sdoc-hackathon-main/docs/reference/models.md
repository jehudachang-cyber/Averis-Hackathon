# Models & contracts

`src/sdoc_hackathon/models.py` is the shared vocabulary of the pipeline
(AGENTS.md §2): every silo — classification, parsers, extract/compare/review,
orchestration — communicates **only** through the types defined here. The
module is deliberately logic-free: construction, small derived helpers, and
validation only.

Key ideas to carry into every other page:

- `FIELDS` fixes the seven compared shipment fields and their canonical
  order (defect lists, escalation tables, and dashboard columns all follow it).
- Blank values are meaningful — a blank field is the `missing_value`
  escalation trigger, never a mismatch (ADR-0004).
- Every record carries `decided_by` so an audit can tell rule decisions
  from LLM-assisted ones (OCR or label translation ⇒ `"llm"`, ADR-0006).

::: sdoc_hackathon.models
    options:
      members_order: source

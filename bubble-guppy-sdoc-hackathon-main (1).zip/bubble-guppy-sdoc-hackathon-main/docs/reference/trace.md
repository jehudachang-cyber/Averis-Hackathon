# Trace

The per-email audit trail. Every pipeline stage appends a `StepEvent` to the
email's `Trace`, which is the machine-readable "why did the pipeline decide
this" record — the demo dashboard's stage-by-stage views and document
provenance are rendered straight from it, with no re-derivation.

Event order for a comparison email reads
`classify → parse → extract → compare → review`; non-comparison emails stop
after `classify`. The optional `payload` (issue 47) carries structured
provenance — parsed rows, per-field row anchors, per-field SI/BL values —
and is `None` on every pre-existing event, so consumers must treat it as
optional.

Rendered by hand (not mkdocstrings): the module's doctest examples use
bracket syntax that the docs cross-ref engine misparses. The source
docstrings remain the contract — see `src/sdoc_hackathon/trace.py`.

## `StepEvent` (frozen dataclass)

| Attribute | Type | Meaning |
| --- | --- | --- |
| `stage` | `str` | Pipeline stage name: `classify`, `parse`, `extract`, `compare`, `review`, `ocr` |
| `decision` | `str` | What the stage decided — the category, the document kind, or the status |
| `confidence` | `Confidence \| None` | The stage's confidence in the decision, when it has one |
| `detail` | `str` | Free-form evidence: matched rule names, field values, parser errors |
| `payload` | `dict[str, object] \| None` | Structured provenance (issue 47): extract/compare events carry field anchors and per-field values so the demo bridge never re-derives them |

## `Trace` (dataclass)

| Member | Signature | Meaning |
| --- | --- | --- |
| `email_id` | `str` | The inbox identifier this log belongs to |
| `events` | `list[StepEvent]` | Ordered event log; stages append as the email flows through |
| `append()` | `(event: StepEvent) -> None` | Append one stage event |
| `stage()` | `(stage: str) -> StepEvent \| None` | Return the first event recorded by that stage, or `None` |

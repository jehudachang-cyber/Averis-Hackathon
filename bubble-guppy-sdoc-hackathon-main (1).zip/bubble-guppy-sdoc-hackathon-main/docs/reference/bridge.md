# Demo bridge API

`api/` is the FastAPI bridge between the pipeline's `Trace` objects and the
React dashboard. It runs the real pipeline over the bundle **once** at
startup and serves everything from that cache: no ground truth anywhere, no
re-derivation on the read path, no stale artifacts.

## Snapshot cache (quota guard)

A full live run spends Gemini calls (scanned-PDF OCR + label translations),
so restarts reuse a fingerprinted snapshot of the last successful run instead
of re-running: the fingerprint covers bundle contents, the bridge/pipeline
sources, and *whether* LLM keys were live — never key material. Any relevant
change invalidates it automatically.

| Environment variable | Meaning |
| --- | --- |
| `SDOC_SNAPSHOT` | `on` (default) reuse + write · `refresh` re-run + re-write · `off` always live |
| `SDOC_SNAPSHOT_PATH` | Snapshot file (default `.demo-logs/bridge-snapshot.json`) |
| `SDOC_SNAPSHOT_BUCKET` | Optional GCS bucket persisting the snapshot (issue 73; Cloud Run cold boots). Unset keeps file-only behavior; storage errors degrade to a live run |
| `SDOC_DATA_ROOT` | Bundle directory (default `sdoc-hackathon-bundle`) |
| `SDOC_OCR_KEYS` | Gemini keys override; set empty to force no-OCR |
| `SDOC_MULTILINGUAL_ROOT` | Optional extra fixture bundle merged into the cache |
| `SDOC_UI_DIST` | Built React app to serve statically (Cloud Run: one service hosts api + ui). Unset = API only |

## Endpoints

| Method | Path | Purpose |
| --- | --- | --- |
| GET | `/api/health` | Liveness + cache state (`source`, `ocr_live`, email count) |
| GET | `/api/overview` | Rollups + measured score strip (labels; ground truth never leaves the scorer) |
| GET | `/api/emails?subset=…` | Summary list for Browse, subset-filterable |
| GET | `/api/emails/{id}/story` | Full story for one email, straight from the Trace |
| GET | `/api/subsets` | The derived subsets (`showcase` / `starter` / `bl_comparison` / `all`) |
| POST | `/api/resolve/preview` | Compose the correction email — no delivery, no log |
| POST | `/api/resolve/send` | Compose + really send + log (sandbox by default) |
| GET | `/api/resolve/log` | The append-only resolution trail |

Resolve-endpoint details (risk-tier confirm, recipient routing, log
backends) live on the [Resolve & mailer](resolve.md) page; the operator
flow is described in [How-To → Resolve a mismatch](../how-to/index.md#resolve-a-mismatch-auto-resolve-issue-51).

Subsets are **derived from the run's own records** — never hand-picked lists
that go stale — except the five pinned Showcase hero stories, which are
chosen to demonstrate one specific pipeline outcome each and are not tuned
against any answer key.

::: api.app
    options:
      members: false

## Story, overview, subsets internals

::: api.story
    options:
      members: false

::: api.overview
    options:
      members: false

::: api.subsets
    options:
      members: false

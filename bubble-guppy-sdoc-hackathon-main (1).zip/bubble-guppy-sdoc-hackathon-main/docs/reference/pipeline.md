# Pipeline

Orchestration: `classify → parse → extract/compare → review` over every
inbox email, producing parallel lists of `SubmissionRecord`s and `Trace`s.
Every stage appends a `StepEvent` so each decision is auditable; for
`BL_COMPARISON` emails the flow additionally records the additive
`extract`/`compare` provenance events (issue 47) so the demo dashboard never
re-derives field anchors or per-field values.

Audit hook (ADR-0006 amendment): a document with no text layer but a usable
kind can only exist because OCR transcribed it — and a document whose labels
were translated decided nothing without LLM output either — so such records
carry `decided_by="llm"` end to end.

::: sdoc_hackathon.pipeline
    options:
      members_order: source

# CLI

## `scripts/run_pipeline.py`

Run the SDOC pipeline over a bundle inbox and write a submission:

```bash
uv run python scripts/run_pipeline.py --data sdoc-hackathon-bundle --out submission.json
```

### Flags

| Flag | Default | Meaning |
| --- | --- | --- |
| `--data` | `sdoc-hackathon-bundle` | Bundle directory containing `inbox/` and `attachments/` |
| `--out` | `submission.json` | Output submission JSON path |
| `--no-ocr` | off | Skip Gemini OCR even when `GEMINI_API_KEYS` are configured (scanned PDFs then escalate `unreadable`) |

The run prints per-category counts and the `BL_COMPARISON` outcome
breakdown. Missing inbox directory exits nonzero with a clear message.

### Scoring the output

```bash
uv run python sdoc-hackathon-docker/server/score_cli.py submission.json
```

On Windows consoles, prefix `PYTHONUTF8=1` (the scorer prints Unicode bars).

### Environment variables

| Variable | Used by | Meaning |
| --- | --- | --- |
| `GEMINI_API_KEYS` | `llm.load_api_keys_from_env` | Comma-separated Gemini keys for scanned-PDF OCR + label translation (rotation multiplies free-tier quota) |
| `GEMINI_MODELS` / `GEMINI_MODEL` | `llm.resolve_models` | Override the default model order / pin a single model for reproducibility |
| `SDOC_OCR_KEYS` | `api.app` | Bridge-only keys override; set empty to force the no-OCR path |
| `SDOC_SNAPSHOT` / `SDOC_SNAPSHOT_PATH` / `SDOC_SNAPSHOT_BUCKET` | `api.app` | Snapshot-cache mode / location / GCS persistence (see [bridge reference](bridge.md)) |
| `SDOC_RESOLVE_STORE` / `SDOC_RESOLVE_LOG_PATH` | `api.resolve` | Resolve-log backend and file location |
| `SANDBOX_RECIPIENT`, `GMAIL_USER`, `GMAIL_APP_PASSWORD`, `ALLOW_REAL_SEND` | `api.resolve` | Mailer routing (see [resolve reference](resolve.md)) |

## Demo launcher — `demo.sh`

One command starts the API bridge (`:8000`) and the React dashboard
(`:5173`) and stops both on Ctrl+C:

```bash
./demo.sh                 # dashboard on http://localhost:5173, bridge on :8000
./demo.sh --logs          # also tail both log streams
./demo.sh --refresh       # force a fresh pipeline run (spends Gemini calls)
API_PORT=9000 UI_PORT=3000 ./demo.sh   # override ports
```

## Deploy — `deploy/deploy.sh`

Preflight checks → Cloud Build → Cloud Run (all preflight checks are
read-only and abort before any spend). See the
[Cloud Run how-to](../how-to/index.md#deploy-to-cloud-run-issue-52) and
`deploy/README.md`.

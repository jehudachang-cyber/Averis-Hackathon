# Resolve & mailer

The auto-resolve stage (issue 51) plus its Gmail SMTP transport. When the
pipeline verdict is `MISMATCH` (all seven fields compared, both values
present), an operator picks the correct value per mismatched field —
`si` (the prefilled default), `bl`, or a manual override — the bridge composes
a markdown correction email, and the resolution is logged. Verdicts are
never mutated.

Hard invariants:

- **Sandbox by default.** Unless `ALLOW_REAL_SEND=1` is set on a real GCP
  deploy, every send is redirected to `SANDBOX_RECIPIENT` while the UI still
  shows the real counterparty. Never delivered to a bundle domain during a
  demo.
- **Risk-tier confirm.** Consignee, notify party, and both ports are
  title-document fields (`RISKY_FIELDS`) and always require an explicit
  confirm; container count, gross weight, and shipper resolve with the
  single default confirm.
- **Log never breaks the send path.** The resolve log is a JSONL file
  (`.demo-logs/resolve.log`) by default, or Firestore with
  `SDOC_RESOLVE_STORE=firestore`; any Firestore error downgrades to the file.
- **Mailer errors are typed.** `api.mailer.send_email` raises `MailError` so
  the HTTP layer answers with a clean message instead of an SMTP traceback.
  The composed body is markdown carried as both a plain-text part and a
  rendered HTML alternative (issue 68).

| Environment variable | Meaning |
| --- | --- |
| `GMAIL_USER` / `GMAIL_APP_PASSWORD` | Sending account credentials (unset ⇒ send endpoint answers 503) |
| `SANDBOX_RECIPIENT` | Where sandboxed sends land |
| `ALLOW_REAL_SEND` | `1` only on a real GCP deploy — enables delivery to the counterparty |
| `SDOC_RESOLVE_STORE` | `file` (default) or `firestore` |
| `SDOC_RESOLVE_LOG_PATH` | File-log location override |

::: api.resolve
    options:
      members: false

::: api.mailer
    options:
      members: false

# Submission

Serialization from `SubmissionRecord`s to the scored `submission.json`
shape, which mirrors `sdoc-hackathon-bundle/sample_submission.json` exactly:
a JSON object keyed by email id, each value carrying `category`, `status`,
`review_reason`, `defect_fields`, and `has_defect`.

Rendered by hand (not mkdocstrings): the module's doctest examples use
bracket syntax that the docs cross-ref engine misparses. The source
docstrings remain the contract — see
`src/sdoc_hackathon/submission.py`.

## `record_to_entry(record: SubmissionRecord) -> dict[str, object]`

Flatten one record into the submission entry shape: `category`, `status`,
`review_reason` (only when `NEEDS_REVIEW`), `defect_fields` (only when
`MISMATCH`), and `has_defect` (true iff `MISMATCH`).

## `write_submission(records, out_path) -> Path`

Convert every record with `record_to_entry` and write the JSON object keyed
by email id to `out_path` (UTF-8, `ensure_ascii=False`), returning the
written path. This is the artifact `score_cli.py` scores.

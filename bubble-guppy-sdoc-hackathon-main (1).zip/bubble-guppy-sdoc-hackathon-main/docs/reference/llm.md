# Gemini OCR & label translation

The pipeline's only LLM touchpoints (ADR-0005: deterministic first, LLM only
where rules genuinely cannot read the input):

1. **OCR** — scanned (image-only) PDF pages are rendered to bytes by the pdf
   parser and transcribed verbatim by Gemini; the result is wrapped in a
   `ParsedDocument` like any native parser's output.
2. **Label translation** — when the deterministic language router classifies
   a parsed document as Chinese or Bahasa Melayu, its text is translated to
   English here. **Labels and title only**; values stay byte-for-byte so the
   downstream extract/compare stages run unchanged (ADR-0008).

Keys come from `GEMINI_API_KEYS` (comma-separated, loaded from `.env`).
Calls rotate across the configured keys *and* models so one exhausted or
revoked key, a throttled model, or a retired pin does not stop the run —
a failing pair is skipped and the next tried. Default model order is
`DEFAULT_GEMINI_MODELS`; override the list via `GEMINI_MODELS` or pin one
via `GEMINI_MODEL`. When every key fails for a scan the document surfaces
as `UNREADABLE` and review escalates — never a guess.

Every network call sits behind the module-level seams `_generate` /
`_generate_text`; unit tests monkeypatch them, so the gate stays offline.

::: sdoc_hackathon.llm
    options:
      members: false

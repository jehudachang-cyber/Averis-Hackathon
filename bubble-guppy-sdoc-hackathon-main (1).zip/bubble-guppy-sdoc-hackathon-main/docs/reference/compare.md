# Compare

Stage 3b: the SI-vs-BL field-by-field diff. The seven canonical fields are
compared after **value-based** normalization (never email-id-based):
case/whitespace folding, address-separator variants, weight formats
(`131,058 KG` vs `131058`), container forms (`6 x 40'HC`), and port name vs
bare UN/LOCODE equivalence.

Two design points worth internalizing:

- Parenthetical content is **kept** for ports — the dataset plants
  same-code/different-city traps (`MOMBASA, KENYA (KEMBA)` vs
  `TUTICORIN, INDIA (KEMBA)`) that must stay mismatches; a bare UN/LOCODE
  equals a full port string only when one side carries no city text.
- A field with a blank side is **not** a defect — the review stage escalates
  it as `missing_value` (ADR-0004 precedence lives in the review stage).

::: sdoc_hackathon.compare
    options:
      members: false

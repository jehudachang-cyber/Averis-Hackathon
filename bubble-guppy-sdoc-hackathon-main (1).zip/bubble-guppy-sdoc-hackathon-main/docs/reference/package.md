# Package

The top-level package re-exports the shared contracts — `FIELDS`, the type
aliases, and the dataclasses from `models`, plus `StepEvent`/`Trace` — so
downstream code can write `from sdoc_hackathon import SubmissionRecord`
without reaching into submodules. The re-exported names are documented on
the [Models & contracts](models.md) and [Trace](trace.md) pages.

::: sdoc_hackathon
    options:
      members: false
      show_submodules: false

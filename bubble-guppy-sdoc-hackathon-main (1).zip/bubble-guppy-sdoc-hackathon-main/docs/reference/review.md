# Review

Stage 4: final status + escalation reason, implementing the ADR-0004 reason
table exactly — first hit wins:

| # | Condition | Status | `review_reason` |
| --- | --------- | ------ | ----------------- |
| 1 | Comparison request with zero or one of the SI/BL pair present | NEEDS_REVIEW | `missing_attachment` |
| 1a | …unless the body is an unambiguous request to *send* the draft BL (four anchors must all hold) | OK | — |
| 2 | An attached document is neither SI nor BL | NEEDS_REVIEW | `wrong_doc_type` |
| 3 | A required document parsed but is unusable | NEEDS_REVIEW | `unreadable` |
| 4 | A required field blank in either document | NEEDS_REVIEW | `missing_value` |
| 5 | All seven fields present and compared | OK / MISMATCH | — |

Reliability contract (ADR-0003): `NEEDS_REVIEW` means "could not be decided
— escalate to a human", with recall valued over precision. Escalations carry
evidence in `detail` so a human can confirm or correct. A `MISMATCH` lists
differing fields in canonical order; `has_defect` is true iff the status is
`MISMATCH`.

::: sdoc_hackathon.review
    options:
      members: false

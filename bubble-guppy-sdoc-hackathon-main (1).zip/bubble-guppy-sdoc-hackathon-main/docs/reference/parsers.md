# Parsers

Stage 2. One parser module per format (`txt`, `xlsx`, `docx`, `pdf`); every
parser returns the same `(ParsedDocument, Confidence)` pair so the extract
stage is format-agnostic. Parsers never read the answer key and never see
email ids — they take paths/text and detect the document kind (SI / BL /
OTHER / UNREADABLE) from the document text itself.

Uniform guarantees applied by this package no matter the format:

- **Unreadable gate** — `mark_unreadable` demotes technically-parsed but
  useless documents (garbled, empty, too few field rows) to
  `kind="UNREADABLE"` with `error="insufficient_text_layer"` or
  `"insufficient_field_rows"`, so review escalates instead of guessing.
- **Scanned PDFs** — a PDF with no text layer is rendered and transcribed
  via Gemini when `ocr_keys` are configured (ADR-0006), otherwise it
  surfaces as `UNREADABLE (scanned)`.
- **Label translation** — the deterministic router
  (`detect_document_language`) sends Chinese / Bahasa Melayu documents
  through Gemini label translation when keys are configured (ADR-0008);
  values stay byte-for-byte. Without keys the review stage escalates.
- **Unsupported formats** — return `UNREADABLE` at confidence 0.1 rather
  than raising.

The orchestration layer calls `parse_attachment` (dispatch + gate +
translation) rather than invoking format parsers directly.

::: sdoc_hackathon.parsers
    options:
      members: false
      show_submodules: true

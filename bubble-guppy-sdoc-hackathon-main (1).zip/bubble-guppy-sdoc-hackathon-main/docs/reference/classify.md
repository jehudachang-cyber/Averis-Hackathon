# Classification

Stage 1 of the pipeline. Every inbox email is classified into one of five
categories — `BL_COMPARISON | SI_REQUEST | INVOICE_QUERY | GENERAL | SPAM` —
by a deterministic, tiered rule table; non-comparison emails stop here with
`status="OK"` (ADR-0005: deterministic first, LLM only where rules cannot
read the input).

Confidence bands (ADR-0003):

| Tier | Signal | Confidence |
| --- | --- | --- |
| 1 | Subject rule | 0.95 |
| 2 | Body rule | 0.85 |
| 3 | Fallback (→ `GENERAL`) | 0.55 |

Within the body tier the order is significant — spam outranks ops keywords,
explicit check/compare phrases outrank a bare "draft bl" mention, and the
forwarded-thread rule is reachable only when nothing else matched. See the
module docstring for the full ordering rationale, and
[Email classification in plain English](../explanation/classification-in-plain-english.md)
for a gentler walkthrough.

::: sdoc_hackathon.classify
    options:
      members: false
      show_submodules: false

# Architectural Decision Records

| ADR | Status | Summary |
|-----|---------|----------|
| [ADR-001: Use Architecture Decision Records](001-use-architectural-decision-records.md) | 🟢 Accepted | Use ADRs to explain the rationale behind architecturally significant design choices for future developers and AI assistants |
| [ADR-002: Manage dependencies with uv](002-manage-dependencies-with-uv.md) | 🟢 Accepted | Use uv to manage project dependencies |
| [ADR-0003: Stage confidence and reliability model](0003-stage-confidence-and-reliability-model.md) | 🟢 Accepted | Numeric confidence + escalate-on-low bands for every stage |
| [ADR-0004: BL-comparison escalation rules](0004-bl-comparison-escalation-rules.md) | 🟢 Accepted | Deterministic review_reason table checked before any match verdict |
| [ADR-0005: Deterministic-first classification, LLM in reserve](0005-deterministic-first-classification-llm-policy.md) | 🟢 Accepted | Tiered rule table for stage 1; LLM only for rule-undecidable inputs, traced |
| [ADR-0006: Gemini OCR policy for scanned attachments](0006-gemini-ocr-policy.md) | 🟢 Accepted | `google-genai` + rotation over `gemini-3.8-flash` → `gemini-2.5-flash` → `gemini-3.5-flash-lite` → `gemini-3.1-flash-lite` with key rotation; LLM transcribes verbatim, labels stay deterministic |
| [ADR-0007: Field extraction policy](0007-field-extraction-policy.md) | 🟢 Accepted | One label vocabulary, two row styles; container-table trap explicit; blanks escalate |

# ADR-0005: Deterministic-First Classification With LLM Held In Reserve

| | |
| ---| ---|
| **Status** | 🟢 Accepted |
| **Created** | 2026-09-19 |
| **Last Updated** | 2026-09-19 |
| **Deciders** | bubble-guppy, opencode session |
| **Tags** | classification, rules, llm-policy |

---

## Context

Stage 1 assigns every inbox email one of five categories. The inbox is
heavily templated (coded subjects like `TO CONFIRM DOCS _ ...`,
`REQUEST SI _ ...`, department-coded operational subjects, and a small
marketing/phishing vocabulary), so a deterministic rule table was the
natural first approach. Two constraints shaped the decision: (1) an
overfitted rule table would score well on this dataset but generalize
badly, and (2) the team's steer is to minimize LLM usage and reserve it for
genuinely hard inputs in a later phase. Scoring treats stage-1 macro-F1 as
0.30 of the final score, with a ≥ 0.98 target.

## Problem Statement

How should stage-1 classification be implemented so it is accurate,
auditable, generalizable, and reserves LLM capacity for cases rules cannot
cover?

## Options Considered

|  Option  | Description | Generalization | Accuracy | Auditability | Cost/latency | Overall score | Notes |
|----------|-------------|----------------|----------|--------------|--------------|---------------|-------|
| **Weight**   | - | 2 | 2 | 1 | 1 | - | |
| **Tiered rule table + documented precedence** | Literal-pattern rules in fixed tiers (subject 0.95 → body 0.85 → fallback 0.55), in-tier order documented; purity and precedence regression-tested | ✅ | ✅ | ✅ | ✅ | 15 | Chosen; measured macro-F1 1.000 on the working set |
| **LLM classifies every email** | Ship each email to an LLM for a category + confidence | ⚠️ | ✅ | ❌ | ❌ | 8 | Non-deterministic, slow, costly, hard to audit; unnecessary for templated input |
| **ML classifier (trained on labels)** | Train a text classifier on labeled examples | ⚠️ | ✅ | ❌ | ⚠️ | 7 | Would require labels (answer key is evaluation-only); opaque |

✅ = 3 (good), ⚠️ = 2 (acceptable), ❌ = 1 (poor)

## Decision Outcome

We will use a **tiered rule table with documented precedence**, and hold an
LLM in reserve for a later phase under this policy:

1. Rules own the common cases. The table (`classify.RULES`) covers the
   templated vocabulary; tier and in-tier precedence are documented in the
   module docstring and locked by regression tests.
2. The fallback is honest. Unmatched emails fall back to `GENERAL` at
   confidence 0.55 (ADR-0003 bands); low confidence flags them for review
   rather than pretending certainty.
3. LLM policy (for a future phase): an LLM may be used only for emails the
   rule table cannot decide confidently (fallback hits, or
   subject/body signals that conflict in ways the table cannot resolve),
   and its output must be recorded on the trace (`decided_by="llm"`) so it
   is auditable and separable from rule decisions. It must not be used to
   paper over a rule table that could be generalized.
4. Measurement over vibes: rule changes are validated by the full-bundle
   run + scoreboard, and every miss is traced to a document feature
   (e.g. quoted thread tails) and fixed as a generalization, never as a
   per-email patch.

Measured result at acceptance: stage-1 **macro-F1 1.000** (accuracy 1.000,
per-category precision/recall/F1 all 1.00) on the 520-email working set,
after one eval-guided precedence fix (named BL request vs quoted thread
tail). The single iteration took macro-F1 from 0.976 to 1.000; no inbox ids
or answer-key labels were used at any point.

## Consequences

* Good, because classification is instant, deterministic, free, and fully
  auditable (every decision names its rule).
* Good, because the LLM policy gives a clear, narrow escape hatch without
  surrendering ownership of the common cases.
* Bad, because new vocabulary (new subject codes, new spam patterns) needs
  rule additions; the fallback + review path limits the damage meanwhile.
* Unknowns/risks: a differently-worded real inbox could degrade recall; the
  fallback-then-review path and the reserved LLM tier are the mitigation.

## Confirmation

The `classify` module docstring carries the tier/precedence contract;
`tests/unit/test_classify_matrix.py` locks the matrix and precedence
conflicts; the scoreboard run is recorded in the execution plan's evidence
column at each tuning iteration.

## Links

| Type | Links |
| -----| ------|
| **ADRs** | ADR-0003 (confidence bands), ADR-0004 (escalation table) |
| **Issues** | #10, #11, #12, #19 (classification + minimal pipeline) |

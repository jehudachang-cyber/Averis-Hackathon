# ADR-0006: Gemini OCR Policy For Scanned Attachments

| | |
| ---| ---|
| **Status** | 🟢 Accepted (amended 2026-09-20: model rotation) |
| **Created** | 2026-09-19 |
| **Last Updated** | 2026-09-20 |
| **Deciders** | bubble-guppy, opencode session |
| **Tags** | ocr, llm, gemini, reliability, secrets |

---

## Context

The working dataset contains 28 PDF attachments; a subset are scans with no
text layer (pymupdf's text extraction yields nothing usable — flagged via
`ParsedDocument.scanned`). ADR-0005 fixed the policy: deterministic rules
everywhere possible, an LLM only where genuinely required. Scanned pages are
that case — no text layer exists to rule over.

The team holds multiple Gemini API keys (free tier), stored in `.env` as
`GEMINI_API_KEYS` (comma-separated, see `.env.example`). `.env` is
gitignored; only the format template is tracked.

## Decision

1. **SDK:** official `google-genai` package (declared via `uv add`).
2. **Model:** rotation over `[gemini-3.8-flash, gemini-2.5-flash,
   gemini-3.5-flash-lite, gemini-3.1-flash-lite]` (amended below; originally
   `gemini-2.5-flash`) — verbatim transcription needs no reasoning
   depth; the lite tier keeps the most generous free-tier headroom, and
   model+key rotation multiplies the free-tier quota across team keys. A
   throttled or retired model falls through to the next in the list.
3. **Prompt contract:** transcribe verbatim, preserve line structure, no
   markdown/ commentary/ translation. The parser must stay faithful; label
   interpretation stays with extract (#20) — the same separation the txt/xlsx
   docx parsers follow.
4. **Key + model rotation:** calls iterate `GEMINI_API_KEYS` in
   `resolve_models()` order (default `DEFAULT_GEMINI_MODELS`); a failing
   (key, model) pair is skipped and the next model, then the next key, is
   tried. All pairs failing maps to the standard
   `UNREADABLE` contract (confidence 0.1, `error` set) — OCR never raises
   into the pipeline.
5. **Key loading:** python-dotenv populates the environment from `.env`
   (explicit user decision, AGENTS §0.6). Missing configuration is an
   actionable error message, not a crash.
6. **Audit:** OCR output carries `decided_by="llm"` end-to-end (ADR-0003's
   trace requirement) and parse confidence 0.85 — the LLM band — so review
   can weigh transcribed documents differently from native text.
7. **Testability:** the network call lives behind one module seam
   (`llm._generate`); unit tests monkeypatch it. The gate stays fully
   offline.

## Alternatives considered

- **Tesseract/local OCR:** no network dependency, but heavy platform-specific
  install (matching the demo environment), materially worse accuracy on
  shipping documents, and a new native dependency for marginal gain.
- **Cloud Vision API:** strong OCR, but a second vendor + auth surface for
  the same job Gemini already covers.
- **LLM as field structurer (not just OCR):** rejected per ADR-0005 — the
  label synonym map (#18) handles structure deterministically and stays
  auditable. The LLM's job ends at faithful transcription.

## Consequences

- Runtime (only) gains a network dependency on Google's API; the offline
  test gate and the deterministic stages are unaffected.
- Free-tier quota becomes the sum of team keys; one revoked key degrades
  capacity, not correctness (rotation + UNREADABLE fallback).
- Scanned-page transcription quality is measurable: trace keeps
  `decided_by="llm"` per email, so eval can attribute stage-3 misses to OCR
  vs comparison logic.

## Amendment (2026-09-19): live activation

Smoke-testing against a real scan surfaced two realities and completed the
policy:

1. **Model retirement.** `gemini-2.5-flash` returns 404 for new keys
   ("no longer available to new users"); the API names a successor. The
   default now tracks the rolling `gemini-flash-lite-latest` alias (lite
   tier: no reasoning depth needed, most generous free quota), and
   `GEMINI_MODEL` env var overrides without a code change — retirements
   are operational events, not code events.
2. **Successful OCR suppresses `unreadable`.** ADR-0004 rule 3 keys on
   *unusable content*, not on "was scanned" — once OCR transcribes a scan
   into usable rows, escalating would under-use the evidence. Scans with
   keys flow: OCR → kind-from-transcription → extract → compare, and the
   email carries `decided_by="llm"` end to end. Without keys (or all keys
   failing) the 0.25/0.1 UNREADABLE contract stands unchanged.
3. Transcriptions arrive as clean `Label: value` colon rows (verified on a
   real 512_SI scan); the extract stage consumes them unmodified apart from
   one added surface label (`CONTAINERS`).

## Amendment (2026-09-20): model rotation

The rolling `gemini-flash-lite-latest` alias always settles on *a* lite
model, but the team's preferred flash models were never tried. The default
is now an ordered rotation — `gemini-3.8-flash` → `gemini-2.5-flash` →
`gemini-3.5-flash-lite` → `gemini-3.1-flash-lite`. A model that returns 429
(rate limit) or 404 (retired pin) is skipped and the next model — or, once
the list is exhausted, the next key — is tried; a throttle never crashes the
run. `GEMINI_MODEL` still pins a single model and `GEMINI_MODELS` overrides
the whole list; both remain operational, not code, events.

# ADR-0003: Stage Confidence And Reliability Model

| | |
| ---| ---|
| **Status** | 🟢 Accepted |
| **Created** | 2026-09-19 |
| **Last Updated** | 2026-09-19 |
| **Deciders** | bubble-guppy, opencode session |
| **Tags** | pipeline, reliability, scoring |

---

## Context

The pipeline decides, per email: a category (stage 1), and for comparison
requests a match/mismatch/escalate verdict (stage 3). The scoring model
weights end-to-end correctness at 0.50 and treats `NEEDS_REVIEW` as a
separate *reliability* axis (escalation recall/precision), rather than
counting escalations as wrong answers. Stage outputs also feed a human
review workflow, so downstream consumers need to know how much to trust an
automatic verdict. The team agreed (plan decision log, 2026-09-18) on a
rules-first core with escalation instead of confident guessing, and the user
steer for this milestone is "deterministic for the common cases; LLM only
where rules would overfit".

## Problem Statement

How should stages express decision confidence, and when should the pipeline
stop deciding and escalate to `NEEDS_REVIEW`?

## Options Considered

|  Option  | Description | Generalization | Reliability recall | Effort | Auditability | Overall score | Notes |
|----------|-------------|----------------|--------------------|--------|--------------|---------------|-------|
| **Weight**   | - | 1 | 2 | 1 | 1 | - | |
| **Confidence bands + escalate-on-low** | Every stage returns a numeric `Confidence` with a named reason; decisions below the stage's band threshold escalate | ✅ | ✅ | ⚠️ | ✅ | 12 | Chosen |
| **Decide always, never escalate** | Force an OK/MISMATCH verdict from every input | ❌ | ❌ | ✅ | ⚠️ | 6 | Turns unreadable input into false defects |
| **LLM judges everything** | Ship every email to an LLM for a verdict + self-rated confidence | ⚠️ | ⚠️ | ❌ | ❌ | 6 | Slow, non-deterministic, hard to audit; overkill for templated docs |

✅ = 3 (good), ⚠️ = 2 (acceptable), ❌ = 1 (poor)

## Decision Outcome

We will use **confidence bands + escalate-on-low**.

1. Every stage attaches a `Confidence(score, reason)` to its decision,
   carried on `StepEvent` (trace) and summarized by the review stage.
2. A decision is only *committed* if its confidence meets the stage's
   commit band; otherwise the email is routed to `NEEDS_REVIEW` with the
   stage-appropriate `review_reason`.
3. Commit bands (initial, tuned only against documents + scoreboard):

   | Stage | Commit band | Below-band behavior |
   | --- | --- | --- |
   | classify | ≥ 0.85 | keep the category but flag low-confidence for review |
   | parse | ≥ 0.5 | document is treated as unusable → `unreadable` |
   | extract/compare | ≥ 0.7 | missing/ambiguous fields → `missing_value` |
   | review (final) | any | escalations always win over forced verdicts |

4. Reliability recall (never silently guess) outranks escalation precision:
   when in doubt between OK and escalation, escalate.

## Consequences

* Good, because scoring treats correct escalations as their own axis, so
  honesty is never penalized as a wrong answer.
* Good, because every decision carries a machine-readable reason, giving
  the demo dashboard an audit trail (`trace.py`).
* Bad, because rules need per-stage calibration; too-low bands silently
  degrade end-to-end score, too-high bands inflate `NEEDS_REVIEW`.
* Unknowns/risks: scanned PDFs may sit between bands (parse 0.25 < 0.5);
  expected handling is OCR (Gemini, later milestone) or `unreadable`.

## Confirmation

Each stage issue (classify #4–6, parsers #7–11, extract/review) must carry
the band constants and escalation tests. The eval loop records stage-1
macro-F1, defect F1, end-to-end, and reliability on every tuning iteration.

## Links

| Type | Links |
| -----| ------|
| **ADRs** | ADR-0004 (escalation rules), ADR-005 (classification approach) |
| **Issues** | #7 (contracts), #10–12 (classification) |

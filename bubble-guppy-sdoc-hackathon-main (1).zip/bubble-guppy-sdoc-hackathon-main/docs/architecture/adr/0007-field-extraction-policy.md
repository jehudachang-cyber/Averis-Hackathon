# ADR-0007: Field Extraction Policy

| | |
| ---| ---|
| **Status** | 🟢 Accepted |
| **Created** | 2026-09-19 |
| **Last Updated** | 2026-09-19 |
| **Deciders** | bubble-guppy, opencode session |
| **Tags** | extraction, labels, normalization, reliability |

---

## Context

Extract stage (issue 20) turns `ParsedDocument` rows into
`ExtractedFields`. The challenge: the same field appears under different
surface labels across SI and BL renderings (the generator's stated
"same info looks different" design), and attachments come in four formats
with two distinct row styles. The extraction policy must be deterministic
and auditable (ADR-0005), never tuned against the answer key.

Observed reality (all 250 attachments scanned):

- txt/xlsx/docx always emit `Label: value` colon rows.
- PDFs mix colon rows (totals/summaries) with **bare-label blocks** —
  `Shipper` followed by value lines, sometimes glued
  (`Consignee (Non-Negotiable) BALL & DOGGETT…`), and a container table
  whose bare `GROSS WEIGHT (KG)` header sits above per-container values,
  not the shipment total.
- Labels carry Chinese annotations (`发货人`), unit/qualifier
  parentheticals, `TOTAL` prefixes, and a real-world `WeightII` typo.
- Two documents deliberately carry blank values (`SHIPPER:` with nothing
  after) — the dataset's `missing_value` escalation cases.

## Decision

1. **One vocabulary, two consumers.** `normalize_label` + `SYNONYM_MAP`
   (issue 12) serve both the colon-row path and the bare-block path;
   formats share the exact same extraction semantics.
2. **Parentheticals are noise.** Normalization strips *all* parenthetical
   segments (units, port codes, qualifiers) plus CJK annotations. This
   keeps the map collision-free: `Consignee (Non-Negotiable)` and plain
   `CONSIGNEE` are one key.
3. **Bare blocks via longest-prefix matching.** A colon-less row either
   matches a mapped label prefix (starting a value block that runs until
   the next colon row or known label), or is ignored. Glued lines become
   label + inline value.
4. **The container-table trap is explicit.** Bare `GROSS WEIGHT` (and
   `CONTAINER NO.`/`DESCRIPTION`) are treated as table headers, never as
   field starts; authoritative weights arrive later as `TOTAL Gross …:`
   colon rows. Per-container values must never leak into the total.
5. **First occurrence wins.** Duplicate labels for the same field resolve
   to the first occurrence — documents are rendered top-down.
6. **Blanks stay blanks.** A label with no value (`SHIPPER:`) yields an
   empty field, which the review stage escalates as `missing_value`
   (ADR-0004). Extraction never invents values.
7. **Kind detection stays at parse stage.** The extractor trusts
   `ParsedDocument.kind`; `assign_roles` picks the SI as the reference by
   kind and returns `None` on ambiguity (escalate, don't guess).

## Alternatives considered

- **LLM structuring of document values:** rejected per ADR-0005 — the
  vocabulary is finite, templated, and fully deterministic here (measured:
  99.6–100% field coverage, zero fabrication). The LLM's job ends at
  verbatim transcription of scanned pages (ADR-0006).
- **Per-format extractors:** rejected — four code paths to keep in sync
  for one shared row shape; the uniform `rows` contract exists precisely
  to avoid this.
- **Fuzzy label matching:** rejected as un-auditable; the harvested
  vocabulary is closed (2,971 label rows resolve 100%) and new unknown
  labels fail loudly by leaving fields blank → review.

## Consequences

- Extraction is deterministic, offline, and traceable to a label decision
  per field.
- A genuinely new surface label (outside the pools) produces blank fields
  and a `missing_value` escalation — visible, not silent.
- The bare-block stop-set (`_NON_FIELD_LABELS`) must be extended if the
  document pool grows; tests pin the current vocabulary.

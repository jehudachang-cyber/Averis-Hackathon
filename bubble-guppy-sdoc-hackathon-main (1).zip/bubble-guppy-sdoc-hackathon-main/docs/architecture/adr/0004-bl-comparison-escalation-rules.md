# ADR-0004: BL-Comparison Escalation Rules

| | |
| ---| ---|
| **Status** | 🟢 Accepted |
| **Created** | 2026-09-19 |
| **Last Updated** | 2026-09-19 (amended: rule 1a send-request clearance) |
| **Deciders** | bubble-guppy, opencode session |
| **Tags** | pipeline, review, escalation |

---

## Context

For a `BL_COMPARISON` email the pipeline must compare the Shipping
Instruction (reference) against the draft Bill of Lading over seven fields
and report either a mismatch or "no mismatch detected". Real inboxes contain
cases where a confident verdict is impossible: documents missing, wrong
document types attached, scans that cannot be read, or required fields left
blank. USE_CASE.md's reliability section requires escalation with source
evidence instead of guessing or failing silently, and the scoring model
reports escalation quality on a dedicated reliability axis.

## Problem Statement

In which situations must the pipeline output `NEEDS_REVIEW` instead of
OK/MISMATCH, and which `review_reason` applies?

## Options Considered

|  Option  | Description | Reliability recall | Precision | Simplicity | Auditability | Overall score | Notes |
|----------|-------------|--------------------|-----------|------------|--------------|---------------|-------|
| **Weight**   | - | 2 | 1 | 1 | 1 | - | |
| **Deterministic reason table** | Fixed precedence table mapping observable conditions to `review_reason` values, checked before any match verdict | ✅ | ✅ | ✅ | ✅ | 13 | Chosen |
| **Heuristic scoring / ML escalation** | Train a model to predict "should escalate" from features | ⚠️ | ⚠️ | ❌ | ❌ | 6 | Needs labels; opaque; overkill |
| **Escalate nothing** | Always output OK or MISMATCH | ❌ | ❌ | ✅ | ❌ | 5 | Guessing on undecidable input |

✅ = 3 (good), ⚠️ = 2 (acceptable), ❌ = 1 (poor)

## Decision Outcome

We will use a **deterministic reason table**, evaluated in this order
(first hit wins) whenever an email reaches the comparison stage:

| # | Condition (observable from documents) | Status | `review_reason` |
| --- | --- | --- | --- |
| 1 | Comparison request with zero or one of the SI/BL pair present | `NEEDS_REVIEW` | `missing_attachment` |
| 2 | An attached document is neither an SI nor a BL (invoice, packing list, COO…) | `NEEDS_REVIEW` | `wrong_doc_type` |
| 3 | A required document parsed but its content is unusable (garbled, empty, scanned with no OCR result) | `NEEDS_REVIEW` | `unreadable` |
| 4 | Both documents usable but a required field is blank/unspecified in either | `NEEDS_REVIEW` | `missing_value` |
| 5 | All seven fields present and compared | `OK` if all equivalent, else `MISMATCH` | — |

Rules:

* The SI is the reference; field equivalence is judged after value
  normalization (case, whitespace, weight/container formatting).
* A `MISMATCH` lists the differing canonical fields in `defect_fields`
  (canonical order); `has_defect` is true iff status is `MISMATCH`.
* Escalations always carry evidence (trace events + `detail`) so a human can
  confirm or correct; escalation recall outranks escalation precision
  (ADR-0003).

## Consequences

* Good, because each escalation is reproducible and testable from document
  facts alone; no threshold tuning is needed for the escalation path.
* Good, because the precedence order resolves multi-fault emails
  deterministically (e.g. one SI + one invoice → `wrong_doc_type` wins over
  `missing_attachment` only if the SI is also absent; rule 1 fires first
  when both docs are missing).
* Bad, because the table must be kept in sync with new edge cases; changes
  require an ADR revision and regression tests.
* Unknowns/risks: documents that are *partially* wrong-type (mixed packets)
  may need a sub-reason later; defer until the dataset shows such cases.

## Confirmation

`review.py` implements exactly this table with unit tests per row (including
precedence conflicts), and the escalation fixtures (`email_no_attachment`,
`email_si_only`) exercise rules 1 and 2 end-to-end.

## Amendment (2026-09-19): rule 1a — send-request clearance

The first full-inbox evaluation (2026-09-19, see
`docs/explanation/eval-report-2026-09-19.md`) exposed a systematic
over-escalation: 91 main-set comparison emails carry no attachments *by
design* (bodies are forwarding requests — "Please assist to send the draft
BL for X for checking asap") yet rule 1 escalated all of them as
`missing_attachment`, sinking escalation precision to 0.157. The generator
spec (`data_v2/README.md`) marks attachment-less comparison emails `OK`;
its true missing-attachment cases (506–510) say so in the body instead.

Refinement: rule 1 keeps escalation as the default, but **clears to OK**
when — and only when — four deterministic anchors all hold (no API calls,
no ML, closed pattern lists):

1. **Known layout** — the intro is followed by a signature block or a
   quoted-thread block; unknown body shapes never clear.
2. **Explicit send request** — a politeness word (`please`/`kindly`/`pls`)
   and a send/forward/share verb governing a draft-BL noun, inside one
   sentence of the live intro.
3. **No comparison-intent word anywhere** (compare/verify/confirm/match/
   against/discrepancy…). Note `check/checking` is deliberately excluded —
   the send family itself writes "for checking asap" — and subjects are
   deliberately not verb-scanned (both families share one subject builder).
4. **No missing/dropped-attachment note** in body or subject.

The list is deliberately closed and conservative: uncertainty must
escalate exactly as before (recall-first), so the change trades a small,
bounded recall risk for a large precision win. Verified on the full bundle:
flag count 108 → 17, escalation precision 0.157 → **1.000** at unchanged
recall (0.850) and unchanged FINAL SCORE 1.0000.

## Links

| Type | Links |
| -----| ------|
| **ADRs** | ADR-0003 (confidence model) |
| **Issues** | #7 (contracts), extract/compare/review issues |

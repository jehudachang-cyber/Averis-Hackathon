# ADR-0008: Multilingual Emails & Documents — Deterministic Router + LLM Label Translation

| | |
| ---| ---|
| **Status** | 🟢 Accepted (issue #46) |
| **Created** | 2026-09-20 |
| **Last Updated** | 2026-09-20 |
| **Deciders** | bubble-guppy (lead), Buffy session |
| **Tags** | multilingual, llm, gemini, classification, extraction, fixtures |

---

## Context

The pipeline's rule inventory is English-only. Verified gaps (the survey,
2026-09-20):

- `classify.py` — every subject/body rule pattern is an English literal; a
  BM/ZH email falls through to the `GENERAL` fallback at 0.55.
- `extract.py` — `normalize_label()` **strips all CJK characters**
  (`_CJK_RE`), which is exactly why annotation-level bilingual labels
  (`Shipper (发货人):`, `Gross Weight毛重(KGS)`) already work. A
  **pure-ZH label** (`发货人:`) normalizes to the empty string and never
  maps — the concrete extraction gap.
- `parsers/txt.py` — the garble gate treated any CJK codepoint as binary
  garbage, so a native-ZH `.txt` document was `UNREADABLE` before any
  router could see it (fixed in this issue: CJK ideographs are text).
- `parsers/` kind hints — SI/BL title detection matches English titles
  only (`SHIPPING INSTRUCTION`, `BILL OF LADING`).
- No BM appears anywhere in the working bundle or the generator pools; ZH
  appears only as annotations. Vocabulary from `data_v2/pools.py` is
  ZH-annotated English labels — nothing sanctions a pure-ZH or BM synonym
  inventory for the map.

Options considered: (a) widen `SYNONYM_MAP` with translated surface forms;
(b) translate documents to English upstream of extraction; (c) restrict to
annotation-level support (works today). (a) requires a sanctioned ZH/BM
glossary covering every surface form, is brittle to phrasing variants, and
still leaves SI/BL title detection and body classification untranslated.
The demo's Gemini integration (ADR-0006) already provides a supervised,
audited LLM path.

## Decision

1. **Deterministic router, LLM translation.** A pure rule module
   (`parsers/lang.py`) classifies each parsed document `en` / `zh` / `bm`:
   a document is **zh** when ≥ 2 rows *start* with a CJK ideograph
   (annotation-level bilingual labels are Latin-first and never trigger),
   and **bm** when ≥ 2 distinct BM shipping markers occur (Latin script is
   invisible to script ratio; markers come from the sanctioned fixtures).
   The decision of *whether* the LLM is involved stays reproducible and
   traceable (ADR-0005); only the label vocabulary crosses the language
   boundary.
2. **Translation at parse stage, labels only.** Non-English documents are
   translated via a second Gemini touchpoint (`llm.translate_to_english`,
   seam `_generate_text`): title and field labels become standard English
   shipping terminology; **values are preserved byte-for-byte** —
   independently translated values could diverge between SI and BL and
   fabricate mismatches. The translated text is re-parsed with the same
   row convention (`_fold_continuations`, `detect_kind`), so extraction,
   comparison, and review run **unchanged**; the document carries
   `translated=True`.
3. **Audit parity with OCR.** `decided_by="llm"` whenever any document was
   OCR'd *or* translated (pipeline audit hook extended). A ZH/BM thread's
   record therefore never claims `decided_by="rules"`.
4. **Failure contract mirrors ADR-0006.** No keys → no translation, no
   guess: documents keep their parsed text and review escalates
   (`wrong_doc_type` via unassignable roles). All keys failing or an empty
   translation → `UNREADABLE` with the reason. Live translation is best
   effort at 0.85 (ADR-0003 LLM band).
5. **Classification literals from sanctioned fixtures.** The classifier
   gains ZH/BM body rules whose literals (`提单草稿`,
   `draf bill of lading`, `核对提单草稿与运输指示`, …) come from the
   multilingual fixture bundle (`sdoc-hackathon-bundle-multilingual/`),
   never invented ad hoc. Tier precedence and confidence bands are
   unchanged (ADR-0003/0005).
6. **Fixtures as the scoring story.** The fixture bundle twins two scored
   English threads (`email_453` → OK, `email_004` → MISMATCH
   consignee/notify_party) with values byte-identical across SI/BL, so
   each twin's expected verdict transfers by construction. The scored
   520-email bundle is never modified; the ids sit outside the
   `email_NNN` space. The demo dashboard serves the fixture threads in the
   Showcase subset via a merged cache.
7. **Garble gate is script-aware.** The txt parser's binary-garbage
   heuristic now whitelists CJK ideographs; Latin-1/ASCII behavior is
   unchanged (verified: no-OCR run over the working bundle stays
   byte-identical).

## Consequences

- Multilingual correctness is proven by fixture twins + unit tests with
  the LLM seam mocked (offline gate) — it cannot hit `score_cli` targets
  because the working bundle has no BM/ZH. Accepted (issue #46 ambiguity
  resolution).
- The English regression gate stays the hard invariant: the no-OCR run
  over the 520-email bundle must remain byte-identical.
- BM coverage is exactly as deep as the fixtures; deeper BM (new phrasings,
  more threads) means new reviewed fixture content, not new code paths.
- Two LLM seams (`_generate`, `_generate_text`) share key+model rotation and the
  `GEMINI_MODEL` pinning story; free-tier budget grows by one call per
  non-English document.
- `translate_prompt`'s inline terminology examples double as the
  sanctioned glossary pointer; extending vocabulary = extending the
  reviewed fixtures + prompt examples together.

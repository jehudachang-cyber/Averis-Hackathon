# The demo dashboard

The React dashboard (`ui/`) is the visual front end of the pipeline: every
number it shows comes from the real pipeline run cached in the
[bridge](../reference/bridge.md) — no mocks, no re-derivation. Launch it
with `./demo.sh` (see [How-To](../how-to/index.md#run-the-demo-dashboard)).

## Overview

The landing page: category and status distributions, escalation breakdown
per reason, the measured score strip (macro-F1 / defect-F1 / e2e / FINAL —
embedded display labels measured once via `score_cli.py`; the answer key
never leaves the scorer), and a **Mismatch overview** section — a clickable
list that drops you into the matching story in Browse.

## Pipeline

The pipeline cinematic player: stage-by-stage animation of a chosen email
flowing through classify → parse → extract → compare → review, driven by the
real `Trace` events. Confidence values, matched-rule evidence, and stage
decisions come straight from the events — the same data
[`api/emails/{id}/story`](../reference/bridge.md) serves.

## Browse

The email inspector. A subset selector (shared with the Pipeline page:

- **Showcase** — five pinned hero stories, one per interesting outcome
  (clean OK, multi-field mismatch, spam, missing attachment, unreadable scan)
- **Starter (~30)** — a deterministic taste of everything: one per category,
  one per escalation reason, plus mismatches
- **BL Comparison** — every comparison email
- **All 520** — everything

) filters the summary list; picking an email opens its **story**: the
verdict, the classification evidence, the parsed document lines with
per-field row anchors (which literal document line produced which extracted
value), and the per-field SI-vs-BL comparison table.

## ResolvePanel (auto-resolve)

Every `MISMATCH` story in Browse shows the ResolvePanel below the verdict:

1. Pick a value per mismatched field — the **SI value is prefilled**;
   switch to the BL value or type a manual override.
2. Consignee, notify party, and both ports are title-document fields and
   always require ticking an **explicit confirm**; other fields resolve
   with the single default confirm.
3. **Preview email** shows the exact recipient banner: `SANDBOX → …` by
   default, `REAL SEND → …` only when `ALLOW_REAL_SEND=1` on a real deploy.
4. **Send** delivers via Gmail SMTP and appends to the resolve log.

The composed email is markdown — a discrepancy table (SI vs BL) followed by
the resolved values — sent with both plain-text and rendered-HTML parts.
Resolutions are logged (file or Firestore); **verdicts are never mutated**.
Full policy: [Resolve & mailer reference](../reference/resolve.md).

## Where the data comes from

The bridge runs the 520-email pipeline once at startup and serves
everything from that snapshot (fingerprinted; warm restarts cost zero
Gemini calls). When OCR/translation keys are live, scanned and translated
documents appear with their transcribed/translated rows — those stories
carry `decided_by="llm"`.

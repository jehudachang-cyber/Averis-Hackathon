# Evaluation Report — Full-Inbox Run, 2026-09-19

**Scope:** all 520 emails of `sdoc-hackathon-bundle/`, OCR enabled (2 API keys,
default model `gemini-flash-lite-latest`).
**Submission:** `submission_lite.json` (untracked — never commit it).
**Scorer:** `sdoc-hackathon-docker/server/score_cli.py` against the answer key,
used strictly for evaluation.

---

## 1. Headline result

```
FINAL SCORE  1.0000   (weights: stage1=0.3, stage3=0.2, end-to-end=0.5)
```

| Axis | Value | Notes |
| --- | --- | --- |
| Stage 1 accuracy / macro-F1 | 1.000 / 1.000 | all 5 categories perfect |
| Stage 3 defect recall / precision | 1.000 / 1.000 | 46/46 defect emails caught |
| Stage 3 field-level F1 / exact match | 1.000 / 1.000 | defect fields exactly right |
| End-to-end | **1.000** | headline metric |
| Escalation recall (diagnostic) | 0.850 | 17/20 gold NEEDS_REVIEW escalated |
| Escalation precision (diagnostic) | 0.157 | 108 flagged, 17 correct |

The **weighted score is saturated** (1.0000) and is identical to the previous
`gemini-flash` run (`submission_ocr.json`, also 1.0000) — the switch to the
lite alias cost nothing measurable. The interesting signal for the team is
entirely in the **reliability diagnostics** below.

## 2. Pipeline census (our run)

| | Count |
| --- | --- |
| Category totals | BL_COMPARISON 220 · SI_REQUEST 125 · INVOICE_QUERY 75 · GENERAL 60 · SPAM 40 |
| Statuses | OK 365 · NEEDS_REVIEW 108 · MISMATCH 47 |
| Flag reasons | missing_attachment 96 · wrong_doc_type 5 · unreadable 2 · missing_value 5 |

## 3. Reliability axis — what the numbers actually mean

Gold has 20 NEEDS_REVIEW emails (4 reasons × 5, all in `email_501`–`email_520`).
We escalated 108, of which 17 are correct.

### 3.1 Per-reason recall (17/20 correct)

| Gold reason | Escalated | Missed | Detail |
| --- | --- | --- | --- |
| wrong_doc_type | 5/5 | — | |
| missing_attachment | 5/5 | — | |
| missing_value | 5/5 | — | |
| unreadable | 2/5 | **3** | emails 512, 513, 514 |

The 3 misses are the **deliberate ADR-0006 amendment trade-off**: these are
image-only scans that our Gemini OCR transcribed successfully, so the pipeline
flowed them through comparison instead of escalating.

* email_512: OCR produced clean `Label: value` rows → OK. Correct comparison
  outcome, "wrong" only because gold was built pre-OCR.
* email_514: same → OK.
* email_513: same → MISMATCH on `consignee` + `notify_party`. Looking at the
  transcription, these are trivial formatting variants — `PTE LTD` vs
  `PTE. LTD.`, `V002` vs `V.002` — that our normalizer should absorb. **This
  is the only case in the entire run where our answer may be genuinely
  superior to the key**: scoring credited us with zero false defects here, so
  the score didn't move, but a real operator would probably call 513 a match,
  like us.

Two of the five `unreadable` gold cases escalated for the *intended* reasons:
email_511 (image-only BL whose OCR call failed) and email_515 (same).

### 3.2 Over-flagging (108 flags vs 20 gold)

Every one of the 91 excess flags has reason `missing_attachment`, and all of
them are emails the key marks `status: OK`. **Root cause: an interpretation
gap, not a bug.**

* The bundle's generator (`data_v2/emails.py`, `body_bl_comparison`) builds
  ~100 main-set BL_COMPARISON emails *without attachments*, whose bodies are
  forwarding requests ("Please assist to send the draft BL for X for checking
  asap"). `data_v2/README.md` §"Ground-truth schema" states the intended
  semantics: *emails with no attachments always have `status: OK`* — a clean
  comparison request that happens to carry no documents is business-as-usual,
  not a broken pair.
* Our review rule (ADR-0004 rule 1: `<2` attachments ⇒ NEEDS_REVIEW/
  `missing_attachment`) treats any comparison email lacking the SI/BL pair as
  a dropped-attachment incident.
* The generator's true `missing_attachment` cases (`email_506`–`email_510`)
  are distinguishable in-band: their bodies explicitly say "(attachments
  appear to have been dropped)" / "(the draft BL is still missing)".

**Impact if unchanged:** precision 0.157 on a scorer built from the same
convention; in production, 85% of human-review traffic would be noise.

**Options** (needs an issue; this report does not change code — see §5 for
the fix that was subsequently implemented):

1. **Body-intent check (recommended).** If a BL_COMPARISON email has <2
   attachments *and* the body reads as a forwarding request ("please assist to
   send", "kindly send", "send the draft BL") without a dropped-attachment
   note, treat as OK. If the body claims documents were attached, escalate.
   Matches gold on all 96 current flags; risk: phrase-list fragility on new
   phrasings.
2. **Solely phrase-keyword escalation.** Escalate only when the body contains
   an explicit dropped/missing note. Simpler, narrower recall surface.
3. **Leave as-is.** Escalation is diagnostic-only today (excluded from the
   final score). Defensible until the rubric weights precision.

Recommend option 1, implemented in `review.py` + `pipeline.py` (input from
`classify`/`extract` silos not required), with unit tests for both body
families.

## 4. OCR model switch — verification

The run that produced `submission_lite.json` was the first end-to-end run on
`gemini-flash-lite-latest` (the corrected default from the previous session;
`.env` carries no `GEMINI_MODEL` override).

* All 28 scanned pages transcribed into extractable `Label: value` rows where
  the calls succeeded.
* 6 of 8 scanned-attachment OCR calls succeeded; 2 failed transiently
  ("all keys failed") on email_511/515 BLs, which then correctly escalated as
  `unreadable` per the ADR-0004/0006 fallback contract.
* Failure mode is **operational, not model-related**: the same key pool
  succeeded on 512–514 seconds earlier. Free-tier rate limits remain the
  binding constraint; rotation absorbed one round of failures but two
  consecutive all-key failures slipped through. A per-run retry pass for
  UNREADABLE scans (or spacing calls) is worth an issue if it recurs.
* Stage 1/3 and end-to-end scores are byte-identical to the `gemini-flash`
  baseline; no regression from the lite switch.

## 5. Resolution — rule 1a fix, post-fix re-run (added 2026-09-19)

Option 1 from §3.2 was implemented the same day as **ADR-0004 rule 1a**
(`review.py`): escalation stays the default, but rule 1 clears to OK when
four deterministic anchors all hold — known body layout (signature or
quoted-thread block after the intro), an explicit send-request sentence
(politeness word + send/forward/share verb governing a draft-BL noun), no
comparison-intent word anywhere in the body, and no missing/dropped-
attachment note in body or subject. No API calls; closed pattern lists;
any doubt escalates exactly as before. Full rationale in the ADR-0004
amendment.

Post-fix full run (`submission_lite_v2.json`, OCR enabled, same key pool):

| Metric | Before (§1–§3) | After rule 1a |
| --- | --- | --- |
| Flags | 108 | **17** |
| Escalation precision | 0.157 | **1.000** |
| Escalation recall | 0.850 | 0.850 (unchanged) |
| Stage 1 accuracy / macro-F1 | 1.000 | 1.000 (unchanged) |
| Stage 3 defect P/R, field F1, exact | 1.000 | 1.000 (unchanged) |
| End-to-end | 1.000 (46/46) | 1.000 (46/46) |
| **FINAL SCORE** | 1.0000 | **1.0000** |

Per-reason escalation after the fix: wrong_doc_type 5/5,
missing_attachment 5/5, missing_value 5/5, unreadable 2/5 (512–514 still
recovered by OCR per §3.1). Flag census is now exactly 17, all matching
gold — zero false escalations. The 11 new unit tests in
`tests/unit/test_review.py::TestRule1aSendRequest` cover both body
families plus ambiguous/adversarial shapes; full gate (291 tests, ruff,
format, pyright) passes.

## 6. Commands run (evidence)

```bash
uv run python scripts/run_pipeline.py --data sdoc-hackathon-bundle --out submission_lite.json
#   OCR enabled: 2 API key(s) configured
#   wrote 520 records ... BL_COMPARISON 220 / SI_REQUEST 125 / INVOICE_QUERY 75
#   GENERAL 60 / SPAM 40; MISMATCH 47 / OK 65 / missing_attachment 96 / ...
PYTHONUTF8=1 uv run python sdoc-hackathon-docker/server/score_cli.py submission_lite.json
#   FINAL SCORE 1.0000 (weights: s1=0.3, s3=0.2, e2e=0.5)
PYTHONUTF8=1 uv run python sdoc-hackathon-docker/server/score_cli.py submission_ocr.json
#   FINAL SCORE 1.0000 (baseline, gemini-flash default, identical diagnostics)

# Post-fix re-run (after ADR-0004 rule 1a):
uv run python scripts/run_pipeline.py --data sdoc-hackathon-bundle --out submission_lite_v2.json
PYTHONUTF8=1 uv run python sdoc-hackathon-docker/server/score_cli.py submission_lite_v2.json
#   flagged 17, escalation precision 1.000, recall 0.850, FINAL SCORE 1.0000
```

(Windows console needs `PYTHONUTF8=1` for the scorer's box-drawing output.)

Cross-checked aggregates with a one-off analysis script: category/status
census, flag-reason × gold-status cross-tab, per-reason recall, attachment
resolution audit, and OCR transcriptions of email_511–515.

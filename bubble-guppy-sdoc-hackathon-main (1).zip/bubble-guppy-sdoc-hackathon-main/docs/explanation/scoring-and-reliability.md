# Understanding the scoring and the reliability axis

The hackathon score and the reliability diagnostics measure different
things, and keeping them separate is a deliberate design stance.

## The final score

```
final_score = 0.30·stage1_macroF1 + 0.20·stage3_defectF1 + 0.50·end_to_end
```

- **Stage 1 macro-F1** — classification quality across the five categories,
  macro-averaged so rare categories count as much as common ones.
- **Stage 3 defect-F1** — for comparison emails, how precisely the
  mismatched fields (`defect_fields`) are identified.
- **End-to-end** — routed *and* exact: the full record (category + status +
  defect fields) must be right.

Current state on the working bundle: all three axes at 1.000 (FINAL 1.0000),
with OCR live — see the [evaluation report](eval-report-2026-09-19.md) for
how that was reached and what the diagnostics mean.

## The reliability axis (outside the score)

`NEEDS_REVIEW` is scored separately, as **escalation recall and precision
per reason** (`wrong_doc_type`, `missing_attachment`, `unreadable`,
`missing_value`). The design contract is *recall over precision* (ADR-0003):
when the system cannot decide, it must say so rather than guess. A false
escalation costs a human a quick glance; a false `OK` ships a wrong Bill of
Lading.

This has a practical consequence: the same pipeline run can score FINAL
1.0000 both with and without Gemini keys, because scanned PDFs without OCR
correctly escalate `unreadable` instead of silently comparing nothing. The
score stays high; only the *capability* (how many scans flow through) and
the escalation mix change. The eval report §3.1 explains the one deliberate
trade where OCR turns some gold-`unreadable` cases into decided ones —
by design, `decided_by="llm"` marks every such record.

## Blank is not a mismatch

The single most load-bearing distinction in the pipeline: a blank field
means **the system cannot decide** → escalate `missing_value`. Only two
present-but-different values produce a `MISMATCH`. This is why the compare
stage refuses to treat a blank side as a defect, and why the extract stage
leaves missing fields blank rather than inventing values.

## Why deterministic-first

Every stage is a rule table first (ADR-0005). The LLM appears only where
rules genuinely cannot read the input — scanned pages (OCR) and
non-English labels (translation) — and even there the outcome is wrapped
back into the same `ParsedDocument` contract, so everything downstream
stays deterministic and auditable. `decided_by` on each record tells you
which path decided it.

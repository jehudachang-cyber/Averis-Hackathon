# Email classification in plain English

*How the pipeline decides what an email is about — written for non-technical
teammates. No code needed.*

## What classification does

Every email that lands in the shipping-operations inbox must be sorted into one
of five buckets. Everything downstream (open which attachments, compare which
documents, who to notify) depends on getting this first step right.

The five categories are:

| Category | What it means | Example of intent |
| --- | --- | --- |
| **BL_COMPARISON** | "Check my draft Bill of Lading against my Shipping Instruction" | a document-verification request |
| **SI_REQUEST** | "Prepare / send me a Shipping Instruction" | asking for a document |
| **INVOICE_QUERY** | "Why is my invoice wrong? / missing GR / storage charges" | a billing question |
| **GENERAL** | Operational updates, reminders, FYI messages | everyday chatter, not a document task |
| **SPAM** | Marketing, phishing, scams | ignore it |

## The trick: the inbox is heavily templated

The messages are not free-form. They use the same coded subjects and fixed
phrases over and over. Once you have seen a few, you can predict the next one.
The classifier works by learning those patterns **once, up front**, rather than
reading every email from scratch.

It scores like a checklist: if an email looks like a known pattern, bucket it;
if it does not fit, flag it for a human instead of guessing.

## Three levels of certainty

The classifier never just answers — it also says *how sure* it is. This is
called **confidence**. There are three tiers, strongest first:

1. **Subject line (very strong signal)** — e.g. a subject like
   `REQUEST SI _ <vessel> _ <port>` is almost certainly an SI request.
   Confidence 0.95.
2. **Email body (good signal)** — e.g. the body says "check the draft BL
   against the SI". Confidence 0.85.
3. **Fallback (no signal)** — nothing matched. The email is treated as
   GENERAL and flagged for a human to eyeball. Confidence 0.55.

Strong signals always beat weak ones: a coded subject wins over anything the
body says.

## The patterns we actually use (the "templates")

These are the real patterns in the rule table, described in everyday words:

**Subject-line templates:**

- **Spam bait** — "gift card", "claim now", "% off", "exclusive offer",
  "you have won", "verify your account", "bitcoin", "hot singles", etc.
  Any of these make it spam, even before reading the body.
- **Document-check requests** — subjects like `TO CONFIRM DOCS _ <id>`,
  `REQUEST BL DRAFT _ <id>`, or any "draft BL" wording → BL_COMPARISON.
- **Shipping-instruction requests** — `REQUEST SI _ <vessel> _ <port>`,
  `CUST SI _ <id>`, "SI needed" → SI_REQUEST.
- **Billing topics** — "missing GR", "cancel invoice", "local charges",
  "D & D", "total freight" → INVOICE_QUERY.
- **Operational updates** — "update summary", "berthing report", "reminder",
  "delivery planning", "time off request", etc. → GENERAL.

**Body templates (read only if the subject did not settle it):**

- **Spam phrases** — "click here", "claim your", "limited time offer",
  "congratulations!!!", "bank details" → SPAM.
- **Explicit comparison phrasings** — "check the draft BL against the SI",
  "verify the BL", "comparison of the SI and draft bill of lading" →
  BL_COMPARISON.
- **"Shipping instruction"** mentioned in the body → SI_REQUEST.
- **Billing words** — "cancel invoice", "missing GR", "D & D", "local charge"
  → INVOICE_QUERY.
- **Loose "draft bl" mention** → BL_COMPARISON. This deliberately beats
  quoted reply tails, because comparison requests often carry an old email
  quoted below the new one.
- **Conversation leftovers** — "please follow the previous instruction" →
  GENERAL (reached only if nothing above matched).

The order matters. For example, spam phrases beat real work phrases, and an
explicit "check the BL" beats a vague mention, because many SI-request emails
also end with "revert with draft BL once available" — which would otherwise be
a false comparison signal.

## Why no AI / LLM is needed here

Because the templates cover the data so well, rules are free, fast, instant,
and identical every run — you can point at any email and explain exactly which
keyword decided it. A language model would be slower, cost money per email, and
give slightly different answers on every run while being impossible to audit.

The LLM is reserved for one thing rules genuinely cannot do (a later stage):
reading **scanned PDFs** — image-only documents with no text to match. That is
where rules stop and vision-based OCR + escalation to a human begin.

## What happens when nothing matches

Fallback: the email is typed GENERAL at low confidence and routed to a human
review queue, labelled with the reason. The pipeline is built to **never guess
silently** — an unsure email reaching a person is considered the correct,
reliable outcome.
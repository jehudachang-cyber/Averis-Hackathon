# Cloud deployment — single Cloud Run service (issue 52)

One public HTTPS URL serving the whole demo dashboard: the FastAPI bridge
(`api/`) + the built React app (`ui/`) + the pipeline, with secrets injected
from Secret Manager and **no ground truth anywhere in the cloud**.

> Runbook for the one-time GCP provisioning (project, billing, budget alert,
> APIs, Firestore, IAM, Artifact Registry, secrets): see
> [`docs/how-to/gcp-setup.md`](../docs/how-to/gcp-setup.md). All of that
> already exists — this folder only deploys.

## Files

| File | Purpose |
| --- | --- |
| `Dockerfile` | Multi-stage: Node 20 builds `ui/` → `python:3.12-slim` serves `api/` + static UI on `$PORT` |
| `cloudbuild.yaml` | Integrity guard → image build → Cloud Run deploy (cost-capped) |
| `deploy.sh` | Preflight checks (all read-only) then one `gcloud builds submit` |

## One-command deploy

```bash
export PATH="$PATH:/c/Users/caleb/AppData/Local/Google/Cloud SDK/google-cloud-sdk/bin"
gcloud auth login
./deploy/deploy.sh                       # prints the public URL at the end
PROJECT_ID=bubble-guppy REGION=asia-southeast1 ./deploy/deploy.sh   # explicit
```

The script **aborts before any spend** if: no active auth, billing unlinked,
any of the four secrets missing, the Artifact Registry repo missing, ground
truth anywhere in the build context, or the cost caps/sandbox default were
edited away.

## Cost posture (hard rules)

- `min-instances=0` (scale-to-zero), `max-instances=1` — a runaway cannot
  rack up usage.
- One tiny region: `asia-southeast1` (configurable via `REGION`, keep it
  single-region).
- Reuses the **existing** Artifact Registry repo `sdoc-demo` and the
  **existing** four secrets; creates nothing in GCP.
- Warm restarts cost **zero Gemini calls**: the bridge reuses the snapshot
  cache, written to `/tmp/bridge-snapshot.json` (the only writable path on
  Cloud Run).

## Runtime environment (set in the Dockerfile / cloudbuild.yaml)

| Var | Value | Why |
| --- | --- | --- |
| `GEMINI_API_KEYS`, `GMAIL_USER`, `GMAIL_APP_PASSWORD`, `SANDBOX_RECIPIENT` | `--set-secrets` from Secret Manager | never baked into the image or git |
| `ALLOW_REAL_SEND` | `""` (empty) | sandboxed mail by default; sends land in `SANDBOX_RECIPIENT` |
| `SDOC_SNAPSHOT_PATH` | `/tmp/bridge-snapshot.json` | snapshot cache must be writable on Cloud Run |
| `SDOC_RESOLVE_STORE` | `firestore` | resolve log in the existing `(default)` database; downgrades to the file log on any error |
| `SDOC_UI_DIST` | `/app/ui/dist` | `api/app.py` serves the built SPA from the same service |

## Integrity guards (hard)

- `ground_truth.json` / `sdoc-hackathon-docker/` are **never** copied into
  the image. `deploy.sh` step 6 greps the context and refuses to build;
  `cloudbuild.yaml` re-checks inside Cloud Build.
- The dashboard serves measured scores as embedded labels only — no answer
  key reaches the browser or the service.
- Outbound mail is sandboxed unless an operator explicitly sets
  `ALLOW_REAL_SEND=1` on the Cloud Run service (deliberate `gcloud run
  services update`, not a default).

## Local smoke test (no GCP spend)

```bash
cd ui && npm ci && npm run build && cd ..
docker build -f deploy/Dockerfile -t sdoc-demo:smoke .
docker run --rm -d -p 8080:8080 --name sdoc-smoke \
  -e SDOC_OCR_KEYS="" -e SDOC_RESOLVE_STORE=file sdoc-demo:smoke
sleep 45   # first boot runs the pipeline over the bundle (no OCR keys: free)
curl -s localhost:8080/api/health
curl -s localhost:8080/api/overview | head -c 200
curl -s localhost:8080/ | head -c 200          # SPA index.html
curl -s localhost:8080/api/emails | grep -o email_[0-9]* | head -1   # -> story
docker stop sdoc-smoke
```

## GitHub → Cloud Build trigger (optional auto-deploy)

1. Connect the repo: Cloud Console → Cloud Build → Triggers → **Connect
   repository** (GitHub App; grant access to `OctakoPy/bubble-guppy-sdoc-hackathon`).
2. Create the trigger:
   ```bash
   gcloud builds triggers create github \
     --name sdoc-demo-deploy \
     --repo-name=bubble-guppy-sdoc-hackathon --repo-owner=OctakoPy \
     --branch-pattern="^main$" \
     --build-config=deploy/cloudbuild.yaml \
     --project=bubble-guppy
   ```
3. Every push to `main` then builds + deploys with the same cost caps. The
   build config's substitutions (`_REGION`) and the `deploy.sh` preflight
   semantics apply unchanged.

> GitHub Actions stays out (forbidden in this repo); Cloud Build is the only
> CI path.

## Verify after deploy

```bash
curl -s "$(gcloud run services describe sdoc-demo --region=asia-southeast1 \
  --format='value(status.url)')/api/health"     # {"status":"ok",...}
```

Open the URL → Overview / Pipeline / Browse; Browse → a MISMATCH story →
ResolvePanel → send → the mail lands in the sandbox inbox
(`SANDBOX_RECIPIENT`), never a bundle domain.

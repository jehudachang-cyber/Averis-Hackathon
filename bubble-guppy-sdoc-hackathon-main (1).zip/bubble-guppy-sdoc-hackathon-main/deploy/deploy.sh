#!/usr/bin/env bash
# One-shot Cloud Run deploy for the demo dashboard (issue 52).
#
# COST PROTOCOL: every check below runs BEFORE anything that can spend money.
# If any check fails, the script exits without creating, changing, or
# deploying anything. Cloud Run stays scale-to-zero (min-instances=0) and is
# capped (max-instances=1) so a runaway cannot rack up usage.
#
# Usage:
#   ./deploy/deploy.sh              # full deploy
#   PROJECT_ID=bubble-guppy REGION=asia-southeast1 ./deploy/deploy.sh
set -euo pipefail

PROJECT_ID="${PROJECT_ID:-bubble-guppy}"
REGION="${REGION:-asia-southeast1}"
SERVICE="sdoc-demo"
REPO="sdoc-demo"

step() { printf '\n=== %s ===\n' "$1"; }
die()  { printf 'ABORT (nothing was deployed): %s\n' "$1" >&2; exit 1; }

# --------------------------------------------------------------------------- #
# Preflight — read-only checks. Zero cost.
# --------------------------------------------------------------------------- #

step "1/7 gcloud auth + project"
command -v gcloud >/dev/null || die "gcloud not on PATH"
gcloud config get-value project 2>/dev/null | grep -qx "${PROJECT_ID}" || {
  gcloud config set project "${PROJECT_ID}"
}
gcloud auth list --filter=status:ACTIVE --format="value(account)" | grep -q . \
  || die "no active gcloud account — run: gcloud auth login"
SA="$(gcloud projects describe "${PROJECT_ID}" --format='value(projectNumber)')-compute@developer.gserviceaccount.com"
echo "build SA: ${SA}"

step "2/7 billing enabled (read-only)"
gcloud billing projects describe "${PROJECT_ID}" --format="value(billingEnabled)" \
  | grep -qx True || die "billing is not linked to ${PROJECT_ID}"

step "3/7 secrets exist (read-only)"
for SECRET in GEMINI_API_KEYS GMAIL_USER GMAIL_APP_PASSWORD SANDBOX_RECIPIENT; do
  gcloud secrets describe "${SECRET}" --project="${PROJECT_ID}" >/dev/null 2>&1 \
    || die "secret ${SECRET} missing — create it first (see deploy/README.md)"
done

step "4/7 Artifact Registry repo exists (read-only)"
gcloud artifacts repositories describe "${REPO}" \
  --project="${PROJECT_ID}" --location="${REGION}" >/dev/null 2>&1 \
  || die "Artifact Registry repo ${REPO} missing in ${REGION}"
echo "granting the build SA (compute) upload access to ${REPO}"
gcloud artifacts repositories add-iam-policy-binding "${REPO}" \
  --project="${PROJECT_ID}" --location="${REGION}" \
  --member="serviceAccount:${SA}" --role=roles/artifactregistry.writer \
  >/dev/null 2>&1 || echo "warn: AR writer grant failed (already bound?)"

step "5/7 Cloud Run service scale-to-zero (read-only)"
gcloud run services describe "${SERVICE}" --project="${PROJECT_ID}" \
  --region="${REGION}" --format="yaml(spec.template.metadata.annotations)" \
  2>/dev/null | grep -E "autoscaling.knative.dev/(maxScale|minScale)" || true
echo "granting the build SA (compute) Cloud Run deploy access"
gcloud projects add-iam-policy-binding "${PROJECT_ID}" \
  --member="serviceAccount:${SA}" --role=roles/run.admin \
  >/dev/null 2>&1 || echo "warn: run.admin grant failed (already bound?)"
gcloud projects add-iam-policy-binding "${PROJECT_ID}" \
  --member="serviceAccount:${SA}" --role=roles/iam.serviceAccountUser \
  >/dev/null 2>&1 || echo "warn: serviceAccountUser grant failed (already bound?)"

step "6/7 integrity guard — no ground truth in the build context"
if [ ! -f .gcloudignore ]; then
  die "missing .gcloudignore — the submit context would include sdoc-hackathon-docker/"
fi
if ! grep -q "sdoc-hackathon-docker" .gcloudignore; then
  die ".gcloudignore must exclude sdoc-hackathon-docker/ so the answer key is never uploaded"
fi
if find sdoc-hackathon-bundle sdoc-hackathon-bundle-multilingual src api ui \
    -name "ground_truth*" -type f 2>/dev/null | grep -q .; then
  die "ground-truth file found inside the shipped paths"
fi
if grep -Eiq "sdoc-hackathon-docker|data_v2" deploy/Dockerfile; then
  die "deploy/Dockerfile references the evaluation kit"
fi
echo "OK: .gcloudignore excludes the eval kit; no answer-key content in the image context"

step "7/7 sanity — env defaults that keep the sandbox on"
grep -q 'ALLOW_REAL_SEND=""' deploy/Dockerfile \
  || die "deploy/Dockerfile must keep ALLOW_REAL_SEND empty by default"
grep -q 'max-instances=1' deploy/cloudbuild.yaml \
  || die "deploy/cloudbuild.yaml must cap max-instances=1"

step "8/8 Cloud snapshot cache bucket (free infra, no billing)"
BUCKET="${SNAPSHOT_BUCKET:-sdoc-demo-cache}"
if ! gcloud storage buckets describe "gs://${BUCKET}" --project="${PROJECT_ID}" >/dev/null 2>&1; then
  echo "creating gs://${BUCKET} (${REGION}, standard)"
  gcloud storage buckets create "gs://${BUCKET}" --project="${PROJECT_ID}" \
    --location="${REGION}" --default-storage-class=standard
fi
gcloud storage buckets add-iam-policy-binding "gs://${BUCKET}" \
  --project="${PROJECT_ID}" \
  --member="serviceAccount:${SA}" --role=roles/storage.objectAdmin
if [ -f .demo-logs/bridge-snapshot.json ]; then
  gcloud storage cp .demo-logs/bridge-snapshot.json "gs://${BUCKET}/bridge-snapshot.json" \
    >/dev/null || echo "warn: local snapshot pre-upload failed (first boot will warm the cache)"
fi
echo "granting Cloud Run SA read access to the Cloud Build source bucket"
gcloud storage buckets add-iam-policy-binding "gs://${PROJECT_ID}_cloudbuild" \
  --project="${PROJECT_ID}" \
  --member="serviceAccount:${SA}" --role=roles/storage.objectViewer \
  >/dev/null 2>&1 || echo "warn: source-bucket grant skipped (bucket appears after the first submit)"
echo "OK: cache bucket ready + Cloud Run SA granted object access"
echo "note: with a stale fingerprint the first boot re-runs live once and uploads again"

# --------------------------------------------------------------------------- #
# Spend boundary — everything below uses Cloud Build + Cloud Run.
# --------------------------------------------------------------------------- #

step "Building + deploying via Cloud Build (this spends build minutes)"
gcloud builds submit --project="${PROJECT_ID}" --region="${REGION}" \
  --config deploy/cloudbuild.yaml .

step "Done — service URL"
gcloud run services describe "${SERVICE}" --project="${PROJECT_ID}" \
  --region="${REGION}" --format="value(status.url)"

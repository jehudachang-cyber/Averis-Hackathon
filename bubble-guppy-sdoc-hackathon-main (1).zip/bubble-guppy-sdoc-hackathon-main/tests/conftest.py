"""Shared pytest fixtures loading real emails from the working dataset.

Every later issue's tests should reuse these fixtures instead of hand-copying
email content. Fixtures load live files from ``sdoc-hackathon-bundle/`` (no
answer-key data): each :class:`EmailFixture` carries the raw JSON fields plus
decoded attachment text so parser tests can exercise real documents.

Selection rationale (document-driven, per issue 1):

- ``email_453``: SI + draft BL txt pair whose seven canonical fields match on
  both documents after header normalization (verified by reading both
  attachments) -- the happy-path ``email_bl_ok`` fixture.
- ``email_001``: SI + draft BL txt pair where the container count and notify
  party visibly differ between the two documents -- ``email_bl_mismatch``.
- ``email_004``: SI + draft BL txt pair where the notify party differs
  (consignee vs "To the order of") -- a second mismatch flavor, kept as a
  raw ``email_004`` fixture for parser tests.
- ``email_007``: SI-request email whose body carries the full instruction
  text -- ``email_si_request``.
- ``email_002``: invoice query about local charges -- ``email_invoice``.
- ``email_011``: operations update summary -- ``email_general``.
- ``email_015``: marketing/phishing mail -- ``email_spam``.
- ``email_003``: document-check request with no attachments at all and a
  body asking to *send* the draft BL -- ``email_no_attachment`` (ADR-0004
  rule 1a clears it to OK; the 506-510-style incident notes escalate).
- ``email_507``: comparison request where only the SI is attached (the body
  itself says the draft BL is still missing) -- ``email_si_only``.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

import pytest

BUNDLE_ROOT = Path(__file__).resolve().parent.parent / "sdoc-hackathon-bundle"


@dataclass(frozen=True)
class EmailFixture:
    """One inbox email plus decoded attachment text.

    Attributes:
        email_id: Inbox identifier, e.g. ``"email_453"``.
        subject: Raw subject line.
        body: Raw body text.
        attachments: Attachment paths exactly as listed in the email JSON.
        attachment_text: Attachment path -> decoded text (UTF-8 with errors
            replaced, mirroring how the parser stage will read bytes).
    """

    email_id: str
    subject: str
    body: str
    attachments: tuple[str, ...] = ()
    attachment_text: dict[str, str] = field(default_factory=dict)

    def attachment(self, index: int) -> str:
        """Decoded text of the i-th attachment.

        Example:
            >>> fixture = EmailFixture(
            ...     email_id="demo", subject="s", body="b",
            ...     attachments=("attachments/demo_SI.txt",),
            ...     attachment_text={"attachments/demo_SI.txt": "SHIPPING INSTRUCTION"},
            ... )
            >>> fixture.attachment(0)
            'SHIPPING INSTRUCTION'
        """
        path = self.attachments[index]
        return self.attachment_text[path]


def _load(email_id: str) -> EmailFixture:
    payload = json.loads(
        (BUNDLE_ROOT / "inbox" / f"{email_id}.json").read_text(encoding="utf-8")
    )
    texts: dict[str, str] = {}
    for rel_path in payload.get("attachments") or []:
        source = BUNDLE_ROOT / rel_path
        if source.exists():
            texts[rel_path] = source.read_text(encoding="utf-8", errors="replace")
    return EmailFixture(
        email_id=payload["email_id"],
        subject=payload.get("subject", ""),
        body=payload.get("body", ""),
        attachments=tuple(payload.get("attachments") or ()),
        attachment_text=texts,
    )


_IDS: dict[str, str] = {
    "email_bl_ok": "email_453",
    "email_bl_mismatch": "email_001",
    "email_si_request": "email_007",
    "email_invoice": "email_002",
    "email_general": "email_011",
    "email_spam": "email_015",
    "email_no_attachment": "email_003",
    "email_si_only": "email_507",
}


def _register_fixture(name: str, email_id: str) -> None:
    """Bind one parametrized-by-name fixture into this module's globals."""

    @pytest.fixture(name=name)
    def _fixture() -> EmailFixture:
        return _load(email_id)

    globals()[name] = _fixture


for _name, _email_id in _IDS.items():
    _register_fixture(_name, _email_id)


@pytest.fixture(name="email_004")
def email_004() -> EmailFixture:
    """Second mismatch-flavor pair (notify-party discrepancy)."""
    return _load("email_004")

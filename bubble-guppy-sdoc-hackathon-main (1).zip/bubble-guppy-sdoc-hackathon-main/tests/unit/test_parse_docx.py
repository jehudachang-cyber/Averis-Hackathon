"""Unit tests for the docx attachment parser (issue 15)."""

from __future__ import annotations

from io import BytesIO

from docx import Document

from sdoc_hackathon.parsers.docx import parse_docx, parse_docx_bytes


def _docx_bytes(build) -> bytes:  # type: ignore[no-untyped-def]
    """Build a docx via ``build(document)`` and return its bytes."""
    document = Document()
    build(document)
    buffer = BytesIO()
    document.save(buffer)
    return buffer.getvalue()


class TestParseDocxHappyPath:
    """Real-dataset shape: title + meta paragraphs, one label/value table."""

    def test_bl_draft_fixture_shape(self) -> None:
        def build(document) -> None:  # type: ignore[no-untyped-def]
            document.add_paragraph("BILL OF LADING (DRAFT)")
            document.add_paragraph("B/L NO.(提单号): SIN616928451")
            document.add_paragraph("ORDER NO.: 3658202970   FREIGHT PREPAID")
            table = document.add_table(rows=4, cols=2)
            table.rows[0].cells[0].text = "Shipper (Principal or Seller) (发货人)"
            table.rows[0].cells[
                1
            ].text = "APRIL FINE PAPER TRADING\n77 ROBINSON ROAD\nSINGAPORE 068896"
            table.rows[1].cells[0].text = "Consignee (收货人)"
            table.rows[1].cells[1].text = "AL GURG STATIONERY LLC"
            table.rows[2].cells[0].text = "PORT OF LOADING (装货港)"
            table.rows[2].cells[1].text = "SINGAPORE"
            table.rows[3].cells[0].text = "Gross Wt (kgs) (毛重 KGS)"
            table.rows[3].cells[1].text = "243,588"

        doc, conf = parse_docx_bytes(
            "attachments/email_055_BL.docx", _docx_bytes(build)
        )

        assert doc.fmt == "docx"
        assert doc.kind == "BL"
        assert doc.error is None
        assert conf.score == 0.9
        # Bilingual label kept verbatim (extract + synonym map normalize later).
        assert any(
            r.startswith("Shipper (Principal or Seller) (发货人): APRIL FINE PAPER")
            for r in doc.rows
        )
        # Title/meta paragraphs preserved as leading rows; table rows follow.
        assert doc.rows[0] == "BILL OF LADING (DRAFT)"
        assert doc.rows[3] == (
            "Shipper (Principal or Seller) (发货人): "
            "APRIL FINE PAPER TRADING; 77 ROBINSON ROAD; SINGAPORE 068896"
        )
        assert any("B/L NO.(提单号): SIN616928451" in r for r in doc.rows)

    def test_si_title_document(self) -> None:
        def build(document) -> None:  # type: ignore[no-untyped-def]
            document.add_paragraph("SHIPPING INSTRUCTION")
            table = document.add_table(rows=1, cols=2)
            table.rows[0].cells[0].text = "SHIPPER"
            table.rows[0].cells[1].text = "ACME LTD"

        doc, _ = parse_docx_bytes("attachments/x_SI.docx", _docx_bytes(build))

        assert doc.kind == "SI"

    def test_other_document_without_table(self) -> None:
        def build(document) -> None:  # type: ignore[no-untyped-def]
            document.add_paragraph("COMMERCIAL INVOICE")
            document.add_paragraph("Total: 12,000 USD")

        doc, conf = parse_docx_bytes("attachments/inv.docx", _docx_bytes(build))

        assert doc.kind == "OTHER"
        assert conf.score == 0.9
        assert doc.rows == ("COMMERCIAL INVOICE", "Total: 12,000 USD")


class TestParseDocxEdges:
    """Corrupt, empty, and missing files (issue 15 acceptance)."""

    def test_corrupt_bytes(self) -> None:
        doc, conf = parse_docx_bytes("attachments/bad.docx", b"this is not a zip")

        assert doc.kind == "UNREADABLE"
        assert doc.error is not None
        assert "cannot read docx" in doc.error
        assert conf.score == 0.1

    def test_empty_document(self) -> None:
        doc, conf = parse_docx_bytes(
            "attachments/empty.docx", _docx_bytes(lambda d: None)
        )

        assert doc.kind == "UNREADABLE"
        assert doc.error == "docx has no paragraph or table content"
        assert conf.score == 0.1

    def test_missing_file(self) -> None:
        doc, conf = parse_docx("attachments/does_not_exist.docx")

        assert doc.kind == "UNREADABLE"
        assert "cannot read file" in (doc.error or "")
        assert conf.score == 0.1

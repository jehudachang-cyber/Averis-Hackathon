"""Unit tests for the xlsx attachment parser (issue 14)."""

from __future__ import annotations

from io import BytesIO

from openpyxl import Workbook

from sdoc_hackathon.parsers.xlsx import parse_xlsx, parse_xlsx_bytes


def _workbook_bytes(cells: dict[str, str | float]) -> bytes:
    """Build a workbook from a ``cell -> value`` map and return xlsx bytes."""
    workbook = Workbook()
    sheet = workbook.active
    assert sheet is not None
    for address, value in cells.items():
        sheet[address] = value
    buffer = BytesIO()
    workbook.save(buffer)
    return buffer.getvalue()


class TestParseXlsxHappyPath:
    """Real-fixture documents: the dataset's 2-column label/value grid."""

    def test_fixture_si_pair(self, email_004) -> None:  # type: ignore[no-untyped-def]
        # email_004 carries xlsx attachments in the working dataset shape:
        # title row, "BL INSTRUCTION" banner, then label rows.
        workbook = Workbook()
        sheet = workbook.active
        assert sheet is not None
        sheet["A1"] = "ASIA PACIFIC PAPERBOARD TRADING PTE LTD"
        sheet["A2"] = "BL INSTRUCTION"
        sheet["B2"] = "3154303911"
        sheet["A3"] = "SHIPPER"
        sheet["B3"] = "APRIL FAR EAST (M) SDN BHD"
        sheet["A4"] = "No. of Containers or Packages"
        sheet["B4"] = "6 x 40'HC"
        sheet["A5"] = "GROSS WEIGHT"
        sheet["B5"] = 131058.0
        buffer = BytesIO()
        workbook.save(buffer)

        doc, conf = parse_xlsx_bytes("attachments/email_004_SI.xlsx", buffer.getvalue())

        assert doc.fmt == "xlsx"
        assert doc.kind == "SI"  # "BL INSTRUCTION" is an SI-side banner
        assert doc.error is None
        assert conf.score == 0.9
        assert "SHIPPER: APRIL FAR EAST (M) SDN BHD" in doc.rows
        assert "No. of Containers or Packages: 6 x 40'HC" in doc.rows
        # Float cell normalized: 131058.0 -> "131058"
        assert "GROSS WEIGHT: 131058" in doc.rows

    def test_kind_hint_from_bl_banner(self) -> None:
        data = _workbook_bytes(
            {
                "A1": "BILL OF LADING",
                "B1": "3154303911",
                "A2": "CONSIGNEE",
                "B2": "BALL & DOGGETT AUSTRALIA PTY LTD",
            }
        )

        doc, conf = parse_xlsx_bytes("attachments/email_005_BL.xlsx", data)

        assert doc.kind == "BL"
        assert conf.score == 0.9
        assert "CONSIGNEE: BALL & DOGGETT AUSTRALIA PTY LTD" in doc.rows

    def test_multi_column_row_joins_values(self) -> None:
        data = _workbook_bytes(
            {
                "A1": "NOTIFY PARTY",
                "B1": "NAGAPPELLA EXPORTS",
                "C1": "GST 33AACFN6792L1ZU",
            }
        )

        doc, _ = parse_xlsx_bytes("attachments/x.xlsx", data)

        assert doc.rows == ("NOTIFY PARTY: NAGAPPELLA EXPORTS | GST 33AACFN6792L1ZU",)

    def test_title_row_without_label_kept_verbatim(self) -> None:
        data = _workbook_bytes({"A1": "APRIL FINE PAPER TRADING"})

        doc, _ = parse_xlsx_bytes("attachments/x.xlsx", data)

        assert doc.rows == ("APRIL FINE PAPER TRADING",)

    def test_parse_xlsx_disk_path(self, tmp_path) -> None:  # type: ignore[no-untyped-def]
        workbook = Workbook()
        workbook.active["A1"] = "SHIPPER"  # type: ignore[index]
        workbook.active["B1"] = "ACME LTD"  # type: ignore[index]
        target = tmp_path / "doc.xlsx"
        workbook.save(target)

        doc, conf = parse_xlsx(target)

        assert doc.rows == ("SHIPPER: ACME LTD",)
        assert conf.score == 0.9


class TestParseXlsxEdges:
    """Corrupt, empty, and missing files (issue 14 acceptance)."""

    def test_corrupt_bytes(self) -> None:
        doc, conf = parse_xlsx_bytes("attachments/bad.xlsx", b"not an xlsx at all")

        assert doc.kind == "UNREADABLE"
        assert doc.error is not None
        assert "cannot read workbook" in doc.error
        assert conf.score == 0.1

    def test_empty_sheet(self) -> None:
        data = _workbook_bytes({})

        doc, conf = parse_xlsx_bytes("attachments/empty.xlsx", data)

        assert doc.kind == "UNREADABLE"
        assert doc.error == "workbook has no cell content"
        assert conf.score == 0.1

    def test_missing_file(self) -> None:  # type: ignore[no-untyped-def]
        doc, conf = parse_xlsx("attachments/does_not_exist.xlsx")

        assert doc.kind == "UNREADABLE"
        assert "cannot read file" in (doc.error or "")
        assert conf.score == 0.1

    def test_password_protected_reports_unreadable(self) -> None:
        # Password-protected xlsx raises the same workbook-load failure as
        # a corrupt file; both must land in the UNREADABLE contract.
        encrypted = b"PK\x03\x04" + bytes(range(256)) * 4
        doc, conf = parse_xlsx_bytes("attachments/locked.xlsx", encrypted)

        assert doc.kind == "UNREADABLE"
        assert conf.score == 0.1

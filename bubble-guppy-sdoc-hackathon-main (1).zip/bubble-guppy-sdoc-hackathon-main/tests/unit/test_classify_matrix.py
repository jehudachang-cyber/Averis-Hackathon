"""Full category x tier matrix for the consolidated rule table (issue 6).

Every category is exercised at each tier (subject / body / fallback) plus the
documented precedence conflicts. No inbox ids appear in this file.
"""

from __future__ import annotations

import pytest

from sdoc_hackathon.classify import (
    BODY_CONFIDENCE,
    FALLBACK_CONFIDENCE,
    RULES,
    SUBJECT_CONFIDENCE,
    decide,
)

CATEGORIES = {"BL_COMPARISON", "SI_REQUEST", "INVOICE_QUERY", "GENERAL", "SPAM"}

# (subject, body, expected category) covering all five categories on every tier.
MATRIX = [
    # --- subject tier -----------------------------------------------------
    ("TO CONFIRM DOCS _ 5AAA-00001 _ JEBEL ALI_UAE", "see attached", "BL_COMPARISON"),
    ("REQUEST SI _ 5AAA-00001 _ GDANSK_POLAND", "see attached", "SI_REQUEST"),
    ("RE_ LOCAL CHARGES FOB - KARGOSMAR - 5AAA-00001", "see attached", "INVOICE_QUERY"),
    ("15_01_2026 - UPDATE SUMMARY LE HAVRE V.QI540A", "see attached", "GENERAL"),
    ("Congratulations! You have WON a $1,000 Gift Card", "see attached", "SPAM"),
    # --- body tier --------------------------------------------------------
    (
        "5AAA-00001",
        "Attached are the SI and draft BL for your confirmation.",
        "BL_COMPARISON",
    ),
    ("5AAA-00001", "Please find Shipping instruction for 5AAA-00001.", "SI_REQUEST"),
    ("5AAA-00001", "Query on invoice 5250070001: is THC included?", "INVOICE_QUERY"),
    ("5AAA-00001", "From: a@b.c\nPlease follow the previous instruction.", "GENERAL"),
    ("5AAA-00001", "Click here to claim your $1,000 gift card now", "SPAM"),
    # --- fallback tier ----------------------------------------------------
    ("5AAA-00001", "FYI.", "GENERAL"),
    (None, "", "GENERAL"),
]


@pytest.mark.parametrize(("subject", "body", "expected"), MATRIX)
def test_category_matrix(subject: str | None, body: str, expected: str) -> None:
    category, confidence = decide(subject, body)
    assert category == expected
    assert confidence.reason


@pytest.mark.parametrize(("subject", "body", "expected"), MATRIX[:5])
def test_subject_tier_confidence_band(
    subject: str | None, body: str, expected: str
) -> None:
    assert decide(subject, body)[1].score == pytest.approx(SUBJECT_CONFIDENCE)


@pytest.mark.parametrize(("subject", "body", "expected"), MATRIX[5:10])
def test_body_tier_confidence_band(
    subject: str | None, body: str, expected: str
) -> None:
    assert decide(subject, body)[1].score == pytest.approx(BODY_CONFIDENCE)


@pytest.mark.parametrize(("subject", "body", "expected"), MATRIX[10:])
def test_fallback_tier_confidence_band(
    subject: str | None, body: str, expected: str
) -> None:
    assert decide(subject, body)[1].score == pytest.approx(FALLBACK_CONFIDENCE)


# ------------------------------------------------------ precedence conflicts ---
@pytest.mark.parametrize(
    ("subject", "body", "expected"),
    [
        # Subject beats body even when the body screams a different category.
        ("REQUEST SI _ 5AAA-00001", "Verify your account: http://x", "SI_REQUEST"),
        ("TO CONFIRM DOCS _ 5AAA-00001", "cancel invoice 5250070001", "BL_COMPARISON"),
        # Spam body signals beat weak/neutral subjects.
        ("Your parcel is on hold", "confirm payment: http://x", "SPAM"),
        # Comparison phrases beat loose draft-BL mentions.
        (
            "5AAA-00001",
            "Check the draft BL against the SI and revert with draft BL.",
            "BL_COMPARISON",
        ),
        # SI instruction text beats invoice phrasing in the same body.
        (
            "5AAA-00001",
            "Shipping instruction for 5AAA-00001. GR missing.",
            "SI_REQUEST",
        ),
    ],
)
def test_precedence_conflicts_are_deterministic(
    subject: str | None, body: str, expected: str
) -> None:
    assert decide(subject, body)[0] == expected
    # Idempotent/pure: identical inputs give identical outputs.
    assert decide(subject, body) == decide(subject, body)


# --------------------------------------------------------------- rule table ---
def test_rule_table_covers_all_categories() -> None:
    assert {rule.category for rule in RULES} == CATEGORIES


def test_rule_table_names_are_unique() -> None:
    names = [rule.name for rule in RULES]
    assert len(names) == len(set(names))


def test_subject_rules_come_before_body_rules() -> None:
    tiers = [rule.tier for rule in RULES]
    assert tiers == sorted(tiers, key={"subject": 0, "body": 1}.__getitem__)

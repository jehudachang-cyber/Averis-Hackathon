"""Unit tests for the rule-based classifier (issues 4/5/6)."""

from __future__ import annotations

from dataclasses import dataclass

import pytest

from conftest import EmailFixture
from sdoc_hackathon.classify import (
    BODY_CONFIDENCE,
    FALLBACK_CONFIDENCE,
    SUBJECT_CONFIDENCE,
    classify_email,
)
from sdoc_hackathon.models import Confidence


@dataclass
class SimpleEmail:
    """Test email satisfying the classifier protocol."""

    subject: str | None
    body: str


# ------------------------------------------------- fixture-driven coverage ---
@pytest.mark.parametrize(
    ("fixture_name", "expected", "expected_confidence"),
    [
        (
            "email_bl_mismatch",
            "BL_COMPARISON",
            SUBJECT_CONFIDENCE,
        ),  # "TO CONFIRM DOCS ..."
        # Coded-dept subject (no tier-1 pattern): correctly caught by the
        # "draft bl" body rule; the subject pattern itself lands in issue 5.
        ("email_bl_ok", "BL_COMPARISON", BODY_CONFIDENCE),
        ("email_si_request", "SI_REQUEST", SUBJECT_CONFIDENCE),
        ("email_invoice", "INVOICE_QUERY", SUBJECT_CONFIDENCE),
        ("email_general", "GENERAL", SUBJECT_CONFIDENCE),
        ("email_spam", "SPAM", SUBJECT_CONFIDENCE),
    ],
)
def test_classifies_bundle_fixtures(
    fixture_name: str,
    expected: str,
    expected_confidence: float,
    request: pytest.FixtureRequest,
) -> None:
    email: EmailFixture = request.getfixturevalue(fixture_name)
    category, confidence = classify_email(email)
    assert category == expected
    assert isinstance(confidence, Confidence)
    assert confidence.score == pytest.approx(expected_confidence)
    assert confidence.reason


# --------------------------------------------- subject vs body precedence ---
def test_subject_rule_beats_conflicting_body_rule() -> None:
    email = SimpleEmail(
        subject="REQUEST SI _ 5ABC-12345 _ TEST_PORT",
        body="Please verify your account within 24 hours.",
    )
    category, confidence = classify_email(email)
    assert category == "SI_REQUEST"
    assert confidence.score == pytest.approx(SUBJECT_CONFIDENCE)


def test_body_rule_used_when_subject_is_neutral() -> None:
    email = SimpleEmail(subject="5ABC-12345", body="Draft BL attached for checking.")
    category, confidence = classify_email(email)
    assert category == "BL_COMPARISON"
    assert confidence.score == pytest.approx(BODY_CONFIDENCE)


@pytest.mark.parametrize("subject", [None, "", "   "])
def test_missing_subject_falls_back_to_body_then_general(subject: str | None) -> None:
    neutral = SimpleEmail(subject=subject, body="FYI.")
    category, confidence = classify_email(neutral)
    assert category == "GENERAL"
    assert confidence.score == pytest.approx(FALLBACK_CONFIDENCE)

    spammy = SimpleEmail(subject=subject, body="Click here to claim your prize.")
    assert classify_email(spammy)[0] == "SPAM"


# ------------------------------------------- case / whitespace normalization ---
@pytest.mark.parametrize(
    "subject",
    [
        "to confirm docs _ 5RSG-00133",
        "TO CONFIRM DOCS _ 5RSG-00133",
        "To Confirm Docs   _  5RSG-00133",
        "RE_ TO CONFIRM DOCS _ 5RSG-00133",
    ],
)
def test_case_and_whitespace_normalization(subject: str) -> None:
    assert classify_email(SimpleEmail(subject, "body"))[0] == "BL_COMPARISON"


def test_confidence_reason_names_the_matched_rule() -> None:
    _, confidence = classify_email(SimpleEmail("REQUEST BL DRAFT _ PO 26067", "body"))
    assert "bl_confirm_docs" in confidence.reason


# --------------------------------------------- issue 5: body/edge categories ---
def test_si_request_via_body_only_mention() -> None:
    """Neutral subject + instruction text in the body -> SI_REQUEST (0.85)."""
    email = SimpleEmail(
        subject="5RFR-37631",
        body="Please find Shipping instruction for 5RFR-37631.\nPOL: SINGAPORE",
    )
    category, confidence = classify_email(email)
    assert category == "SI_REQUEST"
    assert confidence.score == pytest.approx(BODY_CONFIDENCE)


def test_coded_subject_bl_comparison_via_body_phrase() -> None:
    """Coded-dept subject whose body asks to check the draft BL."""
    email = SimpleEmail(
        subject="AFEMY - MOMBASA_KENYA - CMA(SIJ4216073) - 5RFR-36541",
        body="Please find attached the shipping instruction and the draft bill of "
        "lading for your confirmation. Kindly verify the BL matches the SI.",
    )
    category, confidence = classify_email(email)
    assert category == "BL_COMPARISON"
    assert "bl_compare_body" in confidence.reason


def test_loose_draft_bl_mention_in_si_request_yields_si_request() -> None:
    """SI-request body that merely mentions the draft BL stays SI_REQUEST."""
    email = SimpleEmail(
        subject="CUST SI _ MEA _ 5RCY-52735",
        body="Pls revert with draft BL once available.",
    )
    assert classify_email(email)[0] == "SI_REQUEST"


def test_named_bl_request_beats_quoted_thread_tail() -> None:
    """Coded subject + 'send the draft BL for checking' + quoted reply tail.

    Comparison-request emails commonly carry forwarded thread tails; the
    named document request must outrank the thread artifact.
    """
    email = SimpleEmail(
        subject="AFEMY - ASHDOD_ISRAEL - EVER(EGLV332003791769) - 5RAE-20163",
        body="Dear Najiha,\n\nPlease assist to send the draft BL for 070500236763 "
        "for checking asap.\n\nThank you.\n\nFrom: x <x@y>\n"
        "Please follow the previous instruction. Thank you.",
    )
    category, confidence = classify_email(email)
    assert category == "BL_COMPARISON"
    assert "bl_loose_body" in confidence.reason


def test_invoice_query_by_reference_in_body() -> None:
    email = SimpleEmail(
        subject="5AKR-61849",
        body="Query on invoice 5250075931: is the THC / local charge included?",
    )
    category, confidence = classify_email(email)
    assert category == "INVOICE_QUERY"
    assert confidence.score == pytest.approx(BODY_CONFIDENCE)


def test_general_forwarded_thread_tail() -> None:
    """A bare quoted thread tail resolves to GENERAL at body strength."""
    email = SimpleEmail(
        subject="RE_ 5RCY-36057",
        body="From: Someone <s@x.y>\nPlease follow the previous instruction. Thank you.",
    )
    category, confidence = classify_email(email)
    assert category == "GENERAL"
    assert confidence.score == pytest.approx(BODY_CONFIDENCE)


@pytest.mark.parametrize(
    ("subject", "body"),
    [
        (
            "Congratulations! You have WON a $1,000 Gift Card - CLAIM NOW",
            "Click here: http://bit.ly/claim-prize-now",
        ),
        (
            "Increase your shipping revenue with this ONE weird trick",
            "LIMITED TIME OFFER! Get 90% off the #1 logistics suite.",
        ),
        (
            "Your parcel is on hold",
            "Confirm payment within 24 hours: http://track-parcel.info",
        ),
    ],
)
def test_spam_marketing_and_link_only(subject: str, body: str) -> None:
    assert classify_email(SimpleEmail(subject, body))[0] == "SPAM"


@pytest.mark.parametrize(
    ("first", "second"),
    [
        # SPAM body signal inside an otherwise SI-looking email -> SPAM wins
        ("REQUEST SI _ 5ABC", "Verify your account within 24 hours: http://x"),
        # Invoice signal inside a comparison request -> still comparison (subject tier)
        ("TO CONFIRM DOCS _ 5ABC", "Kindly check the missing GR posting."),
    ],
)
def test_multi_signal_emails_resolve_deterministically(first: str, second: str) -> None:
    """Same input always yields the same category (documented precedence)."""
    email = SimpleEmail(first, second)
    assert classify_email(email) == classify_email(SimpleEmail(first, second))
    assert classify_email(email)[0] in {
        "SPAM",
        "BL_COMPARISON",
        "SI_REQUEST",
        "INVOICE_QUERY",
        "GENERAL",
    }

"""Tests for the unreadable-document gate (issue 11)."""

from __future__ import annotations

from pathlib import Path

import pytest

from sdoc_hackathon.models import Confidence, ParsedDocument
from sdoc_hackathon.parsers import (
    gate_parsed,
    mark_unreadable,
    parse_attachment,
)


def _doc(**overrides: object) -> ParsedDocument:
    """A healthy parsed document to mutate per-test."""
    base: dict[str, object] = {
        "path": "attachments/x.txt",
        "fmt": "txt",
        "kind": "SI",
        "text": "SHIPPING INSTRUCTION\nShipper: A\nConsignee: B\nPOL: C",
        "rows": ("Shipper: A", "Consignee: B", "POL: C"),
        "scanned": False,
        "error": None,
    }
    base.update(overrides)
    return ParsedDocument(**base)  # type: ignore[arg-type]


class TestMarkUnreadable:
    def test_short_text_demoted(self) -> None:
        doc, conf = mark_unreadable(_doc(text="hi", rows=()), Confidence(0.9, "parsed"))
        assert doc.kind == "UNREADABLE"
        assert doc.error == "insufficient_text_layer"
        assert conf.score == 0.1

    def test_too_few_field_rows_demoted(self) -> None:
        doc, conf = mark_unreadable(
            _doc(text="x" * 100, rows=("NOTICE", "PAGE 1")),
            Confidence(0.9, "parsed"),
        )
        assert doc.kind == "UNREADABLE"
        assert doc.error == "insufficient_field_rows"
        assert conf.score == 0.1

    def test_replacement_chars_do_not_count_as_text(self) -> None:
        """Garbage that decodes to U+FFFD padding must not pass the gate."""
        text = "\ufffd" * 50
        doc, _ = mark_unreadable(_doc(text=text, rows=()), Confidence(0.5, "?"))
        assert doc.kind == "UNREADABLE"
        assert doc.error == "insufficient_text_layer"

    def test_healthy_document_passes_through(self) -> None:
        parsed = _doc()
        conf = Confidence(0.95, "clean parse")
        doc, out_conf = mark_unreadable(parsed, conf)
        assert doc is parsed
        assert out_conf is conf

    def test_already_unreadable_passes_through(self) -> None:
        parsed = _doc(kind="UNREADABLE", error="cannot open pdf", text="", rows=())
        conf = Confidence(0.1, "corrupt")
        doc, out_conf = mark_unreadable(parsed, conf)
        assert doc is parsed
        assert out_conf is conf

    def test_custom_min_text_len(self) -> None:
        parsed = _doc(text="Shipper: A\nConsignee: B")
        doc, conf = mark_unreadable(parsed, Confidence(0.9, "p"), min_text_len=100)
        assert doc.kind == "UNREADABLE"
        assert conf.score == 0.1

    def test_gate_parsed_wrapper_matches_defaults(self) -> None:
        doc, conf = gate_parsed(_doc(text="x"), Confidence(0.9, "p"))
        assert doc.kind == "UNREADABLE"
        assert conf.score == 0.1


class TestParseAttachmentDispatch:
    def test_txt_happy_path_gated(self) -> None:
        raw = b"SHIPPING INSTRUCTION\n====\nShipper: A\nConsignee: B\nPOL: C"
        parsed, conf = parse_attachment("attachments/a_SI.txt", raw)
        assert parsed.fmt == "txt"
        assert parsed.kind == "SI"
        assert conf.score == 0.95

    def test_empty_txt_unreadable(self) -> None:
        parsed, conf = parse_attachment("attachments/empty.txt", b"")
        assert parsed.kind == "UNREADABLE"
        assert conf.score == 0.1

    def test_unknown_extension_unreadable(self) -> None:
        parsed, conf = parse_attachment("attachments/a.zip", b"PK\x03\x04")
        assert parsed.fmt == "unknown"
        assert parsed.kind == "UNREADABLE"
        assert parsed.error is not None
        assert conf.score == 0.1

    def test_scanned_pdf_flags_scanned(self) -> None:
        """A text-free PDF surfaces as scanned UNREADABLE without keys."""
        import pymupdf

        doc = pymupdf.open()
        doc.new_page()
        data = doc.tobytes()
        doc.close()
        parsed, conf = parse_attachment("attachments/a_BL.pdf", data)
        assert parsed.kind == "UNREADABLE"
        assert parsed.scanned is True
        assert conf.score == 0.25

    def test_corrupt_pdf_unreadable(self) -> None:
        parsed, conf = parse_attachment("attachments/a.pdf", b"%PDF-1.4 junk")
        assert parsed.kind == "UNREADABLE"
        assert parsed.scanned is False
        assert conf.score == 0.1


def test_bundle_scanned_pdf_end_to_end() -> None:
    """Issue-11 acceptance: real scanned PDF lands UNREADABLE after the gate."""
    path = Path("sdoc-hackathon-bundle/attachments/email_512_SI.pdf")
    if not path.exists():  # pragma: no cover - bundle missing in CI
        pytest.skip("bundle not present")
    parsed, conf = parse_attachment("attachments/email_512_SI.pdf", path.read_bytes())
    assert parsed.kind == "UNREADABLE"
    assert parsed.scanned is True
    assert conf.score == 0.25


def test_bundle_corrupt_pdf_end_to_end() -> None:
    """Real corrupt PDF (511_BL) lands UNREADABLE at 0.1 after the gate."""
    path = Path("sdoc-hackathon-bundle/attachments/email_511_BL.pdf")
    if not path.exists():  # pragma: no cover - bundle missing in CI
        pytest.skip("bundle not present")
    parsed, conf = parse_attachment("attachments/email_511_BL.pdf", path.read_bytes())
    assert parsed.kind == "UNREADABLE"
    assert conf.score == 0.1

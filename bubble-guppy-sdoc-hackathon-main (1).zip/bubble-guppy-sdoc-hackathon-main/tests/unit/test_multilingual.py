"""Tests for multilingual robustness (issue 46, ADR-0008).

The fixtures live in ``sdoc-hackathon-bundle-multilingual/``: ZH and BM
twins of two scored English threads, with values byte-identical to their
twins, so each thread's expected verdict transfers by construction. The
LLM seam is monkeypatched — the gate stays offline.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any
from unittest.mock import patch

import pytest

from sdoc_hackathon.classify import decide
from sdoc_hackathon.models import Confidence, ParsedDocument
from sdoc_hackathon.parsers import detect_document_language, parse_attachment
from sdoc_hackathon.parsers.lang import _distinct_bm_markers, _cjk_first_rows
from sdoc_hackathon.pipeline import BundleEmail, load_bundle_emails, run_pipeline

REPO = Path(__file__).resolve().parents[2]
MULTI_ROOT = REPO / "sdoc-hackathon-bundle-multilingual"
BUNDLE = REPO / "sdoc-hackathon-bundle"

pytestmark = pytest.mark.skipif(
    not MULTI_ROOT.is_dir(), reason="multilingual bundle not present"
)


def _attachment(name: str) -> str:
    """Text of one fixture attachment (either bundle)."""
    for root in (MULTI_ROOT, BUNDLE):
        path = root / "attachments" / name
        if path.is_file():
            return path.read_text(encoding="utf-8")
    raise AssertionError(f"unknown attachment: {name}")


#: fixture attachment -> English twin whose text stands in for the
#: translation (values are byte-identical by construction; see the bundle
#: README). This is the canned LLM response for the mocked-seam tests.
_TWINS: dict[str, str] = {
    "email_mzh_ok_SI": "email_453_SI",
    "email_mzh_ok_BL": "email_453_BL",
    "email_mbm_ok_SI": "email_453_SI",
    "email_mbm_ok_BL": "email_453_BL",
    "email_mzh_mismatch_SI": "email_004_SI",
    "email_mzh_mismatch_BL": "email_004_BL",
    "email_mbm_mismatch_SI": "email_004_SI",
    "email_mbm_mismatch_BL": "email_004_BL",
}


def _fake_translate(key: str, text: str, model: str) -> str:
    """Stand-in for the Gemini seam: return the twin's English text."""
    for src, twin in _TWINS.items():
        if text.strip() == _attachment(f"{src}.txt").strip():
            return _attachment(f"{twin}.txt")
    raise AssertionError("unexpected text reached the translator")


class TestLanguageRouter:
    def test_native_zh_labels(self) -> None:
        assert (
            detect_document_language(
                "运输指示\n发货人: ACME\n收货人: ORBIS\n装货港: BUATAN"
            )
            == "zh"
        )

    def test_annotation_level_bilingual_stays_english(self) -> None:
        # English-first labels with CJK glosses — the working bundle's only
        # ZH style — must keep the fully deterministic path.
        text = "SHIPPER: A\nCONSIGNEE (收货人): B\nGross Weight毛重(KGS): 1 KG"
        assert detect_document_language(text) == "en"

    def test_bm_markers(self) -> None:
        text = _attachment("email_mbm_ok_SI.txt")
        assert detect_document_language(text) == "bm"

    def test_english_document(self) -> None:
        assert detect_document_language(_attachment("email_453_SI.txt")) == "en"

    def test_bm_marker_threshold_is_two(self) -> None:
        assert _distinct_bm_markers("Dan went home.") < 2
        assert _distinct_bm_markers("Sila semak draf Bill of Lading") >= 2

    def test_cjk_first_row_counting(self) -> None:
        assert _cjk_first_rows("SHIPPER: A\n发货人: B") == 1
        assert _cjk_first_rows("发货人: A\n收货人: B") == 2


class TestMultilingualClassification:
    @pytest.mark.parametrize(
        ("body", "rule"),
        [
            ("请协助核对提单草稿与运输指示是否一致。", "bl_compare_body_zh"),
            ("随附 OC 1 的运输指示和提单草稿，请查收。", "bl_compare_body_zh"),
            (
                "Sila semak draf Bill of Lading berbanding Arahan Penghantaran.",
                "bl_compare_body_bm",
            ),
            (
                "Terlampir adalah Arahan Penghantaran dan draf Bill of Lading.",
                "bl_compare_body_bm",
            ),
            ("请尽快发送提单草稿。", "bl_loose_body_zh"),
            ("Draf Bill of Lading akan sedia esok.", "bl_loose_body_bm"),
        ],
    )
    def test_bl_comparison_in_zh_and_bm(self, body: str, rule: str) -> None:
        category, confidence = decide(None, body)
        assert category == "BL_COMPARISON"
        assert rule in confidence.reason

    def test_english_rules_unaffected(self) -> None:
        category, _ = decide(None, "Please check the draft BL against the SI.")
        assert category == "BL_COMPARISON"


class TestParseStageTranslation:
    def test_zh_document_translated_with_kind_hint(self) -> None:
        data = _attachment("email_mzh_ok_SI.txt").encode("utf-8")
        with patch("sdoc_hackathon.llm._generate_text", side_effect=_fake_translate):
            doc, conf = parse_attachment(
                "attachments/email_mzh_ok_SI.txt", data, ocr_keys=["k1"]
            )
        assert doc.translated is True
        assert doc.kind == "SI"
        assert "gemini label translation" in conf.reason
        assert doc.rows[0].startswith("Shipper/Exporter:")
        assert "APRIL FAR EAST (M) SDN BHD" in doc.rows[0]  # value preserved

    def test_english_document_never_routes(self) -> None:
        data = _attachment("email_453_SI.txt").encode("utf-8")
        with patch(
            "sdoc_hackathon.llm._generate_text",
            side_effect=AssertionError("must not be called for English docs"),
        ):
            doc, conf = parse_attachment(
                "attachments/email_453_SI.txt", data, ocr_keys=["k1"]
            )
        assert doc.translated is False
        assert doc.kind == "SI"
        assert conf.score == 0.95

    def test_no_keys_leaves_document_untranslated(self) -> None:
        data = _attachment("email_mzh_ok_SI.txt").encode("utf-8")
        doc, _ = parse_attachment("attachments/email_mzh_ok_SI.txt", data)
        assert doc.translated is False
        assert doc.kind == "OTHER"  # ZH title cannot be kind-hinted

    def test_all_keys_failing_demotes_not_guesses(self) -> None:
        data = _attachment("email_mbm_ok_SI.txt").encode("utf-8")
        with patch(
            "sdoc_hackathon.llm._generate_text", side_effect=RuntimeError("quota")
        ):
            doc, conf = parse_attachment(
                "attachments/email_mbm_ok_SI.txt", data, ocr_keys=["k1"]
            )
        assert doc.kind == "UNREADABLE"
        assert "label translation service unavailable" in (doc.error or "")
        assert "escalated for manual review" in conf.reason
        assert conf.score == 0.1


class TestTwinOracle:
    """Each multilingual thread must produce its English twin's verdict."""

    @pytest.mark.parametrize(
        ("email_id", "expected_status", "expected_defects"),
        [
            ("email_mzh_ok", "OK", ()),
            ("email_mbm_ok", "OK", ()),
            ("email_mzh_mismatch", "MISMATCH", ("consignee", "notify_party")),
            ("email_mbm_mismatch", "MISMATCH", ("consignee", "notify_party")),
        ],
    )
    def test_verdict_matches_english_twin(
        self,
        email_id: str,
        expected_status: str,
        expected_defects: tuple[str, ...],
    ) -> None:
        payload: dict[str, Any] = json.loads(
            (MULTI_ROOT / "inbox" / f"{email_id}.json").read_text(encoding="utf-8")
        )
        with patch("sdoc_hackathon.llm._generate_text", side_effect=_fake_translate):
            records, traces = run_pipeline(
                [(email_id, BundleEmail(payload))],
                data_root=MULTI_ROOT,
                ocr_keys=["k1"],
            )
        record = records[0]
        assert record.category == "BL_COMPARISON"
        assert record.status == expected_status  # type: ignore[comparison-overlap]
        assert tuple(record.defect_fields) == expected_defects
        assert record.decided_by == "llm"
        # the audit trail records the translation stage decision
        parse_events = [e for e in traces[0].events if e.stage == "parse"]
        assert all(event.decision != "UNREADABLE" for event in parse_events)

    def test_without_keys_escalates_never_guesses(self) -> None:
        records, _ = run_pipeline(
            load_bundle_emails(MULTI_ROOT), data_root=MULTI_ROOT, ocr_keys=None
        )
        assert all(record.status == "NEEDS_REVIEW" for record in records)
        assert all(
            record.review_reason in ("wrong_doc_type", "unreadable")
            for record in records
        )
        assert all(record.decided_by == "rules" for record in records)


class TestEnglishRegressionGate:
    def test_no_bundle_email_routes_to_translation(self) -> None:
        """Every attachment in the scored bundle keeps the deterministic path."""
        for path in sorted(BUNDLE.joinpath("attachments").glob("*.txt")):
            text = path.read_text(encoding="utf-8", errors="replace")
            assert detect_document_language(text) == "en", path.name

    def test_translated_marker_is_additive(self) -> None:
        doc = ParsedDocument(path="a.txt")
        assert doc.translated is False and doc.scanned is False

    def test_confidence_llm_band_for_translation(self) -> None:
        confidence = Confidence(0.85, "gemini label translation (zh -> en)")
        assert confidence.score == 0.85

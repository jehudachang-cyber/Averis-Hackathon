"""Tests for the label synonym map (issue 12).

The map is tested against surface forms derived from the generator's label
pool spec (``data_v2/pools.py``) and the attachment vocabulary — never
against the answer key.
"""

from __future__ import annotations

import pytest

from sdoc_hackathon.extract import SYNONYM_MAP, field_for_label, normalize_label
from sdoc_hackathon.models import FIELDS


class TestNormalizeLabel:
    @pytest.mark.parametrize(
        ("raw", "expected"),
        [
            ("Shipper", "SHIPPER"),
            ("  SHIPPER ", "SHIPPER"),
            ("Shipper:", "SHIPPER"),
            ("Shipper：", "SHIPPER"),  # full-width colon
            (
                "Notify Party/Intermediate Consignee (通知人)",
                "NOTIFY PARTY/INTERMEDIATE CONSIGNEE",
            ),
            ("Consignee (收货人)", "CONSIGNEE"),
            ("Gross Weight毛重(KGS)", "GROSS WEIGHT"),
            ("Port of Loading (POL)", "PORT OF LOADING"),
            ("No. of Containers", "NO. OF CONTAINERS"),
            ("Shipper (Principal or Seller) (发货人) ", "SHIPPER"),
            ("Gross Wt (kgs) (毛重 KGS)", "GROSS WT"),
            ("Consignee (Non-Negotiable)", "CONSIGNEE"),
        ],
    )
    def test_cases(self, raw: str, expected: str) -> None:
        assert normalize_label(raw) == expected

    def test_empty_and_colon_only(self) -> None:
        assert normalize_label("") == ""
        assert normalize_label("  : ") == ""


class TestSynonymMap:
    def test_all_seven_fields_covered(self) -> None:
        mapped = set(SYNONYM_MAP.values())
        assert mapped == set(FIELDS)

    def test_spec_pool_surface_forms(self) -> None:
        """Every surface form in the generator's LABELS pool maps correctly."""
        spec_labels = {
            "shipper": [
                "Shipper",
                "Shipper/Exporter",
                "Shipper (Principal or Seller)",
                "SHIPPER",
            ],
            "consignee": [
                "Consignee",
                "Consignee (Non-Negotiable)",
                "CONSIGNEE",
                "To the Order of",
            ],
            "notify_party": [
                "Notify Party",
                "Notify",
                "Notify Party/Intermediate Consignee",
                "NOTIFY PARTY",
            ],
            "port_of_loading": [
                "Port of Loading",
                "Port of Loading (POL)",
                "Load Port",
                "POL",
                "PORT OF LOADING",
            ],
            "port_of_discharge": [
                "Port of Discharge",
                "Port of Discharge (POD)",
                "Discharge Port",
                "POD",
                "PORT OF DISCHARGE",
            ],
            "container_count": [
                "No. of Containers",
                "Number of Containers",
                "Total Containers",
                "Total Number of Containers",
                "Total Container",
                "No. of Containers or Packages",
                "Container Count",
                "Container Quantity",
            ],
            "gross_weight_kg": [
                "Gross Weight (KG)",
                "Gross Wt (kgs)",
                "Gross Weight毛重(KGS)",
                "GROSS WEIGHT",
            ],
        }
        for field, labels in spec_labels.items():
            for label in labels:
                assert field_for_label(label) == field, label

    @pytest.mark.parametrize(
        ("raw", "field"),
        [
            ("Shipper (发货人)", "shipper"),
            ("Shipper/Exporter (发货人)", "shipper"),
            ("CONSIGNEE (收货人)", "consignee"),
            ("Consignee (Non-Negotiable) (收货人)", "consignee"),
            ("To the Order of (收货人)", "consignee"),
            ("Notify (通知人)", "notify_party"),
            ("NOTIFY PARTY (通知人)", "notify_party"),
            ("POL (装货港)", "port_of_loading"),
            ("Load Port (装货港)", "port_of_loading"),
            ("PORT OF LOADING (装货港)", "port_of_loading"),
            ("POD (卸货港)", "port_of_discharge"),
            ("Discharge Port (卸货港)", "port_of_discharge"),
            ("No. of Containers (箱数)", "container_count"),
            ("Total Containers (箱数)", "container_count"),
            ("Container Count (箱数)", "container_count"),
            ("Number of Containers (箱数)", "container_count"),
            ("Total Number of Containers (箱数)", "container_count"),
            ("Total Container (箱数)", "container_count"),
            ("Container Quantity (箱数)", "container_count"),
            ("GROSS WEIGHT (毛重 KGS)", "gross_weight_kg"),
            ("Gross Weight毛重(KGS) (毛重 KGS)", "gross_weight_kg"),
            ("Gross Wt (kgs) (毛重 KGS)", "gross_weight_kg"),
            ("TOTAL GROSS WEIGHT", "gross_weight_kg"),
            ("TOTAL Gross Weight (KG)", "gross_weight_kg"),
            ("TOTAL Gross Wt (kgs)", "gross_weight_kg"),
            ("TOTAL Gross WeightII(KGS)", "gross_weight_kg"),
        ],
    )
    def test_dataset_annotation_variants(self, raw: str, field: str) -> None:
        assert field_for_label(raw) == field

    @pytest.mark.parametrize(
        "raw",
        [
            "B/L NUMBER",
            "B/L No.",
            "Bill of Lading No.",
            "Booking Ref",
            "Booking Reference",
            "Ocean Vessel",
            "Vessel Name",
            "Voy. No",
            "Freight",
            "HS Code",
            "Description of Goods",
            "Commodity",
            "NEW NO",
            "P.O. BOX",
            "TEL",
            "BL INSTRUCTION",
        ],
    )
    def test_unmapped_labels_return_none(self, raw: str) -> None:
        assert field_for_label(raw) is None

    def test_no_email_ids_anywhere(self) -> None:
        """Issue 12 integrity: no email ids in the map or its keys."""
        for key in SYNONYM_MAP:
            assert "email" not in key.lower()

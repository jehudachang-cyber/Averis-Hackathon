"""Tests for field extraction (issue 20)."""

from __future__ import annotations

import pytest

from sdoc_hackathon.extract import assign_roles, extract_fields
from sdoc_hackathon.models import FIELDS, ParsedDocument


def _doc(rows: tuple[str, ...], kind: str = "SI", fmt: str = "txt") -> ParsedDocument:
    """Build a ParsedDocument whose text mirrors ``rows`` line-for-line."""
    return ParsedDocument(
        path="attachments/x.txt",
        fmt=fmt,  # type: ignore[arg-type]
        kind=kind,  # type: ignore[arg-type]
        text="\n".join(rows),
        rows=rows,
    )


class TestColonRows:
    def test_txt_style_all_fields(self) -> None:
        doc = _doc(
            (
                "SHIPPER: APRIL FINE PAPER TRADING",
                "CONSIGNEE: UAB NOVAKOPA",
                "NOTIFY PARTY: UAB NOVAKOPA",
                "PORT OF LOADING: BUATAN, INDONESIA",
                "Discharge Port: BUSAN, SOUTH KOREA",
                "No. of Containers: 6 x 40'HC",
                "Gross Weight毛重(KGS): 70,572 KG",
            )
        )
        fields = extract_fields(doc)
        assert fields.shipper == "APRIL FINE PAPER TRADING"
        assert fields.consignee == "UAB NOVAKOPA"
        assert fields.notify_party == "UAB NOVAKOPA"
        assert fields.port_of_loading == "BUATAN, INDONESIA"
        assert fields.port_of_discharge == "BUSAN, SOUTH KOREA"
        assert fields.container_count == "6 x 40'HC"
        assert fields.gross_weight_kg == "70,572 KG"
        assert fields.missing() == []

    def test_blank_label_values_stay_blank(self) -> None:
        """Blank values (email_519/520 pattern) drive missing_value later."""
        doc = _doc(
            (
                "SHIPPER:",
                "CONSIGNEE: UAB NOVAKOPA",
                "No. of Containers:",
            )
        )
        fields = extract_fields(doc)
        assert fields.shipper == ""
        assert fields.container_count == ""
        assert fields.consignee == "UAB NOVAKOPA"
        assert "shipper" in fields.missing()

    def test_first_occurrence_wins(self) -> None:
        doc = _doc(
            (
                "Shipper: FIRST",
                "Shipper/Exporter: SECOND",
            )
        )
        assert extract_fields(doc).shipper == "FIRST"

    def test_unmapped_labels_ignored(self) -> None:
        doc = _doc(
            (
                "Booking Ref: MCLSINJEA2508070",
                "HS CODE: 48025700",
                "Shipper: ACME",
            )
        )
        fields = extract_fields(doc)
        assert fields.shipper == "ACME"
        assert not any("MCLSINJEA" in value for value in fields.as_dict().values())

    @pytest.mark.parametrize(
        ("field", "raw"),
        [
            ("gross_weight_kg", "Gross Weight (KG): N/A"),
            ("port_of_discharge", "Port of Discharge: TBA"),
            ("port_of_loading", "POL: ???"),
            ("container_count", "No. of Containers: TBD"),
            ("notify_party", "NOTIFY PARTY: ____"),
        ],
    )
    def test_placeholders_blank_not_values(self, field: str, raw: str) -> None:
        """Placeholder markers are not data -> blank -> missing_value later."""
        doc = _doc((raw, "Shipper: ACME"))
        fields = extract_fields(doc)
        assert getattr(fields, field) == ""
        assert field in fields.missing()


class TestBareLabelBlocks:
    def test_pdf_bare_labels_and_glued_line(self) -> None:
        """Real pdf layout: bare labels, glued consignee, table headers."""
        doc = _doc(
            (
                "BILL OF LADING (DRAFT)",
                "B/L NUMBER: OOLU3584143842",
                "Shipper",
                "APRIL FINE PAPER TRADING",
                "ON BEHALF OF VITAL SOLUTIONS PTE LTD",
                "Consignee (Non-Negotiable) BALL & DOGGETT AUSTRALIA PTY LTD",
                "43-45 METROPOLITAN ROAD",
                "NOTIFY PARTY",
                "PACIFIC OFFICE (M) SDN BHD",
                "Load Port",
                "BUATAN, INDONESIA",
                "Port of Discharge",
                "FREMANTLE, AUSTRALIA",
                "Export Carrier (vessel, voyage)SOLID 16 V.044NW2",
                "CONTAINER NO.",
                "DESCRIPTION",
                "GROSS WEIGHT (KG)",
                "PURJ4736471",
                "40'HC UNCOATED WOODFREE PAPER IN REA",
                "21,887",
                "Container Count: 6 x 40'HC",
                "TOTAL Gross Weight (KG): 131,322 KG",
            ),
            kind="BL",
            fmt="pdf",
        )
        fields = extract_fields(doc)
        assert fields.shipper == (
            "APRIL FINE PAPER TRADING; ON BEHALF OF VITAL SOLUTIONS PTE LTD"
        )
        assert fields.consignee == (
            "BALL & DOGGETT AUSTRALIA PTY LTD; 43-45 METROPOLITAN ROAD"
        )
        assert fields.notify_party == "PACIFIC OFFICE (M) SDN BHD"
        assert fields.port_of_loading == "BUATAN, INDONESIA"
        assert fields.port_of_discharge == "FREMANTLE, AUSTRALIA"
        assert fields.container_count == "6 x 40'HC"
        # per-container weight rows must NOT leak into the total
        assert fields.gross_weight_kg == "131,322 KG"

    def test_bare_pol_pod_abbreviations(self) -> None:
        doc = _doc(
            (
                "POL",
                "BUATAN, INDONESIA",
                "POD",
                "FREMANTLE, AUSTRALIA",
            ),
            fmt="pdf",
        )
        fields = extract_fields(doc)
        assert fields.port_of_loading == "BUATAN, INDONESIA"
        assert fields.port_of_discharge == "FREMANTLE, AUSTRALIA"

    def test_bare_gross_weight_header_ignored(self) -> None:
        """The bare GROSS WEIGHT table header must not swallow table rows."""
        doc = _doc(
            (
                "Shipper: ACME",
                "Consignee: ORBIS",
                "NOTIFY PARTY: PACIFIC",
                "Load Port: BUATAN",
                "Port of Discharge: FREMANTLE",
                "No. of Containers: 2 x 40'HC",
                "CONTAINER NO.",
                "DESCRIPTION",
                "GROSS WEIGHT (KG)",
                "PURJ4736471",
                "21,887",
                "WBFO6773592",
                "21,887",
            ),
            fmt="pdf",
        )
        fields = extract_fields(doc)
        assert fields.gross_weight_kg == ""

    def test_block_ends_at_colon_row(self) -> None:
        doc = _doc(
            (
                "Shipper",
                "ACME LTD",
                "No. of Containers: 3 x 40'HC",
                "UNRELATED TAIL",
            ),
            fmt="pdf",
        )
        fields = extract_fields(doc)
        assert fields.shipper == "ACME LTD"
        assert fields.container_count == "3 x 40'HC"


class TestAssignRoles:
    def test_si_bl_pair(self) -> None:
        si = _doc(("Shipper: A",), kind="SI")
        bl = _doc(("Shipper: A",), kind="BL")
        assert assign_roles([si, bl]) is si
        assert assign_roles([bl, si]) is si

    def test_two_si_is_ambiguous(self) -> None:
        a = _doc(("Shipper: A",), kind="SI")
        b = _doc(("Shipper: B",), kind="SI")
        assert assign_roles([a, b]) is None

    def test_wrong_counts_return_none(self) -> None:
        one = _doc(("Shipper: A",), kind="SI")
        three = [one, one, one]
        assert assign_roles([one]) is None
        assert assign_roles(three) is None

    def test_unreadable_pair_cannot_assign(self) -> None:
        a = _doc((), kind="UNREADABLE")
        b = _doc((), kind="OTHER")
        assert assign_roles([a, b]) is None


class TestUnreadablePassthrough:
    def test_unreadable_document_all_blank(self) -> None:
        doc = ParsedDocument(
            path="attachments/s.pdf",
            fmt="pdf",
            kind="UNREADABLE",
            text="",
            rows=(),
            scanned=True,
            error="no text layer",
        )
        fields = extract_fields(doc)
        assert fields.missing() == list(FIELDS)


def test_bundle_missing_value_documents() -> None:
    """Real bundle: 519/520 carry deliberately blank fields."""
    from pathlib import Path

    from sdoc_hackathon.parsers import parse_attachment

    root = Path("sdoc-hackathon-bundle/attachments")
    if not root.exists():  # pragma: no cover
        pytest.skip("bundle not present")

    si_519, _ = parse_attachment(
        "attachments/email_519_SI.txt", (root / "email_519_SI.txt").read_bytes()
    )
    fields = extract_fields(si_519)
    assert fields.shipper == ""
    assert fields.container_count == ""
    assert fields.consignee == "UAB NOVAKOPA"

    si_520, _ = parse_attachment(
        "attachments/email_520_SI.txt", (root / "email_520_SI.txt").read_bytes()
    )
    assert extract_fields(si_520).consignee == ""


def test_bundle_pdf_pair_full_extraction() -> None:
    """Real bundle: the 059 pdf pair extracts all seven fields on both sides."""
    from pathlib import Path

    from sdoc_hackathon.parsers import parse_attachment

    root = Path("sdoc-hackathon-bundle/attachments")
    if not root.exists():  # pragma: no cover
        pytest.skip("bundle not present")
    for name in ("email_059_SI.pdf", "email_059_BL.pdf"):
        doc, _ = parse_attachment(name, (root / name).read_bytes())
        fields = extract_fields(doc)
        assert fields.missing() == [], name
        assert fields.gross_weight_kg == "131,322 KG"
        assert fields.container_count == "6 x 40'HC"


@pytest.mark.parametrize(
    ("email_id", "att", "field"),
    [
        ("email_516", "email_516_SI.txt", "gross_weight_kg"),
        ("email_517", "email_517_SI.txt", "port_of_discharge"),
        ("email_518", "email_518_SI.txt", "port_of_discharge"),
    ],
)
def test_bundle_placeholder_documents(email_id: str, att: str, field: str) -> None:
    """Real bundle: N/A-TBA placeholder docs extract blank, not junk."""
    from pathlib import Path

    from sdoc_hackathon.parsers import parse_attachment

    root = Path("sdoc-hackathon-bundle/attachments")
    if not root.exists():  # pragma: no cover
        pytest.skip("bundle not present")
    doc, _ = parse_attachment(f"attachments/{att}", (root / att).read_bytes())
    fields = extract_fields(doc)
    assert getattr(fields, field) == "", email_id

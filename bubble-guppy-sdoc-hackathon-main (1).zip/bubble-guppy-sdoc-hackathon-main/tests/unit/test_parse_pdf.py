"""Tests for the PDF parser (issue 10): native, scanned, and corrupt paths."""

from __future__ import annotations

import pymupdf
import pytest

from sdoc_hackathon.models import Confidence, ParsedDocument
from sdoc_hackathon.parsers.pdf import (
    MIN_NATIVE_CHARS,
    _content_rows,
    parse_pdf,
    parse_pdf_bytes,
)


def make_pdf(lines: list[str], *, with_text: bool = True) -> bytes:
    """Build an in-memory one-page PDF containing ``lines`` of text."""
    doc = pymupdf.open()
    page = doc.new_page()
    if with_text:
        y = 72.0
        for line in lines:
            page.insert_text((72.0, y), line)
            y += 20.0
    data = doc.tobytes()
    doc.close()
    return data


class TestNativePdf:
    def test_native_parse_basic_contract(self) -> None:
        data = make_pdf(
            [
                "SHIPPING INSTRUCTION",
                "====",
                "Shipper: APRIL FINE PAPER TRADING",
                "Gross Weight (KG): 21,887",
            ]
        )
        parsed, conf = parse_pdf_bytes("attachments/a_SI.pdf", data)
        assert isinstance(parsed, ParsedDocument)
        assert isinstance(conf, Confidence)
        assert parsed.fmt == "pdf"
        assert parsed.kind == "SI"
        assert parsed.scanned is False
        assert parsed.error is None
        # title and rule line excluded, content kept verbatim
        assert parsed.rows == (
            "Shipper: APRIL FINE PAPER TRADING",
            "Gross Weight (KG): 21,887",
        )
        assert conf.score == 0.9

    def test_bl_draft_title_maps_to_bl(self) -> None:
        data = make_pdf(
            ["BILL OF LADING (DRAFT)", "Shipper: X", "Consignee: Y", "POL: Z"]
        )
        parsed, _ = parse_pdf_bytes("attachments/a_BL.pdf", data)
        assert parsed.kind == "BL"

    def test_bl_instruction_title_maps_to_si(self) -> None:
        """'BILL OF LADING INSTRUCTION' is the SI side (substring trap)."""
        data = make_pdf(
            ["BILL OF LADING INSTRUCTION", "Shipper: X", "Consignee: Y", "POL: Z"]
        )
        parsed, _ = parse_pdf_bytes("attachments/a_SI.pdf", data)
        assert parsed.kind == "SI"

    def test_unknown_title_maps_to_other(self) -> None:
        data = make_pdf(
            ["COMMERCIAL INVOICE", "Invoice No: 123", "Date: 2026-09-19", "Total: 5"]
        )
        parsed, _ = parse_pdf_bytes("attachments/inv.pdf", data)
        assert parsed.kind == "OTHER"


class TestScannedPdf:
    def test_no_text_layer_unreadable_without_keys(self) -> None:
        data = make_pdf([], with_text=False)
        parsed, conf = parse_pdf_bytes("attachments/a_BL.pdf", data)
        assert parsed.scanned is True
        assert parsed.kind == "UNREADABLE"
        assert parsed.rows == ()
        assert parsed.error is not None
        assert conf.score == 0.25

    def test_no_text_layer_delegates_to_ocr_with_keys(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        data = make_pdf([], with_text=False)
        ocr_doc = ParsedDocument(path="attachments/a_BL.pdf", fmt="pdf")
        calls: list[tuple[str, bytes, list[str]]] = []

        def fake_ocr(path: str, payload: bytes, keys: list[str]):
            calls.append((path, payload, keys))
            return ocr_doc, Confidence(0.85, "gemini OCR transcription")

        monkeypatch.setattr("sdoc_hackathon.llm.ocr_pdf_pages_bytes", fake_ocr)
        parsed, conf = parse_pdf_bytes("attachments/a_BL.pdf", data, ocr_keys=["k1"])
        assert parsed == ocr_doc
        assert conf.score == 0.85
        assert calls and calls[0][0] == "attachments/a_BL.pdf"
        assert calls[0][2] == ["k1"]

    def test_ocr_transcription_gets_kind_from_title(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """OCR output kind=OTHER is refined from the transcription title."""
        data = make_pdf([], with_text=False)
        ocr_doc = ParsedDocument(
            path="attachments/a_SI.pdf",
            fmt="pdf",
            kind="OTHER",
            text="SHIPPING INSTRUCTION\nShipper: ACME\nConsignee: ORBIS\nPOL: BUATAN",
            rows=("SHIPPING INSTRUCTION", "Shipper: ACME"),
            scanned=True,
        )

        def fake_ocr(path: str, payload: bytes, keys: list[str]):
            return ocr_doc, Confidence(0.85, "gemini OCR transcription")

        monkeypatch.setattr("sdoc_hackathon.llm.ocr_pdf_pages_bytes", fake_ocr)
        parsed, _ = parse_pdf_bytes("attachments/a_SI.pdf", data, ocr_keys=["k1"])
        assert parsed.kind == "SI"
        assert parsed.scanned is True

    def test_ocr_transcription_bl_instruction_trap(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """BILL OF LADING INSTRUCTION in a transcription is the SI side."""
        data = make_pdf([], with_text=False)
        ocr_doc = ParsedDocument(
            path="attachments/a_SI.pdf",
            fmt="pdf",
            kind="OTHER",
            text=(
                "BILL OF LADING INSTRUCTION\nShipper: ACME\n"
                "Consignee: ORBIS\nNotify: PACIFIC\nPOL: BUATAN"
            ),
            scanned=True,
        )

        def fake_ocr(path: str, payload: bytes, keys: list[str]):
            return ocr_doc, Confidence(0.85, "gemini OCR transcription")

        monkeypatch.setattr("sdoc_hackathon.llm.ocr_pdf_pages_bytes", fake_ocr)
        parsed, _ = parse_pdf_bytes("attachments/a_SI.pdf", data, ocr_keys=["k1"])
        assert parsed.kind == "SI"

    def test_ocr_failure_stays_unreadable(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """UNREADABLE OCR results are passed through untouched."""
        data = make_pdf([], with_text=False)
        failed = ParsedDocument(
            path="attachments/a_BL.pdf",
            fmt="pdf",
            kind="UNREADABLE",
            scanned=True,
            error="all keys failed",
        )

        def fake_ocr(path: str, payload: bytes, keys: list[str]):
            return failed, Confidence(0.1, "all keys failed")

        monkeypatch.setattr("sdoc_hackathon.llm.ocr_pdf_pages_bytes", fake_ocr)
        parsed, conf = parse_pdf_bytes("attachments/a_BL.pdf", data, ocr_keys=["k1"])
        assert parsed.kind == "UNREADABLE"
        assert parsed.error == "all keys failed"
        assert conf.score == 0.1

    def test_min_native_chars_threshold(self) -> None:
        """A text layer below the threshold counts as scanned."""
        data = make_pdf(["hi"])
        assert len("hi") < MIN_NATIVE_CHARS
        parsed, _ = parse_pdf_bytes("attachments/a.pdf", data)
        assert parsed.scanned is True


class TestCorruptPdf:
    def test_corrupt_bytes_unreadable(self) -> None:
        parsed, conf = parse_pdf_bytes("attachments/a.pdf", b"%PDF-1.4 not really")
        assert parsed.kind == "UNREADABLE"
        assert parsed.scanned is False
        assert parsed.error is not None
        assert conf.score == 0.1

    def test_missing_file_unreadable(self, tmp_path) -> None:
        parsed, conf = parse_pdf(tmp_path / "nope.pdf")
        assert parsed.kind == "UNREADABLE"
        assert conf.score == 0.1


class TestContentRows:
    def test_rule_lines_and_title_dropped(self) -> None:
        rows = _content_rows(
            ["BILL OF LADING (DRAFT)", "====", "Shipper: A", "----", "Consignee: B"]
        )
        assert rows == ("Shipper: A", "Consignee: B")

    def test_title_only_skipped_before_first_content(self) -> None:
        rows = _content_rows(["SOME TITLE", "NOT A RULE BUT CONTENT"])
        assert rows == ("NOT A RULE BUT CONTENT",)


@pytest.mark.parametrize(
    ("name", "expect_fmt"),
    [
        ("email_059_SI.pdf", "pdf"),
        ("email_059_BL.pdf", "pdf"),
    ],
)
def test_bundle_native_pdfs(name: str, expect_fmt: str) -> None:
    """Smoke: real bundle native PDFs parse with a kind hint."""
    from pathlib import Path

    path = Path("sdoc-hackathon-bundle/attachments") / name
    if not path.exists():  # pragma: no cover - bundle missing in CI
        pytest.skip("bundle not present")
    parsed, conf = parse_pdf(path)
    assert parsed.fmt == expect_fmt
    assert parsed.kind in ("SI", "BL")
    assert parsed.rows
    assert conf.score == 0.9


def test_bundle_scanned_and_corrupt_pdfs() -> None:
    """Smoke: the known scanned (512-514) and corrupt (511/515 BL) PDFs."""
    from pathlib import Path

    root = Path("sdoc-hackathon-bundle/attachments")
    if not root.exists():  # pragma: no cover - bundle missing in CI
        pytest.skip("bundle not present")
    scanned = {"email_512_SI.pdf", "email_512_BL.pdf", "email_513_SI.pdf"}
    corrupt = {"email_511_BL.pdf", "email_515_BL.pdf"}
    for name in scanned | corrupt:
        parsed, conf = parse_pdf(root / name)
        assert parsed.kind == "UNREADABLE", name
        if name in scanned:
            assert parsed.scanned is True
            assert conf.score == 0.25
        else:
            assert parsed.scanned is False
            assert conf.score == 0.1

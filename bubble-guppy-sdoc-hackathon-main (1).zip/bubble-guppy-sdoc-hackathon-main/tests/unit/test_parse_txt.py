"""Unit tests for the txt attachment parser (issue 13)."""

from __future__ import annotations

import pytest

from sdoc_hackathon.models import ParsedDocument
from sdoc_hackathon.parsers import read_attachment_text
from sdoc_hackathon.parsers.txt import detect_kind, parse_txt


class TestDetectKind:
    """Header -> kind hint mapping."""

    @pytest.mark.parametrize(
        ("header", "expected"),
        [
            ("SHIPPING INSTRUCTION", "SI"),
            ("Shipping Instruction", "SI"),
            ("BILL OF LADING (DRAFT)", "BL"),
            ("Bill of Lading", "BL"),
            ("COMMERCIAL INVOICE", "OTHER"),
            ("PAPERBOARD MANIFEST", "OTHER"),
            ("", "OTHER"),
        ],
    )
    def test_known_headers(self, header: str, expected: str) -> None:
        assert detect_kind(header) == expected

    def test_bl_instruction_is_not_bl(self) -> None:
        # "BL INSTRUCTION" is an SI-side header (seen on xlsx SI docs);
        # it must NOT be detected as a Bill of Lading.
        assert detect_kind("BL INSTRUCTION") == "OTHER"

    def test_instruction_without_shipping_is_other(self) -> None:
        assert detect_kind("INSTRUCTION") == "OTHER"


class TestParseTxtHappyPath:
    """Real-shape documents: header, rule line, wrapped label lines."""

    def test_fixture_si_document(self, email_bl_ok):  # type: ignore[no-untyped-def]
        fixture = email_bl_ok
        si_path = next(p for p in fixture.attachments if p.endswith("_SI.txt"))
        text = fixture.attachment_text[si_path]

        doc, conf = parse_txt(si_path, text)

        assert isinstance(doc, ParsedDocument)
        assert doc.fmt == "txt"
        assert doc.kind == "SI"
        assert doc.scanned is False
        assert doc.error is None
        assert conf.score == 0.95
        # Continuation lines folded: address continues the Shipper row.
        shipper_rows = [r for r in doc.rows if r.upper().startswith("SHIPPER")]
        assert len(shipper_rows) == 1
        assert "APRIL FAR EAST" in shipper_rows[0]
        assert "KUALA LUMPUR" in shipper_rows[0]

    def test_fixture_bl_document(self, email_bl_ok):  # type: ignore[no-untyped-def]
        fixture = email_bl_ok
        bl_path = next(p for p in fixture.attachments if p.endswith("_BL.txt"))
        doc, conf = parse_txt(bl_path, fixture.attachment_text[bl_path])

        assert doc.kind == "BL"
        assert conf.score == 0.95
        assert any(r.upper().startswith("CONSIGNEE") for r in doc.rows)

    def test_rows_preserve_label_value_shape(self, email_004):  # type: ignore[no-untyped-def]
        fixture = email_004
        si_path = next(p for p in fixture.attachments if p.endswith("_SI.txt"))
        doc, _ = parse_txt(si_path, fixture.attachment_text[si_path])

        for row in doc.rows:
            assert ": " in row, f"row lost Label: value shape: {row!r}"


class TestParseTxtEdges:
    """Empty, garbled, and binary inputs (issue 13 acceptance)."""

    def test_empty_text(self) -> None:
        doc, conf = parse_txt("attachments/empty_SI.txt", "")
        assert doc.kind == "UNREADABLE"
        assert doc.rows == ()
        assert doc.error is not None
        assert conf.score == 0.1

    def test_whitespace_only_text(self) -> None:
        doc, conf = parse_txt("attachments/ws.txt", " \n\t\n  \n")
        assert doc.kind == "UNREADABLE"
        assert conf.score == 0.1

    def test_non_utf8_garbage(self) -> None:
        raw = bytes(range(0, 32)) * 8  # control chars: garbled after replace
        text = read_attachment_text(raw)
        doc, conf = parse_txt("attachments/junk.txt", text)
        assert doc.kind == "UNREADABLE"
        assert conf.score == 0.1

    def test_clean_text_with_few_replacement_chars_passes(self) -> None:
        # A legitimate document may contain one stray non-ASCII char; that
        # must not trip the garble detector.
        text = "SHIPPING INSTRUCTION\nShipper: Caf\u00e9 Ltd\nPort: B\n"
        doc, conf = parse_txt("attachments/ok.txt", text)
        assert doc.kind == "SI"
        assert conf.score == 0.95

"""Tests for SI-vs-BL comparison and value normalization (issue 21)."""

from __future__ import annotations

import pytest

from sdoc_hackathon.compare import compare_fields, normalize_value, values_match
from sdoc_hackathon.models import ExtractedFields


class TestNormalizeText:
    @pytest.mark.parametrize(
        ("raw", "expected"),
        [
            (
                "Al Gurg Stationery LLC | P.O. BOX 5069; Dubai",
                "AL GURG STATIONERY LLC; P.O. BOX 5069; DUBAI",
            ),
            ("APRIL  FINE   PAPER", "APRIL FINE PAPER"),
            (
                "ROXCEL TRADING GMBH; OPERNRING 3-5",
                "ROXCEL TRADING GMBH; OPERNRING 3-5",
            ),
            ("A | B | C", "A; B; C"),
            (
                "NAGAPPA EXPORTS | NEW NO : 23, L-BLOCK",
                "NAGAPPA EXPORTS; NEW NO : 23, L-BLOCK",
            ),
        ],
    )
    def test_text_rules(self, raw: str, expected: str) -> None:
        assert normalize_value("shipper", raw) == expected

    def test_parentheticals_kept(self) -> None:
        """Same-code/different-city port trap must survive normalization."""
        a = normalize_value("port_of_discharge", "MOMBASA, KENYA (KEMBA)")
        b = normalize_value("port_of_discharge", "TUTICORIN, INDIA (KEMBA)")
        assert a != b


class TestNormalizeWeight:
    @pytest.mark.parametrize(
        ("raw", "expected"),
        [
            ("131,058 KG", "131058"),
            ("131058", "131058"),
            ("243,588", "243588"),
            ("70,572 KG", "70572"),
            ("  41,124  kgs ", "41124"),
        ],
    )
    def test_weight_rules(self, raw: str, expected: str) -> None:
        assert normalize_value("gross_weight_kg", raw) == expected


class TestNormalizeCount:
    @pytest.mark.parametrize(
        ("raw", "expected"),
        [
            ("6 x 40'HC", "6X40HC"),
            ("2 X 20'GP", "2X20GP"),
            ("12", "12"),
            ("1,234", "1234"),
        ],
    )
    def test_count_rules(self, raw: str, expected: str) -> None:
        assert normalize_value("container_count", raw) == expected


class TestValuesMatch:
    def test_weight_formatting_only(self) -> None:
        assert values_match("gross_weight_kg", "243588", "243,588")

    def test_separator_variants(self) -> None:
        assert values_match(
            "notify_party",
            "AL GURG STATIONERY LLC | P.O. BOX 5069; DUBAI",
            "AL GURG STATIONERY LLC; P.O. BOX 5069; DUBAI",
        )

    def test_bare_locode_matches_full_port(self) -> None:
        assert values_match(
            "port_of_loading", "MYPKG", "PORT KLANG (WESTPORT), MALAYSIA (MYPKG)"
        )

    def test_same_code_different_city_is_mismatch(self) -> None:
        assert not values_match(
            "port_of_discharge", "MOMBASA, KENYA (KEMBA)", "TUTICORIN, INDIA (KEMBA)"
        )

    def test_container_count_changed(self) -> None:
        assert not values_match("container_count", "6 x 20'GP", "5 x 20'GP")

    def test_weight_digit_edit(self) -> None:
        assert not values_match("gross_weight_kg", "21,114 KG", "23,114 KG")

    def test_blank_side_is_not_mismatch(self) -> None:
        assert values_match("shipper", "", "ACME")
        assert values_match("shipper", "ACME", "")
        assert values_match("shipper", "", "")


class TestCompareFields:
    def test_all_match(self) -> None:
        si = ExtractedFields(
            shipper="ACME",
            consignee="ORBIS",
            notify_party="PACIFIC",
            port_of_loading="BUATAN, INDONESIA",
            port_of_discharge="FREMANTLE, AUSTRALIA",
            container_count="6 x 40'HC",
            gross_weight_kg="131,322 KG",
        )
        bl = ExtractedFields(
            shipper="acme",
            consignee="ORBIS",
            notify_party="PACIFIC",
            port_of_loading="BUATAN, INDONESIA",
            port_of_discharge="FREMANTLE, AUSTRALIA",
            container_count="6 x 40'HC",
            gross_weight_kg="131322",
        )
        result = compare_fields(si, bl)
        assert result.defect_fields() == []
        assert not result.has_defect()
        assert result.values["gross_weight_kg"] == ("131,322 KG", "131322")

    def test_mismatch_fields_listed_in_canonical_order(self) -> None:
        si = ExtractedFields(
            consignee="EAST BRIGHT FZ-LLC",
            container_count="6 x 20'GP",
            gross_weight_kg="21,114 KG",
        )
        bl = ExtractedFields(
            consignee="UAB NOVAKOPA",
            container_count="5 x 20'GP",
            gross_weight_kg="23,114 KG",
        )
        result = compare_fields(si, bl)
        assert result.defect_fields() == [
            "consignee",
            "container_count",
            "gross_weight_kg",
        ]
        assert result.has_defect()


def test_bundle_pair_counts() -> None:
    """Dataset-level invariant: formatting-only diffs must not become defects."""
    import json
    from pathlib import Path

    from sdoc_hackathon.extract import assign_roles, extract_fields
    from sdoc_hackathon.parsers import parse_attachment

    root = Path("sdoc-hackathon-bundle")
    if not root.exists():  # pragma: no cover
        pytest.skip("bundle not present")

    mismatch_fields = 0
    for em in sorted((root / "inbox").glob("email_*.json")):
        data = json.loads(em.read_text())
        atts = data.get("attachments", [])
        if len(atts) != 2:
            continue
        docs = []
        for att in atts:
            p = root / att
            try:
                doc, _ = parse_attachment(att, p.read_bytes())
            except Exception:
                continue
            docs.append(doc)
        si = assign_roles(docs)
        if si is None:
            continue
        bl = next(d for d in docs if d is not si)
        result = compare_fields(extract_fields(si), extract_fields(bl))
        mismatch_fields += len(result.defect_fields())

    # measured across the bundle: 95 genuine defect fields (26 formatting-
    # only diffs absorbed by normalization; the 3 N/A-TBA placeholder
    # fields now escalate missing_value instead of counting as defects)
    assert mismatch_fields == 95

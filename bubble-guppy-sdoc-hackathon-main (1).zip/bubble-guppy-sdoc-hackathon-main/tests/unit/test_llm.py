"""Unit tests for the Gemini OCR module (issue 23) — fully offline."""

from __future__ import annotations

import pytest

from sdoc_hackathon import llm
from sdoc_hackathon.llm import (
    DEFAULT_GEMINI_MODEL,
    DEFAULT_GEMINI_MODELS,
    load_api_keys,
    load_api_keys_from_env,
    ocr_pdf_pages_bytes,
    ocr_single_document,
    resolve_models,
)


class TestLoadApiKeys:
    """GEMINI_API_KEYS parsing (comma-separated, no spaces)."""

    def test_single_key(self) -> None:
        assert load_api_keys("AIzaSingle") == ["AIzaSingle"]

    def test_multiple_keys_with_spaces(self) -> None:
        assert load_api_keys("k1, k2 ,  k3") == ["k1", "k2", "k3"]

    def test_empty_string(self) -> None:
        assert load_api_keys("") == []

    def test_whitespace_only(self) -> None:
        assert load_api_keys("   ") == []

    def test_trailing_comma(self) -> None:
        assert load_api_keys("k1,") == ["k1"]

    def test_env_loader_reads_environ(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("GEMINI_API_KEYS", "envkey1, envkey2")
        assert load_api_keys_from_env("/nonexistent/.env") == ["envkey1", "envkey2"]

    def test_env_loader_missing_variable(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("GEMINI_API_KEYS", raising=False)
        assert load_api_keys_from_env("/nonexistent/.env") == []


class TestOcrRotation:
    """Key + model rotation over the _generate seam (no network)."""

    def test_first_key_success(self, monkeypatch: pytest.MonkeyPatch) -> None:
        calls: list[str] = []

        def fake_generate(key: str, pdf_bytes: bytes, model: str) -> str:
            calls.append(key)
            return "BILL OF LADING (DRAFT)\nShipper: ACME"

        monkeypatch.setattr(llm, "_generate", fake_generate)

        doc, conf = ocr_pdf_pages_bytes("attachments/s.pdf", b"%PDF", ["k1", "k2"])

        assert calls == ["k1"]  # first key wins; no rotation needed
        assert doc.kind == "OTHER"
        assert doc.scanned is True
        assert doc.fmt == "pdf"
        assert "Shipper: ACME" in doc.rows
        assert conf.score == 0.85

    def test_rotation_skips_failing_key(self, monkeypatch: pytest.MonkeyPatch) -> None:
        calls: list[str] = []

        def fake_generate(key: str, pdf_bytes: bytes, model: str) -> str:
            calls.append(key)
            if key == "dead":
                raise ConnectionError("quota exhausted")
            return "SHIPPING INSTRUCTION\nConsignee: X"

        monkeypatch.setattr(llm, "_generate", fake_generate)
        monkeypatch.setenv("GEMINI_MODELS", "gemini-3.1-flash-lite")

        doc, conf = ocr_pdf_pages_bytes("attachments/s.pdf", b"%PDF", ["dead", "alive"])

        assert calls == ["dead", "alive"]
        assert conf.score == 0.85

    def test_rotation_skips_rate_limited_model(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        calls: list[tuple[str, str]] = []

        def fake_generate(key: str, pdf_bytes: bytes, model: str) -> str:
            calls.append((key, model))
            if model == "gemini-3.8-flash":
                raise ConnectionError("429 rate limit")
            return "SHIPPING INSTRUCTION\nConsignee: X"

        monkeypatch.setattr(llm, "_generate", fake_generate)
        monkeypatch.setenv("GEMINI_MODELS", "gemini-3.8-flash, gemini-3.1-flash-lite")

        doc, conf = ocr_pdf_pages_bytes("attachments/s.pdf", b"%PDF", ["k1"])

        assert calls == [("k1", "gemini-3.8-flash"), ("k1", "gemini-3.1-flash-lite")]
        assert conf.score == 0.85
        assert "Consignee: X" in doc.rows

    def test_all_keys_fail_maps_to_unreadable(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        def fake_generate(key: str, pdf_bytes: bytes, model: str) -> str:
            raise ConnectionError("boom")

        monkeypatch.setattr(llm, "_generate", fake_generate)

        doc, conf = ocr_pdf_pages_bytes("attachments/s.pdf", b"%PDF", ["k1", "k2"])

        assert doc.kind == "UNREADABLE"
        assert doc.scanned is True
        assert doc.error is not None
        # technical detail stays on the audit surface...
        assert "all GEMINI models+keys failed" in doc.error
        assert "k1" in doc.error and "k2" in doc.error  # masked keys present
        # ...while the audience-facing reason reads professionally
        assert (
            conf.reason
            == "transcription service unavailable — escalated for manual review"
        )
        assert conf.score == 0.1

    def test_no_keys_configured(self) -> None:
        doc, conf = ocr_pdf_pages_bytes("attachments/s.pdf", b"%PDF", [])

        assert doc.kind == "UNREADABLE"
        assert "no GEMINI_API_KEYS" in (doc.error or "")
        assert conf.score == 0.1

    def test_empty_transcription_is_unreadable(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(llm, "_generate", lambda key, data, model: "   \n  ")

        doc, conf = ocr_pdf_pages_bytes("attachments/s.pdf", b"%PDF", ["k1"])

        assert doc.kind == "UNREADABLE"
        assert doc.error == "OCR returned empty transcription"
        assert conf.score == 0.1

    def test_rows_drop_blank_lines(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setattr(
            llm, "_generate", lambda key, data, model: "Title\n\n  \nField: value\n"
        )

        doc, _ = ocr_pdf_pages_bytes("attachments/s.pdf", b"%PDF", ["k1"])

        assert doc.rows == ("Title", "Field: value")

    def test_outcome_decided_by_llm(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path
    ) -> None:  # type: ignore[no-untyped-def]
        monkeypatch.setattr(llm, "_generate", lambda key, data, model: "text")
        pdf_file = tmp_path / "s.pdf"
        pdf_file.write_bytes(b"%PDF-1.4 scanned page")

        outcome = ocr_single_document(pdf_file, ["k1"])

        assert outcome.decided_by == "llm"
        assert outcome.confidence.score == 0.85
        assert outcome.document.scanned is True


class TestModelConfig:
    """Model rotation choice documented in ADR-0006."""

    def test_default_model_rotation(self) -> None:
        # Default fallback order; the first model is the preferred default.
        # gemini-2.5-flash 404s for new keys (2026-09) so it stays as a
        # low-priority fallback only. env overrides: GEMINI_MODELS (whole
        # list) or GEMINI_MODEL (single pin).
        assert DEFAULT_GEMINI_MODELS == [
            "gemini-3.8-flash",
            "gemini-2.5-flash",
            "gemini-3.5-flash-lite",
            "gemini-3.1-flash-lite",
        ]
        assert DEFAULT_GEMINI_MODEL == DEFAULT_GEMINI_MODELS[0]

    def test_default_used_without_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("GEMINI_MODEL", raising=False)
        monkeypatch.delenv("GEMINI_MODELS", raising=False)
        assert resolve_models() == DEFAULT_GEMINI_MODELS

    def test_gemini_models_env_overrides_list(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("GEMINI_MODELS", "gemini-x, gemini-y")
        assert resolve_models() == ["gemini-x", "gemini-y"]

    def test_gemini_model_env_pins_single(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("GEMINI_MODEL", "gemini-pinned")
        monkeypatch.delenv("GEMINI_MODELS", raising=False)
        assert resolve_models() == ["gemini-pinned"]

    def test_gemini_models_env_wins_over_gemini_model(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("GEMINI_MODEL", "gemini-pinned")
        monkeypatch.setenv("GEMINI_MODELS", "gemini-a, gemini-b")
        assert resolve_models() == ["gemini-a", "gemini-b"]

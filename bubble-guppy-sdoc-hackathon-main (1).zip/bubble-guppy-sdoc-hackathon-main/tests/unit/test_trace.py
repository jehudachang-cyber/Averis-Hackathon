"""Tests for the trace provenance touch (issue 47).

Covers:

- ``StepEvent.payload``: optional, defaults to ``None``, round-trips.
- ``extract_fields_anchored``: per-field row anchors for txt colon rows,
  pdf bare-label blocks (label row + continuation range), the pdf
  container-table trap (per-container rows never anchored), placeholders,
  and delegation equality with ``extract_fields``.
- Pipeline provenance events: ``extract`` (per parsed document, with
  anchors) and ``compare`` (per-field SI/BL values + match flags) present
  exactly on BL_COMPARISON traces, in stage order before ``review``.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import cast

from sdoc_hackathon.classify import Email
from sdoc_hackathon.extract import extract_fields, extract_fields_anchored
from sdoc_hackathon.models import FIELDS, ParsedDocument
from sdoc_hackathon.pipeline import BundleEmail, run_pipeline
from sdoc_hackathon.trace import StepEvent, Trace


def _payload_dict(event: StepEvent) -> dict[str, object]:
    """Narrow ``event.payload`` (typed ``dict[str, object] | None``)."""
    assert event.payload is not None
    return event.payload


# ------------------------------------------------------- StepEvent.payload ---
def test_step_event_payload_defaults_to_none() -> None:
    event = StepEvent(stage="review", decision="OK")
    assert event.payload is None


def test_step_event_payload_round_trips() -> None:
    payload: dict[str, object] = {"fields": {"shipper": {"rows": [2], "present": True}}}
    event = StepEvent(stage="extract", decision="EXTRACTED", payload=payload)
    assert event.payload == payload


# ---------------------------------------------- extract_fields_anchored -----
def _doc(rows: tuple[str, ...], kind: str = "SI", fmt: str = "txt") -> ParsedDocument:
    return ParsedDocument(
        path="attachments/x.txt",
        fmt=fmt,  # type: ignore[arg-type]
        kind=kind,  # type: ignore[arg-type]
        text="\n".join(rows),
        rows=rows,
    )


class TestAnchoredColonRows:
    def test_anchors_point_at_their_own_rows(self) -> None:
        doc = _doc(
            (
                "SHIPPER: APRIL FINE PAPER TRADING",
                "CONSIGNEE: UAB NOVAKOPA",
                "Port of Discharge: BUSAN, SOUTH KOREA",
            )
        )
        fields, anchors = extract_fields_anchored(doc)
        assert fields.shipper == "APRIL FINE PAPER TRADING"
        assert anchors["shipper"] == [0]
        assert anchors["consignee"] == [1]
        assert anchors["port_of_discharge"] == [2]

    def test_all_field_keys_present_even_when_absent(self) -> None:
        doc = _doc(("Shipper: ACME",))
        _fields, anchors = extract_fields_anchored(doc)
        assert sorted(anchors) == sorted(FIELDS)
        assert anchors["gross_weight_kg"] == []
        assert anchors["notify_party"] == []

    def test_unmapped_and_header_rows_never_anchored(self) -> None:
        doc = _doc(
            (
                "Booking Ref: MCLSINJEA2508070",
                "Shipper: ACME",
            )
        )
        _fields, anchors = extract_fields_anchored(doc)
        assert anchors["shipper"] == [1]
        # no anchor anywhere points at the booking-ref row
        assert all(0 not in rows for rows in anchors.values())


class TestAnchoredBareLabelBlocks:
    def test_pdf_block_anchors_label_and_continuation_range(self) -> None:
        doc = _doc(
            (
                "B/L NUMBER: OOLU3584143842",
                "Shipper",
                "APRIL FINE PAPER TRADING",
                "ON BEHALF OF VITAL SOLUTIONS PTE LTD",
                "Consignee (Non-Negotiable) BALL & DOGGETT AUSTRALIA PTY LTD",
                "43-45 METROPOLITAN ROAD",
                "NOTIFY PARTY",
                "PACIFIC OFFICE (M) SDN BHD",
            ),
            kind="BL",
            fmt="pdf",
        )
        _fields, anchors = extract_fields_anchored(doc)
        # bare-label block: label row + every consumed continuation row
        assert anchors["shipper"] == [1, 2, 3]
        # glued line: single row carries label and value
        assert anchors["consignee"] == [4, 5]
        assert anchors["notify_party"] == [6, 7]
        assert anchors["port_of_loading"] == []

    def test_container_table_trap_never_anchored(self) -> None:
        """Per-container weight rows and the bare header get no anchor."""
        doc = _doc(
            (
                "Shipper: ACME",
                "CONTAINER NO.",
                "DESCRIPTION",
                "GROSS WEIGHT (KG)",
                "PURJ4736471",
                "21,887",
                "TOTAL Gross Weight (KG): 131,322 KG",
            ),
            fmt="pdf",
        )
        fields, anchors = extract_fields_anchored(doc)
        assert fields.gross_weight_kg == "131,322 KG"
        # only the TOTAL summary colon row (index 6) is the provenance
        assert anchors["gross_weight_kg"] == [6]
        for header_index in (1, 2, 3, 4, 5):
            assert all(header_index not in rows for rows in anchors.values()), (
                header_index
            )

    def test_placeholder_value_blank_and_still_anchored(self) -> None:
        """The row produced the (blanked) value — it stays the provenance."""
        doc = _doc(("Gross Weight (KG): N/A", "Shipper: ACME"))
        fields, anchors = extract_fields_anchored(doc)
        assert fields.gross_weight_kg == ""
        assert anchors["gross_weight_kg"] == [0]


def test_extract_fields_delegates_to_anchored() -> None:
    doc = _doc(("Shipper: ACME", "Load Port: BUATAN"))
    fields = extract_fields(doc)
    anchored_fields, _anchors = extract_fields_anchored(doc)
    assert fields == anchored_fields


def test_anchored_extraction_matches_real_bundle_pdf() -> None:
    """Real pdf pair (email_059): anchors land inside document rows."""
    from pathlib import Path

    from sdoc_hackathon.parsers import parse_attachment

    root = Path("sdoc-hackathon-bundle/attachments")
    if not root.exists():  # pragma: no cover
        return
    doc, _ = parse_attachment(
        "attachments/email_059_SI.pdf", (root / "email_059_SI.pdf").read_bytes()
    )
    fields, anchors = extract_fields_anchored(doc)
    assert fields.missing() == []
    for name in FIELDS:
        rows = anchors[name]
        assert rows, name
        assert all(0 <= index < len(doc.rows) for index in rows)


# -------------------------------------------------- pipeline provenance -----
def _pipeline_traces(emails: list[tuple[str, Email]]) -> dict[str, object]:
    _records, traces = run_pipeline(emails)
    return {trace.email_id: trace for trace in traces}


def test_comparison_trace_has_extract_and_compare_events() -> None:
    """Real bundle pair (email_001): full provenance chain, in stage order."""
    root = Path("sdoc-hackathon-bundle")
    if not (root / "inbox").exists():  # pragma: no cover
        return

    data = json.loads((root / "inbox" / "email_001.json").read_text(encoding="utf-8"))
    _records, traces = run_pipeline(
        [(data["email_id"], BundleEmail(data))], data_root=root
    )
    trace: Trace = traces[0]
    assert [event.stage for event in trace.events] == [
        "classify",
        "parse",
        "parse",
        "extract",
        "compare",
        "review",
    ]

    extract_event = trace.stage("extract")
    assert extract_event is not None
    documents = _payload_dict(extract_event)["documents"]
    assert isinstance(documents, list) and len(documents) == 2
    doc_payloads = cast("list[dict[str, object]]", documents)
    si_payload = next(
        cast("dict[str, object]", doc) for doc in doc_payloads if doc["kind"] == "SI"
    )
    si_fields = cast("dict[str, object]", si_payload["fields"])
    shipper_anchor = cast("dict[str, object]", si_fields["shipper"])
    assert shipper_anchor["rows"]
    assert shipper_anchor["present"] is True

    compare_event = trace.stage("compare")
    assert compare_event is not None
    fields_payload = _payload_dict(compare_event)["fields"]
    fields_map = cast("dict[str, object]", fields_payload)
    assert set(fields_map) == set(FIELDS)
    shipper = cast("dict[str, object]", fields_map["shipper"])
    assert set(shipper) == {"si", "bl", "match"}
    assert shipper["si"] and shipper["bl"]


def test_non_comparison_trace_has_no_provenance_events() -> None:
    _records, traces = run_pipeline(
        [("email_x", Email("FYI update", "Operational update, nothing to do."))]
    )
    stages = [event.stage for event in traces[0].events]
    assert stages == ["classify"]
    assert "extract" not in stages
    assert "compare" not in stages


def test_escalated_comparison_has_extract_but_no_compare() -> None:
    """Rule-1 escalation (no attachments): no docs -> no extract either."""
    _records, traces = run_pipeline(
        [("email_y", Email("TO CONFIRM DOCS", "Please check the SI and BL."))]
    )
    stages = [event.stage for event in traces[0].events]
    assert stages == ["classify", "review"]
    assert "compare" not in stages

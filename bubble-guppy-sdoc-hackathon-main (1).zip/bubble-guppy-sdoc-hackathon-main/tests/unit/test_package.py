"""Package-level smoke tests."""

import sdoc_hackathon


def test_package_importable() -> None:
    """The package must import without error."""
    assert sdoc_hackathon is not None

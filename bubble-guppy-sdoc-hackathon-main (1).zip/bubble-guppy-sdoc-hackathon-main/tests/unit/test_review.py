"""Tests for the review stage (issue 22): ADR-0004 table, row by row."""

from __future__ import annotations

import pytest

from sdoc_hackathon.models import ParsedDocument
from sdoc_hackathon.review import review_comparison


def _doc(kind: str, path: str = "attachments/x.txt") -> ParsedDocument:
    return ParsedDocument(path=path, fmt="txt", kind=kind)  # type: ignore[arg-type]


_FULL_SI = ParsedDocument(
    path="attachments/a_SI.txt",
    fmt="txt",
    kind="SI",
    text=(
        "SHIPPER: ACME\nCONSIGNEE: ORBIS\nNOTIFY PARTY: PACIFIC\n"
        "PORT OF LOADING: BUATAN, INDONESIA\n"
        "PORT OF DISCHARGE: FREMANTLE, AUSTRALIA\n"
        "No. of Containers: 6 x 40'HC\nGross Weight毛重(KGS): 131,322 KG"
    ),
    rows=(
        "SHIPPER: ACME",
        "CONSIGNEE: ORBIS",
        "NOTIFY PARTY: PACIFIC",
        "PORT OF LOADING: BUATAN, INDONESIA",
        "PORT OF DISCHARGE: FREMANTLE, changed",
        "No. of Containers: 6 x 40'HC",
        "Gross Weight毛重(KGS): 131,322 KG",
    ),
)
_FULL_BL_MATCH = ParsedDocument(
    path="attachments/a_BL.txt",
    fmt="txt",
    kind="BL",
    text=_FULL_SI.text,
    rows=_FULL_SI.rows,
)
_FULL_BL_MISMATCH = ParsedDocument(
    path="attachments/a_BL.txt",
    fmt="txt",
    kind="BL",
    text=_FULL_SI.text,
    rows=(
        "SHIPPER: ACME",
        "CONSIGNEE: ORBIS",
        "NOTIFY PARTY: PACIFIC",
        "PORT OF LOADING: BUATAN, INDONESIA",
        "PORT OF DISCHARGE: BUSAN, SOUTH KOREA",
        "No. of Containers: 8 x 40'HC",
        "Gross Weight毛重(KGS): 133,322 KG",
    ),
)


class TestAdr0004Table:
    def test_rule1_missing_attachment_zero(self) -> None:
        decision, comparison = review_comparison(0, [])
        assert decision.status == "NEEDS_REVIEW"
        assert decision.review_reason == "missing_attachment"
        assert comparison is None

    def test_rule1_missing_attachment_one(self) -> None:
        decision, _ = review_comparison(1, [_doc("SI")])
        assert decision.status == "NEEDS_REVIEW"
        assert decision.review_reason == "missing_attachment"

    def test_rule2_wrong_doc_type(self) -> None:
        decision, _ = review_comparison(2, [_doc("SI"), _doc("OTHER")])
        assert decision.status == "NEEDS_REVIEW"
        assert decision.review_reason == "wrong_doc_type"

    def test_rule3_unreadable(self) -> None:
        decision, _ = review_comparison(2, [_doc("SI"), _doc("UNREADABLE")])
        assert decision.status == "NEEDS_REVIEW"
        assert decision.review_reason == "unreadable"

    def test_rule4_missing_value(self) -> None:
        si = ParsedDocument(
            path="attachments/s.txt",
            fmt="txt",
            kind="SI",
            text="SHIPPER:\nCONSIGNEE: X",
            rows=("SHIPPER:", "CONSIGNEE: X"),
        )
        decision, _ = review_comparison(2, [si, _FULL_BL_MATCH])
        assert decision.status == "NEEDS_REVIEW"
        assert decision.review_reason == "missing_value"
        assert "shipper" in decision.detail

    def test_rule5_ok(self) -> None:
        decision, comparison = review_comparison(2, [_FULL_SI, _FULL_BL_MATCH])
        assert decision.status == "OK"
        assert decision.review_reason is None
        assert comparison is not None
        assert not comparison.has_defect()

    def test_rule5_mismatch_lists_defects(self) -> None:
        decision, comparison = review_comparison(2, [_FULL_SI, _FULL_BL_MISMATCH])
        assert decision.status == "MISMATCH"
        assert comparison is not None
        assert comparison.defect_fields() == [
            "port_of_discharge",
            "container_count",
            "gross_weight_kg",
        ]


class TestPrecedence:
    def test_missing_attachment_beats_everything(self) -> None:
        """Rule 1 fires on count even with broken documents present."""
        decision, _ = review_comparison(1, [_doc("OTHER"), _doc("UNREADABLE")])
        assert decision.review_reason == "missing_attachment"

    def test_wrong_doc_type_beats_unreadable(self) -> None:
        decision, _ = review_comparison(2, [_doc("OTHER"), _doc("UNREADABLE")])
        assert decision.review_reason == "wrong_doc_type"

    def test_unreadable_beats_missing_value(self) -> None:
        blank_si = ParsedDocument(
            path="attachments/s.txt",
            fmt="txt",
            kind="UNREADABLE",
            text="",
            rows=(),
        )
        decision, _ = review_comparison(2, [blank_si, _FULL_BL_MATCH])
        assert decision.review_reason == "unreadable"

    def test_two_sis_is_wrong_doc_type(self) -> None:
        decision, _ = review_comparison(2, [_doc("SI"), _doc("SI")])
        assert decision.status == "NEEDS_REVIEW"
        assert decision.review_reason == "wrong_doc_type"


def test_bundle_si_only_email_escalates() -> None:
    """Real fixture: only SI attached (507) → missing_attachment."""
    from pathlib import Path

    from sdoc_hackathon.parsers import parse_attachment

    att_root = (
        Path(__file__).resolve().parent.parent.parent
        / "sdoc-hackathon-bundle"
        / "attachments"
    )
    if not att_root.exists():  # pragma: no cover
        pytest.skip("bundle not present")
    doc, _ = parse_attachment(
        "attachments/email_507_SI.txt",
        (att_root / "email_507_SI.txt").read_bytes(),
    )
    decision, _ = review_comparison(1, [doc])
    assert decision.status == "NEEDS_REVIEW"
    assert decision.review_reason == "missing_attachment"


def test_bundle_scanned_bl_escalates_unreadable() -> None:
    """Real fixture: SI txt + scanned BL pdf (512) → unreadable without OCR."""
    from pathlib import Path

    from sdoc_hackathon.parsers import parse_attachment

    att_root = (
        Path(__file__).resolve().parent.parent.parent
        / "sdoc-hackathon-bundle"
        / "attachments"
    )
    if not att_root.exists():  # pragma: no cover
        pytest.skip("bundle not present")
    si, _ = parse_attachment(
        "attachments/email_512_SI.pdf", (att_root / "email_512_SI.pdf").read_bytes()
    )
    bl, _ = parse_attachment(
        "attachments/email_512_BL.pdf", (att_root / "email_512_BL.pdf").read_bytes()
    )
    decision, _ = review_comparison(2, [si, bl])
    assert decision.status == "NEEDS_REVIEW"
    assert decision.review_reason == "unreadable"


def test_bundle_corrupt_bl_escalates_unreadable() -> None:
    """Real fixture: SI txt + corrupt BL pdf (511) → unreadable."""
    from pathlib import Path

    from sdoc_hackathon.parsers import parse_attachment

    att_root = (
        Path(__file__).resolve().parent.parent.parent
        / "sdoc-hackathon-bundle"
        / "attachments"
    )
    if not att_root.exists():  # pragma: no cover
        pytest.skip("bundle not present")
    si, _ = parse_attachment(
        "attachments/email_511_SI.txt", (att_root / "email_511_SI.txt").read_bytes()
    )
    bl, _ = parse_attachment(
        "attachments/email_511_BL.pdf", (att_root / "email_511_BL.pdf").read_bytes()
    )
    decision, _ = review_comparison(2, [si, bl])
    assert decision.status == "NEEDS_REVIEW"
    assert decision.review_reason == "unreadable"


class TestRule1aSendRequest:
    """Rule 1a: only a very-high-confidence send-request body clears rule 1.

    Anchor phrases/verbs mirror the generator's exact body families; every
    ambiguous shape must keep escalating (recall-first, ADR-0004).
    """

    _SIG = "\n\nBest Regards,\nSyed Faraz Ali\nShipping Documentation\nDID : +971 04 4938295"

    @staticmethod
    def _send_body(intro: str, sig: str = _SIG) -> str:
        return intro + sig

    def test_unambiguous_send_request_clears(self) -> None:
        body = self._send_body(
            "Dear Hari,\n\nPlease assist to send the draft BL for SIN832764835 "
            "for checking asap.\n\nThank you."
        )
        decision, comparison = review_comparison(0, [], body=body)
        assert decision.status == "OK"
        assert decision.review_reason is None
        assert comparison is None

    def test_send_request_with_trailing_thread_clears(self) -> None:
        body = self._send_body(
            "Dear Mitchelle,\n\nPlease assist to send the draft BL for PSGSE9638346 "
            "for checking asap.\n\nThank you."
        ) + (
            "\n\n______________________________\nFrom: Ooi Sok Yong "
            "<sokyong@aprilasia.com>\nSent: Friday, December 26, 2026 10:12 PM\n"
            "Subject: RE: 5ALT-57871\n\nPlease follow the previous instruction. Thank you."
        )
        decision, _ = review_comparison(0, [], body=body)
        assert decision.status == "OK"

    def test_warning_banner_send_request_clears(self) -> None:
        banner = (
            "WARNING: This email originated outside of our organisation. "
            "As a security measure, please exercise caution with E-Mail "
            "content and any links or attachments.\n\n"
        )
        body = banner + self._send_body(
            "Dear Najiha,\n\nPlease assist to send the draft BL for 070500236763 "
            "for checking asap.\n\nThank you."
        )
        decision, _ = review_comparison(0, [], body=body)
        assert decision.status == "OK"

    def test_single_attachment_send_request_clears(self) -> None:
        body = self._send_body(
            "Dear Team,\n\nKindly send the draft BL for 070500263211 asap."
        )
        decision, _ = review_comparison(1, [_doc("SI")], body=body)
        assert decision.status == "OK"

    @pytest.mark.parametrize(
        ("body", "why"),
        [
            (
                "Dear Team,\n\nPlease compare the SI and draft BL for 070500263211 "
                "and confirm (attachments appear to have been dropped). Thank you."
                + _SIG,
                "explicit dropped note (real 506/508/510 shape)",
            ),
            (
                "Dear Team,\n\nPlease compare the SI and draft BL for I756178688 and "
                "confirm (the draft BL is still missing). Thank you." + _SIG,
                "explicit still-missing note (real 507/509 shape)",
            ),
            (
                "Dear Hari,\n\nPlease assist to send the draft BL for SIN832764835 "
                "for checking asap.\n\nThank you.",
                "no signature/thread marker — unknown layout",
            ),
            (
                "Dear Hari,\n\nPls send me the docs.\n\nThank you." + _SIG,
                "no draft-BL doc noun",
            ),
            (
                "Dear Hari,\n\nBest Regards,\nSyed Faraz Ali" + _SIG,
                "no blank-line paragraph boundary — unknown layout",
            ),
        ],
    )
    def test_ambiguous_or_incident_bodies_still_escalate(
        self, body: str, why: str
    ) -> None:
        decision, _ = review_comparison(0, [], body=body)
        assert decision.status == "NEEDS_REVIEW", why
        assert decision.review_reason == "missing_attachment"

    def test_comparison_verbs_anywhere_block_clearance(self) -> None:
        # The live intro is clean, but comparison verbs in the quoted thread
        # (or subject) must veto clearance — document families are compared.
        body = self._send_body(
            "Dear Hari,\n\nPlease assist to send the draft BL for SIN832764835 "
            "for checking asap."
        ) + (
            "\n\n______________________________\nFrom: X <x@y.com>\n\n"
            "Please verify the BL matches the SI."
        )
        decision, _ = review_comparison(0, [], body=body)
        assert decision.status == "NEEDS_REVIEW"

    def test_send_request_with_dropped_note_escalates(self) -> None:
        body = self._send_body(
            "Dear Hari,\n\nPlease assist to send the draft BL for SIN832764835 "
            "for checking asap (the SI is missing)."
        )
        decision, _ = review_comparison(0, [], body=body)
        assert decision.status == "NEEDS_REVIEW"
        assert decision.review_reason == "missing_attachment"

    def test_no_body_given_still_escalates(self) -> None:
        decision, _ = review_comparison(0, [])
        assert decision.status == "NEEDS_REVIEW"
        assert decision.review_reason == "missing_attachment"

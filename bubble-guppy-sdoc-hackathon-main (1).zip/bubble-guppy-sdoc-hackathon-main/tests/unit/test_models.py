"""Unit tests for the shared contracts (issue 1)."""

from __future__ import annotations

import dataclasses

import pytest

from sdoc_hackathon.models import (
    FIELDS,
    CategoryPrior,
    ComparisonResult,
    Confidence,
    ExtractedFields,
    ParsedDocument,
    ReviewDecision,
    SubmissionRecord,
)
from sdoc_hackathon.trace import StepEvent, Trace


# ---------------------------------------------------------------- FIELDS ---
def test_fields_are_the_seven_canonical_fields() -> None:
    assert FIELDS == (
        "shipper",
        "consignee",
        "notify_party",
        "port_of_loading",
        "port_of_discharge",
        "container_count",
        "gross_weight_kg",
    )


# ------------------------------------------------------------ Confidence ---
def test_confidence_accepts_valid_scores() -> None:
    for score in (0.0, 0.55, 0.85, 0.95, 1.0):
        assert Confidence(score, "band").score == score


@pytest.mark.parametrize("score", [-0.1, 1.01, 42])
def test_confidence_rejects_out_of_range(score: float) -> None:
    with pytest.raises(ValueError, match="within"):
        Confidence(score, "bad")


def test_confidence_is_frozen() -> None:
    record = Confidence(0.9, "sure")
    with pytest.raises(dataclasses.FrozenInstanceError):
        record.score = 0.1  # type: ignore[misc]


# -------------------------------------------------------- ParsedDocument ---
def test_parsed_document_defaults() -> None:
    doc = ParsedDocument(path="attachments/x_SI.txt")
    assert doc.fmt == "unknown"
    assert doc.kind == "OTHER"
    assert doc.text == ""
    assert doc.rows == ()
    assert doc.scanned is False
    assert doc.error is None


def test_parsed_document_equality_and_construction() -> None:
    a = ParsedDocument(path="p", fmt="txt", rows=("a", "b"))
    b = ParsedDocument(path="p", fmt="txt", rows=("a", "b"))
    assert a == b


# ------------------------------------------------------- ExtractedFields ---
def test_extracted_fields_blank_by_default() -> None:
    fields = ExtractedFields()
    for name in FIELDS:
        assert getattr(fields, name) == ""
    assert fields.missing() == list(FIELDS)


def test_extracted_fields_missing_ignores_whitespace_blanks() -> None:
    fields = ExtractedFields(shipper="  ", consignee="ACME")
    assert fields.missing()[0] == "shipper"
    assert "consignee" not in fields.missing()


def test_extracted_fields_as_dict_roundtrip() -> None:
    fields = ExtractedFields(gross_weight_kg="21,577 KG")
    assert fields.as_dict()["gross_weight_kg"] == "21,577 KG"


# ------------------------------------------------------ ComparisonResult ---
def test_comparison_result_defect_fields() -> None:
    matches = dict.fromkeys(FIELDS, True)
    matches["shipper"] = False
    matches["container_count"] = False
    result = ComparisonResult(field_matches=matches, values={})
    assert result.defect_fields() == ["shipper", "container_count"]
    assert result.has_defect() is True


def test_comparison_result_all_match() -> None:
    result = ComparisonResult(field_matches=dict.fromkeys(FIELDS, True), values={})
    assert result.defect_fields() == []
    assert result.has_defect() is False


# ------------------------------------------------------ SubmissionRecord ---
def test_submission_record_defaults_match_sample_submission() -> None:
    record = SubmissionRecord(email_id="email_001", category="GENERAL")
    assert record.status == "OK"
    assert record.review_reason is None
    assert record.has_defect is False
    assert record.defect_fields == ()


def test_submission_record_mismatch_record() -> None:
    record = SubmissionRecord(
        email_id="email_001",
        category="BL_COMPARISON",
        status="MISMATCH",
        has_defect=True,
        defect_fields=("container_count",),
    )
    assert record.defect_fields == ("container_count",)


# -------------------------------------------------------- ReviewDecision ---
def test_review_decision_defaults() -> None:
    decision = ReviewDecision(status="NEEDS_REVIEW", review_reason="unreadable")
    assert decision.confidence is None
    assert decision.detail == ""


# --------------------------------------------------------- misc / traces ---
def test_category_prior_construction() -> None:
    assert CategoryPrior("SPAM", 3).weight == 3


def test_trace_records_stage_events_in_order() -> None:
    trace = Trace(email_id="email_004")
    trace.append(StepEvent(stage="classify", decision="BL_COMPARISON"))
    trace.append(StepEvent(stage="parse", decision="SI", detail="header"))
    assert [event.stage for event in trace.events] == ["classify", "parse"]
    assert trace.stage("parse") is not None
    assert trace.stage("parse").decision == "SI"  # type: ignore[union-attr]
    assert trace.stage("missing") is None


def test_step_event_defaults() -> None:
    event = StepEvent(stage="review", decision="OK")
    assert event.confidence is None
    assert event.detail == ""

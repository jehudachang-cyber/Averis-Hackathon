"""Tests for the minimal pipeline and submission writer (GH#19)."""

from __future__ import annotations

import json

import pytest

from conftest import BUNDLE_ROOT, EmailFixture
from sdoc_hackathon.classify import Email
from sdoc_hackathon.models import FIELDS, SubmissionRecord
from sdoc_hackathon.pipeline import load_bundle_emails, run_pipeline
from sdoc_hackathon.submission import (
    record_to_entry,
    to_submission,
    write_submission,
)

_SUBMISSION_KEYS = {
    "category",
    "status",
    "review_reason",
    "defect_fields",
    "has_defect",
}


# ------------------------------------------------------------ submission ---
def test_record_to_entry_matches_sample_shape() -> None:
    sample = json.loads(
        (BUNDLE_ROOT / "sample_submission.json").read_text(encoding="utf-8")
    )
    entry = record_to_entry(SubmissionRecord(email_id="email_001", category="GENERAL"))
    assert set(entry) == _SUBMISSION_KEYS
    reference = sample["email_001"]
    for key in _SUBMISSION_KEYS:
        assert entry[key] == reference[key]


def test_to_submission_rejects_duplicate_ids() -> None:
    records = [
        SubmissionRecord(email_id="email_001", category="GENERAL"),
        SubmissionRecord(email_id="email_001", category="SPAM"),
    ]
    with pytest.raises(ValueError, match="duplicate"):
        to_submission(records)


def test_write_submission_roundtrip(tmp_path) -> None:
    records = [
        SubmissionRecord(email_id="email_001", category="GENERAL"),
        SubmissionRecord(
            email_id="email_002",
            category="BL_COMPARISON",
            status="MISMATCH",
            has_defect=True,
            defect_fields=("gross_weight_kg",),
        ),
    ]
    path = write_submission(records, tmp_path / "sub" / "submission.json")
    payload = json.loads(path.read_text(encoding="utf-8"))
    assert payload["email_002"]["has_defect"] is True
    assert payload["email_002"]["defect_fields"] == ["gross_weight_kg"]
    assert payload["email_001"]["status"] == "OK"


# ---------------------------------------------------------------- pipeline ---
def test_run_pipeline_classifies_and_traces() -> None:
    records, traces = run_pipeline(
        [
            ("email_a", Email("REQUEST SI _ 1", "SI text")),
            ("email_b", Email("Congratulations! Gift card", "claim now")),
        ]
    )
    assert [record.category for record in records] == ["SI_REQUEST", "SPAM"]
    assert all(record.status == "OK" for record in records)
    assert traces[0].stage("classify").decision == "SI_REQUEST"  # type: ignore[union-attr]


def test_run_pipeline_preserves_input_order_and_ids() -> None:
    emails = [(f"email_{i:03d}", Email(None, "FYI.")) for i in (5, 1, 3)]
    records, traces = run_pipeline(emails)
    assert [record.email_id for record in records] == [
        "email_005",
        "email_001",
        "email_003",
    ]
    assert [trace.email_id for trace in traces] == records_identifiers(records)


def records_identifiers(records: list[SubmissionRecord]) -> list[str]:
    return [record.email_id for record in records]


# ------------------------------------------------- end-to-end on the bundle ---
def test_pipeline_over_full_bundle_matches_sample_ids() -> None:
    """Full-bundle run: 520 records, every sample id present, valid shape."""
    sample = json.loads(
        (BUNDLE_ROOT / "sample_submission.json").read_text(encoding="utf-8")
    )
    emails = load_bundle_emails(BUNDLE_ROOT)
    records, _traces = run_pipeline(emails)
    submission = to_submission(records)

    assert len(records) == len(sample)
    assert set(submission) == set(sample)
    for email_id, entry in submission.items():
        assert set(entry) == _SUBMISSION_KEYS
        assert entry["category"] in {
            "BL_COMPARISON",
            "SI_REQUEST",
            "INVOICE_QUERY",
            "GENERAL",
            "SPAM",
        }
        assert entry["status"] in {"OK", "MISMATCH", "NEEDS_REVIEW"}
        if entry["status"] != "MISMATCH":
            assert entry["defect_fields"] == []
            assert entry["has_defect"] is False
        defect_fields = entry["defect_fields"]
        assert isinstance(defect_fields, list)
        for field_name in defect_fields:
            assert field_name in FIELDS


def test_pipeline_fixture_categories_flow_through(
    request: pytest.FixtureRequest,
) -> None:
    """Every fixture email flows through the pipeline into a valid record.

    Escalation fixtures (no attachment / SI only) surface NEEDS_REVIEW
    per ADR-0004 rule 1; the SI-only fixture has no data_root in this
    test, so its attachment also cannot be read.
    """
    expected_status = {
        "email_bl_ok": "NEEDS_REVIEW",  # no data_root -> attachments unreadable
        "email_si_request": "OK",
        "email_invoice": "OK",
        "email_general": "OK",
        "email_spam": "OK",
        "email_no_attachment": "OK",  # ADR-0004 rule 1a: body is an unambiguous send request
        "email_si_only": "NEEDS_REVIEW",
    }
    for fixture_name, want_status in expected_status.items():
        email: EmailFixture = request.getfixturevalue(fixture_name)
        records, traces = run_pipeline([(email.email_id, email)])
        record = records[0]
        assert record.email_id == email.email_id
        assert record.status == want_status, fixture_name
        if want_status == "NEEDS_REVIEW":
            assert record.review_reason is not None
        assert record.has_defect is False
        assert traces[0].stage("classify") is not None
        assert traces[0].stage("classify").confidence is not None  # type: ignore[union-attr]
